from flask import Flask, current_app, request
import socket
import cv2
from Functions import ImageFunctions
import datetime
import random
import copy

# 以模块所在的模块为根目录
app = Flask(__name__)


class Config(object):
    DEBUG = True


def create_uuid():
    nowTime = datetime.datetime.now().strftime("%Y%m%d%H%M%S")  # current time
    randomNum = random.randint(0, 100)  # random integer
    if randomNum <= 10:
        randomNum = str(0) + str(randomNum)
    uniqueNum = str(nowTime) + str(randomNum)
    return uniqueNum


app.config.from_object(Config)
ename='jpg'
IP='http://116.62.132.196:5000/'
tempa=''

@app.route("/")
def index():
    print(current_app.config.get("CANSHU1"))
    return "hello flask"

@app.route('/up_photo', methods=['GET','POST'])
def up_photo():
    rdmm = create_uuid()
    num=rdmm
    global ename,tempa
    tempa=rdmm
    print('start')
    print(request.files)
    img_req = request.files.get('uploadFile')
    ename = img_req.filename.split('.')[-1]
    filename = num+'.'+ img_req.filename.split('.')[-1]
    img_req.save('static/'+filename)
    savepath = 'static/'+filename
    print(IP+savepath)
    return IP+savepath


@app.route('/add',methods=['POST'])     # miniprogram request
def add():
    data=request.get_json()['num']
    return str(data+1)


@app.route('/receiveOrder',methods=['GET','POST'])     # miniprogram request
def receiveOrder():
    global tempa
    print('here!')
    fpath = 'static/' + tempa+'.'+ename
    data=request.get_json()['order']
    X = ImageFunctions(fpath)
    rdmm = create_uuid()
    tempa=rdmm
    if data=='SSR':
        img_new=X.SSR()
    if data=='equalization':
        img_new=X.equalization()
    if data=='clahe':
        img_new=X.clahe()
    if data=='drag':
        img_new=X.drag()
    if data=='b1':
        img_new=X.blurry()
    if data=='b2':
        img_new=X.smooth()
    if data=='b3':
        img_new=X.reinforce()
    if data=='b4':
        img_new=X.USM()
    if data=='b5':
        img_new=X.edgeRef()
    if data=='b6':
        img_new=X.edgeRefPlus()
    if data=='b7':
        img_new=X.contour()
    if data=='b8':
        img_new=X.edgeGet()
    if data=='c1':
        img_new=X.Otsu()
    if data=='c2':
        img_new=X.ma()
    if data=='c3':
        img_new=X.adaptiveThresh()
    if data=='c4':
        img_new = X.sauvola()
    if data=='d1':
        img_new = X.erode()
    if data=='d2':
        img_new = X.dilate()
    if data=='d3':
        img_new = X.opening()
    if data=='d4':
        img_new = X.closing()
    if data=='e1':
        img_new = X.memory()
    if data=='e2':
        img_new = X.yearpass()
    if data=='e3':
        img_new = X.yearpass_red()
    if data=='e4':
        img_new = X.yearpass_green()
    if data=='e5':
        img_new = X.brighter()
    if data=='e6':
        img_new = X.dimmer()
    cv2.imwrite('static/' + rdmm + '.' + ename, img_new)
    fpath = 'static/' + rdmm + '.' + ename
    print('***')
    print('IP+filepath'+IP+fpath)
    print('***')
    return IP+fpath


if __name__ == '__main__':
    host_name = socket.gethostbyname(socket.gethostname())
    print(host_name)
    app.run(host=host_name, port=5000)