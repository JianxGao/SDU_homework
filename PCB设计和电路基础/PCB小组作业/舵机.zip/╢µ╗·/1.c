#include <reg52.h>
unsigned char pwm_flag;
unsigned char pwm_cnt;
unsigned char duty_cycle; //���ռ�ձ� (0 - 100)
sbit pwm_out = P1^1;
void timer0_isr(void) interrupt 1 using 1
{
    if(pwm_flag)
    {
        TL0 = 0xEE;
        TH0 = 0xFF;//��װ20usֵ
        pwm_cnt++;
        if(pwm_cnt == duty_cycle + 25)
        {
            pwm_out = 0;
            pwm_cnt = 0;
            pwm_flag = 0;   //��תpwm_out
        }else
        {
            pwm_out = 1;
        }
    }else
    {
        TL0 = 0x33;
        TH0 = 0xFE;//��װ500usֵ     
        pwm_cnt++;
        if(pwm_cnt == 35)
        {
            pwm_cnt = 0;
            pwm_out = 1;
            pwm_flag = 1;   //��תpwm_out
        }else{
            pwm_out = 0;
        }
    }
}
void Timer0Init(void) //20΢��@11.0592MHz
{
    TMOD = 0x01;                    //
    TL0 = 0xEE;                     //initial timer0 low byte
    TH0 = 0xFF;                //initial timer0 high byte
    TR0 = 1;                        //timer0 start running
    ET0 = 1;                        //enable timer0 
    EA = 1;                         //open global  switch
    pwm_cnt = 0;
    pwm_flag = 1;               // �ߵ�ƽ����
}
void main(void)
{
    Timer0Init();
	duty_cycle=0;
		while(1);
		
	
    return;}
