
void keyscan()

{

	if(key1 == 0)

	{

	delay(3);

	if(key1 == 0)

	{

		if(target >= 7)

		{

			target -= 1;

		}

		while(key1 == 0)

		{P1 = 0x00;}

	}

	P1 = 0xFF;

	}

 

	if(key2 == 0)

	{

		delay(3);

		if(key2 == 0)

		{

			if(target <= 26)

			{

				target += 1;

			}

			while(key2 == 0)

			{P1 = 0x00;}

		}

		P1 = 0xFF;

	}

}//����������

 

void initial()

{

	key1 = 1;

	key2 = 1;

	P1 = 0xff;

	initial_Timer();

}
