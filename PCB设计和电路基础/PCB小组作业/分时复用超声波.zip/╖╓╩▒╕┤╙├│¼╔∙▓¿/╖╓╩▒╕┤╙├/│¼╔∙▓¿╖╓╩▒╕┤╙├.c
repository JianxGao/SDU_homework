//��ʱ���汾
#include <STC8.H>
#include <intrins.h>

unsigned char buff[4]={0x00,0x00,0x00,0x00};
unsigned char a=0;
unsigned char b=0;
unsigned int cnt=0;
bit busy=0;
bit flag=0;

extern void Uart1Init();
void Delay100ms();
void UartSend(unsigned char dat);
void UartSendStr(unsigned char *p);
void timeinit();

void timer1() interrupt 3
{
		cnt++;
		if(cnt>=40)
		{
				cnt=0;
				flag=1;
		}
}
void main()
{
		Uart1Init();
		timeinit();
		while(1)
		{
			if(flag==1)
			{
				flag=0;
				P_SW1 = 0x00;
				UartSend(0x01);
				Delay100ms();
			}
			//while(a<4);
			if(a==4)
			{
				P_SW1 = 0x40;
				UartSendStr(buff);
				a=0;
			}
    }
}
void UartSend(unsigned char dat)
{
		SBUF = dat;
    while (!TI);
    TI=0;
}
void UartSendStr(unsigned char *p)
{
    while (*p)
    {
        UartSend(*p++);
    }
}
void UART1(void) interrupt 4
{
			if(RI)                           //�ж��ǽ����жϲ���
			{
				RI=0;
				if(a<4)				//��־λ����
				{
					buff[a]=SBUF;					//���뻺������ֵ
					a++;
				}
			}	
} 

void timeinit()
{
		TMOD = 0x00;                                //ģʽ0
    TL1 = 0x5E;                                 //65536-11.0592M/12/1000
    TH1 = 0x67;
    TR1 = 1;                                    //������ʱ��
    ET1 = 1;                                    //ʹ�ܶ�ʱ���ж�
    EA = 1;
}

void Delay100ms()		//@24.000MHz
{
	unsigned char i, j, k;

	_nop_();
	_nop_();
	i = 10;
	j = 31;
	k = 147;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}

