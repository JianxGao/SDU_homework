#include <STC8.H>

void Uart1Init(void)		//9600bps@24.000MHz
{	
		SCON = 0x50;		//8λ����,�ɱ䲨����
		T2L = 0x8F;                                 //65536-24000000/9600/4=0FFE8H
    T2H = 0xFD;
    AUXR = 0x15;                                //������ʱ��
    ES = 1;                                     //ʹ�ܴ����ж�
    EA = 1;
}

void Uart2Init(void)
{
		S2CON=0x10;
		T2L = 0x8F;                                 //65536-24000000/9600/4=0FFE8H
    T2H = 0xFD;
		AUXR = 0x14;
		IE2 = 0x01;                                  //ʹ�ܴ����ж�
    EA = 1;
}
void main()
{	
	
	Uart1Init();
	P_SW1 = 0x40;
	while(1);
}

void interruptuart() interrupt 4
{
	if(RI)
	{
		RI=0;
		SBUF=SBUF+1;
	}
	if(TI)
	{
		TI=0;
	}
}