#include <STC8.H>

sbit R22=P0^0;
sbit T22=P0^1;
unsigned int cnt=0;

void timer1() interrupt 3
{
		cnt++;
		if(cnt>=40)
		{
				R22=~R22;
				T22=~T22;
				cnt=0;
		}
}

void main()
{
    TMOD = 0x00;                                //ģʽ0
    TL1 = 0x5E;                                 //65536-11.0592M/12/1000
    TH1 = 0x67;
    TR1 = 1;                                    //������ʱ��
    ET1 = 1;                                    //ʹ�ܶ�ʱ���ж�
    EA = 1;

    while (1);
}
