#include <STC8.H>
#include <intrins.h>

unsigned char buff[4]={0x00,0x00,0x00,0x00};
unsigned char a=0;
unsigned char b=0;
bit busy=0;
bit flag=0;

extern void Uart1Init();
void Delay1000ms();
void Delay70ms();
void UartSend(unsigned char dat);
void UartSendStr(unsigned char *p);

void main()
{
		Uart1Init();
    while (1)
		{		
				P_SW1 = 0x00;
				UartSend(0x01);
				Delay70ms();
				//while(a<4);
				if(a==4)
				{
					P_SW1 = 0x40;
					UartSendStr(buff);
					a=0;
				}
				Delay1000ms();
		}
}
void UartSend(unsigned char dat)
{
    while (busy);
    busy = 1;
    SBUF = dat;
}
void UartSendStr(unsigned char *p)
{
    while (*p)
    {
        UartSend(*p++);
    }
}
void UART1(void) interrupt 4
{
		if(TI)
		{
			TI=0;
			busy = 0;
		}
		//while(a<4)
		
			if(RI && (a<4))                           //�ж��ǽ����жϲ���
			{
				RI=0; 		 //��־λ����
				buff[a]=SBUF;					//���뻺������ֵ
				a++;
			}
} 
void Delay1000ms()		//@24.000MHz
{
	unsigned char i, j, k;

	_nop_();
	_nop_();
	i = 122;
	j = 193;
	k = 128;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}

void Delay70ms()		//@24.000MHz
{
	unsigned char i, j, k;

	_nop_();
	_nop_();
	i = 7;
	j = 99;
	k = 50;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}

