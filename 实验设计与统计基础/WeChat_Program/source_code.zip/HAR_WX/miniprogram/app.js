//app.js
App({
  onLaunch: function() {
    var that = this;
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        env: 'test-wjjgg',
        traceUser: true,
      })
      wx.cloud.callFunction({
        name: "login",
        complete: res => {
          that.globalData.openid = res.result.openid;
          console.log(that.globalData.openid)
        }
      })
    }

    let capsuleInfo = wx.getMenuButtonBoundingClientRect();
    this.globalData = {
      capsuleInfo: capsuleInfo,
      windowName: null,
      openid: null,
      userInfo: null,
      isLogin: false,
      evn: 'test',
      queryDishes: null
    }
  },
  globalData: {}
})