// pages/kaihetiao/kaihetiao.js
const app = getApp()
const db = wx.cloud.database();
const kehetiao = db.collection("kaihetiao");
const play_tip = wx.createInnerAudioContext()
const play_54321 = wx.createInnerAudioContext()
Page({
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    height: "",
    weight: "",
    topography: "",
    space: "",
    // 手机6轴数据数组
    //三轴加速
    acc_x: [],
    acc_y: [],
    acc_z: [],
    //三轴角速度
    gry_x: [],
    gry_y: [],
    gry_z: [],
    notstart: true,
    startTime: 0,
    timeSs: 0,
    stop: false,
  },
  onLoad() {
    wx.showModal({
      title: '温馨提示',
      content: '运动前请做好热身~如果出现任何症状请立即停止记录~（填写完信息后点开始记录，会有语音提示，跟随语音引导即可。成功记录运动数据后记得保存数据~另外记录过程中出现意外，可以点击清除数据~）',
      showCancel: false,
      confirmText: "我知道了"
    })
    console.log(this.data.capsuleInfo)

  },
  heightinput: function (e) {
    this.setData({
      height: e.detail
    })
  },
  weightinput: function (e) {
    this.setData({
      weight: e.detail
    })
  },
  topographyinput: function (e) {
    this.setData({
      topography: e.detail
    })
  },
  spaceinput: function (e) {
    this.setData({
      space: e.detail
    })
  },
  mobileinput: function (e) {
    this.setData({
      mobile: e.detail
    })
  },
  // 点击开始记录
  startdata: function () {
    if (
      this.data.height == null | this.data.weight == null |
      this.data.height.length == 0 | this.data.weight.length == 0
    ) {
      wx.showModal({
        title: '启动失败',
        content: 'Sorry，您的信息未填写完全~',
        showCancel: false,
        confirmText: "我知道了"
      })
    } else {
      this.setData({
        isReading: true,
        stop: false,
        notstart: true
      })
      play_tip.play()
      play_tip.autoplay = true
      play_tip.src = "cloud://test-wjjgg.7465-test-wjjgg-1301103607/fix_mobile.mp3"
      play_tip.onEnded(res => {
        play_54321.stop()
        play_54321.play()
        play_54321.autoplay = true
        play_54321.src = "cloud://test-wjjgg.7465-test-wjjgg-1301103607/5432.mp3"
        play_54321.onEnded(res => {
          // 初始化
          this.setData({
            startTime: new Date().getTime(),
            isReading: true,
          })
          // console.log("start: ", new Date())
          let _this = this;
          let accXs = [];
          let accYs = [];
          let accZs = [];
          let gyroscopeXs = [];
          let gyroscopeYs = [];
          let gyroscopeZs = [];
          let timeSs_a = [];
          let timeSs_g = [];
          //  采样频率设置50hz
          wx.startAccelerometer({
            interval: 'game'
          })
          wx.startGyroscope({
            interval: 'game'
          })
          let pinlv = 20; // 20ms/s
          let count = 15000 / pinlv;
          // 收集6s数据
          // 监听加速度数据
          let mid_time;
          wx.onAccelerometerChange(
            function (res) {
              mid_time = new Date().getTime();
              // console.log("mid-time: ", mid_time, "startTime: ", _this.data.startTime)
              // 除以1000就是1s
              let timeStep = (mid_time - _this.data.startTime) / (pinlv)
              //现在是20ms一次，所以1s就是50次
              if (timeStep < count) {
                accXs.push(res.x)
                accYs.push(res.y)
                accZs.push(res.z)
                timeSs_a.push(mid_time)
                // console.log("a:", res.x, res.y, res.z, mid_time)
              }
              if (timeStep >= count) {
                // console.log("end", new Date())
                _this.setData({
                  acc_x: accXs,
                  acc_y: accYs,
                  acc_z: accZs,
                  timeSs_a: timeSs_a,
                  isReading: false
                })
                wx.offAccelerometerChange();
                wx.stopAccelerometer();
                return;
              }
            })
          // 三轴角速度
          wx.onGyroscopeChange(
            function (res) {
              // 除以1000就是1s
              let timeStep = (mid_time - _this.data.startTime) / (pinlv)
              //现在是20ms一次，所以1s就是50次
              if (timeStep < count) {
                gyroscopeXs.push(res.x)
                gyroscopeYs.push(res.y)
                gyroscopeZs.push(res.z)
                timeSs_g.push(mid_time)
                // console.log("g:", res.x, res.y, res.z, mid_time)
              }
              if (timeStep >= count) {
                // console.log("end", new Date())
                _this.setData({
                  gry_x: gyroscopeXs,
                  gry_y: gyroscopeYs,
                  gry_z: gyroscopeZs,
                  timeSs_g: timeSs_g,
                  isReading: false
                })
                wx.offGyroscopeChange();
                wx.stopGyroscope();
                const play_finish = wx.createInnerAudioContext()
                play_finish.stop()
                play_finish.play()
                play_finish.autoplay = true
                play_finish.src = "cloud://test-wjjgg.7465-test-wjjgg-1301103607/finish.mp3"
                play_finish.onEnded(res => {
                  play_finish.destroy()
                  play_tip.stop()
                  play_54321.stop()
                })
                _this.setData({
                  notstart: false
                })
                return;
              }
            })
        })
      })
    }
  },
  // 停止记录数据
  stopdata: function () {
    let _this = this
    play_tip.stop()
    play_54321.stop()
    this.setData({
      isReading: false,
      stop: true
    })
    wx.stopAccelerometer({
      success: res => {
        console.log("停止读取三轴加速度数据")
        _this.setData({
          acc_x: [],
          acc_y: [],
          acc_z: [],
        })
      }
    })
    wx.stopGyroscope({
      success: res => {
        console.log("停止读取三轴陀螺仪数据")
        _this.setData({
          gry_x: [],
          gry_y: [],
          gry_z: [],
        })
      }
    })
  },
  // 清除数据
  cleardata: function () {
    play_tip.stop()
    play_54321.stop()
    this.setData({
      acc_x: [],
      acc_y: [],
      acc_z: [],
      gry_x: [],
      gry_y: [],
      gry_z: [],
      notstart: true
    })
    console.log("清除数据")
    wx.showToast({
      title: '清除成功',
    })
  },
  savedata: function () {
    console.log(app.globalData.userInfo)
    if (this.data.acc_x.length == 0) {
      wx.showModal({
        title: '保存失败',
        content: 'Sorry，您未采集运动数据~',
        showCancel: false,
        confirmText: "我知道了"
      })
    } else {
      play_tip.stop()
      play_54321.stop()
      wx.showLoading({
        title: '数据保存中',
      })
      this.setData({
        notstart: true
      })
      console.log("保存成功")
      kehetiao.add({
        data: {
          userInfo: app.globalData.userInfo,
          nickname: app.globalData.userInfo.gender.nickName,
          gender: app.globalData.userInfo.gender,
          height: this.data.height,
          weight: this.data.weight,
          acc_x: this.data.acc_x,
          acc_y: this.data.acc_y,
          acc_z: this.data.acc_z,
          gry_x: this.data.gry_x,
          gry_y: this.data.gry_y,
          gry_z: this.data.gry_z,
          times: this.data.timeSs_a,
          timeSs_g: this.data.timeSs_g
        }
      }).then(res => {
        this.setData({
          acc_x: [],
          acc_y: [],
          acc_z: [],
          gry_x: [],
          gry_y: [],
          gry_z: [],
          notstart: true
        })})
      wx.showToast({
        title: '保存成功',
      })
    }
  },

})