// pages/data_take/data_take.js
var app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
  },
  keep: function () {
    wx.navigateTo({
      url: '../keep/keep',
    })
  },
  kaihetiao: function () {
    wx.navigateTo({
      url: '../kaihetiao/kaihetiao',
    })
  },
  highleglift: function () {
    wx.navigateTo({
      url: '../High_leg_lift/High_leg_lift',
    })
  },
  squat: function () {
    wx.navigateTo({
      url: '../squat/squat',
    })
  },
  bobbi: function () {
    wx.navigateTo({
      url: '../Bobbi/Bobbi',
    })
  },
  pushup: function () {
    wx.navigateTo({
      url: '../push_up/push_up',
    })
  },
})