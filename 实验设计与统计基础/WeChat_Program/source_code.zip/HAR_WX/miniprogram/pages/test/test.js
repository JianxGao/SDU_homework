// pages/test/test.js
// test主要传递测试者信息
const app = getApp()

Page({
  data: {
    test_time: 30,
    radio: null,
    sport: null,
    capsuleInfo: app.globalData.capsuleInfo,
    test: false,
    height: "",
    weight: "",
    topography: "",
    space: "",
    notstart: true,
    startTime: 0,
    timeSs: 0,
    stop: false,
  },
  // 选择操作系统
  onChange(event) {
    this.setData({
      radio: event.detail,
    });
  },
  // 选择操作系统
  onClick(event) {
    const {
      name
    } = event.currentTarget.dataset;
    this.setData({
      radio: name,
    });
  },
  // 步进器函数
  onstepchange(e) {
    console.log(e.detail);
    this.setData({
      test_time: e.detail
    })
  },
  onLoad() {

  },

  // 点击开始记录
  startdata: function () {
    if (this.data.radio == null | 
      this.data.height == null | this.data.weight == null |
      this.data.height.length == 0 | this.data.weight.length == 0) {
      wx.showModal({
        title: '前往失败',
        content: 'Sorry，请您完善信息~',
        showCancel: false,
        confirmText: "我知道了"
      })
    }
    else {
      var release = ({
        timelen: this.data.test_time,
        os: this.data.radio
      })
      wx.navigateTo({
        url: '../pre_test/pre_test?release=' + JSON.stringify(release),
      })
    }
  },
  startdata2: function () {
    if (this.data.radio == null | 
        this.data.height == null | this.data.weight == null |
        this.data.height.length == 0 | this.data.weight.length == 0) {
      wx.showModal({
        title: '前往失败',
        content: 'Sorry，请您完善信息~',
        showCancel: false,
        confirmText: "我知道了"
      })
    }
    else {
      var release = ({
        timelen: this.data.test_time,
        os: this.data.radio
      })
      wx.navigateTo({
        url: '../new_test/new_test?release=' + JSON.stringify(release),
      })
    }
  },
  heightinput: function (e) {
    this.setData({
      height: e.detail
    })
  },
  weightinput: function (e) {
    this.setData({
      weight: e.detail
    })
  },
})