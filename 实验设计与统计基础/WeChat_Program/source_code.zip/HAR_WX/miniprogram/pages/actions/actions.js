// pages/actions/actions.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  shendun:function(){
    wx.navigateTo({
      url: '../shendun_yanshi/shendun_yanshi',
    })
  },
  shenduntiao:function(){
    wx.navigateTo({
    url: '../shenduntiao_yanshi/shenduntiao_yanshi',
    })
  },
  kaihetiao:function(){
    wx.navigateTo({
      url: '../kaihetiao_yanshi/kaihetiao_yanshi',
    })
  },
  gaotaitui:function(){
    wx.navigateTo({
      url: '../gaotaitui_yanshi/gaotaitui_yanshi',
    })
  },
})