// pages/home/home.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    auther: false,
    have_auther: true,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  onLoad: function() {
    var _this = this;
    wx.getSetting({
      success(res) {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称
          wx.getUserInfo({
            success: function(res) {
              _this.setData({
                auther: true,
                have_auther: false,
              })
              app.globalData.userInfo = res.userInfo
              console.log(res.userInfo)
            }
          })
        }
      }
    })
  },
  bindGetUserInfo(e) {
    console.log(e.detail.userInfo)
    app.globalData.userInfo = e.detail.userInfo
    if (e.detail.userInfo==null){}
    else{
      this.setData({
        auther: true,
        have_auther: false,
      })
    }
  },
  actions:function(){
    wx.navigateTo({
      url: '../actions/actions',
    })
  },
  gotodata_Take:function(){
    wx.navigateTo({
      url:'../data_take/data_take',
    })
  },

  gototest:function(){
    wx.navigateTo({
      url: '../test/test',
    })
  }

})