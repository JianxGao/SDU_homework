export declare const button: string;
