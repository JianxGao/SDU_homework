// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: 'homework-84qwq'
})
const db = cloud.database()
const _ = db.command 

// 云函数入口函数
exports.main = async (event, context) => {
  if (event.addMessage) {
    return await db.collection('chatGroups').doc(event.chatgroupId)
      .update({
        data: {
          message: _.addToSet(event.message)
        }
      })
  } else if (event.removeMessage) {
    return await db.collection('chatGroups').doc(event.chatgroupId)
      .update({
        data: {
          message: _.pullAll([event.message])
        }
      })
  }
}