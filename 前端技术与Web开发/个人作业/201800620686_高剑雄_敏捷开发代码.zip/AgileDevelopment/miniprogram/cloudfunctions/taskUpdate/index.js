// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: 'homework-84qwq' 
})
const db = cloud.database()
const _ = db.command 
// 云函数入口函数
exports.main = async (event, context) => {
  if (event.field) { 
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          executor: _.remove()
        }
      })
  } else if (event.removeTask) {
    return await db.collection('tasks').doc(event.taskId)
      .remove()
  } else if (event.addMembers) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          members: _.addToSet(event.userId)
        }
      })
  } else if (event.removeMembers) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          members: _.pullAll([event.userId])
        }
      })
  } else if (event.addTaskNode) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          taskNode: _.addToSet(event.parentTaskId)
        }
      })
  } else if (event.addAllTaskNode) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          alltaskNode: _.addToSet(event.parentTaskId)
        }
      })
  } else if (event.removeTaskNode) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          taskNode: _.pullAll([event.parentTaskId]),
          alltaskNode: _.pullAll([event.parentTaskId])
        }
      })
  } else if (event.addProNode) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          proNode: _.addToSet(event.proId)
        }
      })
  } else if (event.removeProNode) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          proNode: _.pullAll([event.proId])
        }
      })
  } else if (event.addCompanys) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          companys: _.addToSet(event.companyId)
        }
      })
  } else if (event.removeCompanys) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          companys: _.pullAll([event.companyId])
        }
      })
  } else if (event.addSubtask) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          subtasksNode: _.addToSet(event.subtaskId)
        }
      })
  } else if (event.addAllSubtask) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          allsubtasks: _.addToSet(event.subtaskId)
        }
      })
  } else if (event.removeSubtask) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          subtasksNode: _.pullAll([event.subtaskId]),
          allsubtasks: _.pullAll([event.subtaskId])
        }
      })
  } else if (event.addFiles) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          files: _.addToSet(event.fileId)
        }
      })
  } else if (event.addPrivateFiles) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          privatefiles: _.addToSet(event.fileId)
        }
      })
  } else if (event.removeFiles) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          files: _.pullAll([event.fileId]),
          privatefiles: _.pullAll([event.fileId])
        }
      })
  } else if (event.addFolders) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          folders: _.addToSet(event.folderId)
        }
      })
  } else if (event.addAllFolders) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          allfolders: _.addToSet(event.folderId)
        }
      })
  } else if (event.removeFolders) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          folders: _.pullAll([event.folderId]),
          allfolders: _.pullAll([event.folderId])
        }
      })
  } else if (event.addPermission) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          addPermission: _.addToSet(event.userId)
        }
      })
  } else if (event.removeAddPermission) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          addPermission: _.pullAll([event.userId])
        }
      })
  } else if (event.deletePermission) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          deletePermission: _.addToSet(event.userId)
        }
      })
  } else if (event.removeDeletePermission) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          deletePermission: _.pullAll([event.userId])
        }
      })
  } else if (event.modifyPermission) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          modifyPermission: _.addToSet(event.userId)
        }
      })
  } else if (event.removeModifyPermission) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          modifyPermission: _.pullAll([event.userId])
        }
      })
  } else if (event.updateName) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          name: _.set(event.name)
        }
      })
  } else if (event.updateExecutor) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          executor: _.set(event.executorId)
        }
      })
  } else if (event.updateStart) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          start: _.set(event.start)
        }
      })
  } else if (event.updateEnd) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          end: _.set(event.end)
        }
      })
  } else if (event.updateFinished) {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: {
          finished: _.set(event.finished)
        }
      })
  } else {
    return await db.collection('tasks').doc(event.taskId)
      .update({
        data: event.data
      })
  }
}



