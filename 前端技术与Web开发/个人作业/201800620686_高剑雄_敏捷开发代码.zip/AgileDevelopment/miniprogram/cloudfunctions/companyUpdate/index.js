// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init({
  env: 'homework-84qwq'
})
const db = cloud.database()
const _ = db.command
// 云函数入口函数
exports.main = async (event, context) => {
  if (event.removeCompany) {
    return await db.collection('companys').doc(event.companyId)
      .remove()
  } else if (event.addMember) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          members: _.addToSet(event.userId)
        }
      })
  } else if (event.removeMember) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          members: _.pullAll([event.userId])
        }
      })
  } else if (event.addProjects) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          projectsNode: _.addToSet(event.proId)
        }
      })
  } else if (event.removeProjects) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          projectsNode: _.pullAll([event.proId])
        }
      })
  } else if (event.addTasks) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          tasks: _.addToSet(event.taskId)
        }
      })
  } else if (event.removeTasks) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          tasks: _.pullAll([event.taskId])
        }
      })
  } else if (event.addEvents) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          events: _.addToSet(event.eventId)
        }
      })
  } else if (event.removeEvents) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          events: _.pullAll([event.eventId])
        }
      })
  } else if (event.addFiles) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          files: _.addToSet(event.fileId)
        }
      })
  } else if (event.removeFiles) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          files: _.pullAll([event.fileId])
        }
      })
  } else if (event.addFolders) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          folders: _.addToSet(event.folderId)
        }
      })
  } else if (event.removeFolders) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          folders: _.pullAll([event.folderId])
        }
      })
  } else if (event.addPermission) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          addPermission: _.addToSet(event.userId)
        }
      })
  } else if (event.removeAddPermission) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          addPermission: _.pullAll([event.userId])
        }
      })
  } else if (event.deletePermission) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          deletePermission: _.addToSet(event.userId)
        }
      })
  } else if (event.removeDeletePermission) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          deletePermission: _.pullAll([event.userId])
        }
      })
  } else if (event.modifyPermission) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          modifyPermission: _.addToSet(event.userId)
        }
      })
  } else if (event.removeModifyPermission) {
    return await db.collection('companys').doc(event.companyId)
      .update({
        data: {
          modifyPermission: _.pullAll([event.userId])
        }
      })
  }
}