// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: 'homework-84qwq'
})
const db = cloud.database()
const _ = db.command
const folderDB = db.collection('folders')
// 云函数入口函数
exports.main = async (event, context) => {
  if (event.removeFolder) {
    return await folderDB.doc(event.folderId)
      .remove()
  } else if (event.addMembers) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          members: _.addToSet(event.userId)
        }
      })
  } else if (event.removeMembers) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          members: _.pullAll([event.userId])
        }
      })
  } else if (event.addFolderNode) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          folderNode: _.addToSet(event.parentfolderId)
        }
      })
  } else if (event.addAllFolderNode) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          allfolderNode: _.addToSet(event.parentfolderId)
        }
      })
  } else if (event.removeFolderNode) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          folderNode: _.pullAll([event.parentfolderId]),
          allfolderNode: _.pullAll([event.parentfolderId])
        }
      })
  } else if (event.addSubFiles) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          subfiles: _.addToSet(event.fileId)
        }
      })
  } else if (event.addFiles) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          files: _.addToSet(event.fileId)
        }
      })
  } else if (event.removeFile) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          subfiles: _.pullAll([event.fileId]),
          files: _.pullAll([event.fileId])
        }
      })
  } else if (event.addSubFolders) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          subfolders: _.addToSet(event.subFolderId)
        }
      })
  } else if (event.addFolders) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          folders: _.addToSet(event.subFolderId)
        }
      })
  } else if (event.removeSubFolder) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          subfolders: _.pullAll([event.subFolderId]),
          folders: _.pullAll([event.subFolderId])
        }
      })
  } else if (event.addProNode) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          proNode: _.addToSet(event.proId)
        }
      })
  } else if (event.removeProNode) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          proNode: _.pullAll([event.proId])
        }
      })
  } else if (event.addTaskNode) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          taskNode: _.addToSet(event.taskId)
        }
      })
  } else if (event.removeTaskNode) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          taskNode: _.pullAll([event.taskId])
        }
      })
  } else if (event.addEventNode) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          eventNode: _.addToSet(event.eventId)
        }
      })
  } else if (event.removeEventNode) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          eventNode: _.pullAll([event.eventId])
        }
      })
  } else if (event.addCompanys) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          companys: _.addToSet(event.companyId)
        }
      })
  } else if (event.removeCompanys) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          companys: _.pullAll([event.companyId])
        }
      })
  } else if (event.addPermission) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          addPermission: _.addToSet(event.userId)
        }
      })
  } else if (event.removeAddPermission) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          addPermission: _.pullAll([event.userId])
        }
      })
  } else if (event.deletePermission) {
    return await folderDB.doc(event.folderId)
      .update({
        data: {
          deletePermission: _.addToSet(event.userId)
        }
      })
  } else if (event.removeDeletePermission) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          deletePermission: _.pullAll([event.userId])
        }
      })
  } else if (event.modifyPermission) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          modifyPermission: _.addToSet(event.userId)
        }
      })
  } else if (event.removeModifyPermission) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          modifyPermission: _.pullAll([event.userId])
        }
      })
  }
}