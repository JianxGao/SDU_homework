 // 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: 'homework-84qwq' 
}) 
const db = cloud.database()
const _ = db.command
// 云函数入口函数
exports.main = async (event, context) => {
  if (event.tasksExecutor) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          tasksExecutor: _.addToSet(event.taskId)
        }  
      })
  } else if (event.tasksFollower) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          tasksFollower: _.addToSet(event.taskId)
        }
      })
  } else if (event.tasksCreator) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          tasksCreator: _.addToSet(event.taskId)
        }
      })
  } else if (event.addTasks) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          tasks: _.addToSet(event.taskId)
        }
      })
  } else if (event.removeTasks) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          tasks: _.pullAll([event.taskId])
        }
      })
  } else if (event.addProjects) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          projects: _.addToSet(event.proId)
        }
      })
  } else if (event.removeProjects) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          projects: _.pullAll([event.proId])
        }
      })
  } else if (event.addFriends) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          friends: _.addToSet(event.friendId)
        }
      })
  } else if (event.removeFriends) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          friends: _.pullAll([event.friendId])
        }
      })
  } else if (event.addFile) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          files: _.addToSet(event.fileId)
        }
      })
  } else if (event.removeFile) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          files: _.pullAll([event.fileId])
        }
      })
  } else if (event.addFolder) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          folders: _.addToSet(event.folderId)
        }
      })
  } else if (event.removeFolder) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          folders: _.pullAll([event.folderId])
        }
      })
  } else if (event.addCompany) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          companys: _.addToSet(event.companyId)
        }
      })
  } else if (event.removeCompany) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          companys: _.pullAll([event.companyId])
        }
      })
  } else if (event.addChatGroups) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          chatGroups: _.addToSet(event.chatgroupId)
        }
      })
  } else if (event.removeChatGroups) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          chatGroups: _.pullAll([event.chatgroupId])
        }
      })
  } else if (event.addTag) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          tags: _.addToSet(event.taskId)
        }
      })
  } else if (event.removeTag) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          tags: _.pullAll([event.taskId])
        }
      })
  } else if (event.addEvents) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          events: _.addToSet(event.eventId)
        }
      })
  } else if (event.removeEvents) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          events: _.pullAll([event.eventId])
        }
      })
  } else if (event.addGroups) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          groups: _.addToSet(event.groupId)
        }
      })
  } else if (event.removeGroups) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          groups: _.pullAll([event.groupId])
        }
      })
  } else if (event.updateName) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          name: _.set(event.name)
        }
      })
  } else if (event.updateMail) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          mail: _.set(event.mail)
        }
      })
  } else if (event.updatePhone) {
    return await db.collection('user').doc(event.userId)
      .update({
        data: {
          phone: _.set(event.phone)
        }
      })
  } else {
    return await db.collection('user').doc(event.userId)
      .update({
        data: event.data
      })
  }
}
