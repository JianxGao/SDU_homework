// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init({
  env: 'homework-84qwq'
})
const db = cloud.database()
// 云函数入口函数
exports.main = async (event, context) => {
  if (event.addProject) {
    return await db.collection('projects').add({
      data: event.data
    })
  } else if (event.addCompany) {
    return await db.collection('companys').add({
      data: event.data
    })
  } else if (event.addEvent) {
    return await db.collection('events').add({
      data: event.data
    })
  } else if (event.addFile) {
    return await db.collection('files').add({
      data: event.data
    })
  } else if (event.addFolder) {
    return await db.collection('folders').add({
      data: event.data
    })
  } else if (event.addTask) {
    return await db.collection('tasks').add({
      data: event.data
    })
  } else if (event.addUser) {
    return await db.collection('user').doc(event.userId).set({
      data: event.data
    })
  } else if (event.addChatGroup) {
    return await db.collection('chatGroups').add({
      data: event.data
    })
  }
}