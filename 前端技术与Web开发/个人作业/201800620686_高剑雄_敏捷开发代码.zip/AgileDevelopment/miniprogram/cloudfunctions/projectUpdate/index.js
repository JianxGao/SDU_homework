// 云函数入口文件
const cloud = require('wx-server-sdk')
 
cloud.init({
  env: 'homework-84qwq'
})
const db = cloud.database()
const _ = db.command
// 云函数入口函数
exports.main = async (event, context) => {
  if (event.addMembers) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          members: _.addToSet(event.userId)
        }
      })
  } if (event.removeMembers) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          members: _.pullAll([event.userId])
        }
      })
  } else if (event.addFile) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          files: _.addToSet(event.fileId)
        }
      })
  } else if (event.addAllFile) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          allfiles: _.addToSet(event.fileId)
        }
      })
  } else if (event.removeFile) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          files: _.pullAll([event.fileId]),
          allfiles: _.pullAll([event.fileId])
        }
      })
  } else if (event.addLinkedFile) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          linkedfiles: _.addToSet(event.fileId)
        }
      })
  } else if (event.removeLinkedFile) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          linkedfiles: _.pullAll([event.fileId])
        }
      })
  } else if (event.addFolder) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          folders: _.addToSet(event.folderId)
        }
      })
  } else if (event.addAllFolder) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          allfolders: _.addToSet(event.folderId)
        }
      })
  } else if (event.removeFolder) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          folders: _.pullAll([event.folderId]),
          allfolders: _.pullAll([event.folderId])
        }
      })
  } else if (event.addLinkedFolder) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          linkedfolders: _.addToSet(event.folderId)
        }
      })
  } else if (event.removeLinkedFolder) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          linkedfolders: _.pullAll([event.folderId])
        }
      })
  } else if (event.addCompany) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          companys: _.addToSet(event.companyId)
        }
      })
  } else if (event.removeCompany) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          companys: _.pullAll([event.companyId])
        }
      })
  } else if (event.addAllTask) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          allTasksNode: _.addToSet(event.taskId)
        }
      })
  } else if (event.removeAllTasksNode) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          allTasksNode: _.pullAll([event.taskId])
        }
      })
  } else if (event.addEvent) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          events: _.addToSet(event.eventId)
        }
      })
  } else if (event.removeEvent) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          events: _.pullAll([event.eventId])
        }
      })
  } else if (event.addMessage) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          message: _.addToSet(event.message)
        }
      })
  } else if (event.removeMessage) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          message: _.pullAll([event.message])
        }
      })
  } else if (event.addPermission) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          addPermission: _.addToSet(event.userId)
        }
      })
  } else if (event.removeAddPermission) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          addPermission: _.pullAll([event.userId])
        }
      })
  } else if (event.deletePermission) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          deletePermission: _.addToSet(event.userId)
        }
      })
  } else if (event.removeDeletePermission) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          deletePermission: _.pullAll([event.userId])
        }
      })
  } else if (event.modifyPermission) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          modifyPermission: _.addToSet(event.userId)
        }
      })
  } else if (event.removeModifyPermission) {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: {
          modifyPermission: _.pullAll([event.userId])
        }
      })
  } else if (event.removeProject) {
    return await db.collection('projects').doc(event.proId)
      .remove()
  } else {
    return await db.collection('projects').doc(event.proId)
      .update({
        data: event.data
      })
  }
}