// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: 'homework-84qwq'
})
const db = cloud.database()
const _ = db.command 
const fileDB = db.collection('files')

// 云函数入口函数
exports.main = async (event, context) => {
  if (event.removeFile) {
    return await fileDB.doc(event.fileId)
      .remove()
  } else if (event.addMembers) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          members: _.addToSet(event.userId)
        }
      })
  } else if (event.removeMembers) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          members: _.pullAll([event.userId])
        }
      })
  } else if (event.addFolderNode) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          folderNode: _.addToSet(event.folderId)
        }
      })
  } else if (event.addAllFolderNode) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          allfolderNode: _.addToSet(event.folderId)
        }
      })
  } else if (event.removeFolderNode) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          folderNode: _.pullAll([event.folderId]),
          allfolderNode: _.pullAll([event.folderId])
        }
      })
  } else if (event.addProNode) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          proNode: _.addToSet(event.proId)
        }
      })
  } else if (event.removeProNode) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          proNode: _.pullAll([event.proId])
        }
      })
  } else if (event.addTaskNode) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          taskNode: _.addToSet(event.taskId)
        }
      })
  } else if (event.removeTaskNode) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          taskNode: _.pullAll([event.taskId])
        }
      })
  } else if (event.addEventNode) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          eventNode: _.addToSet(event.eventId)
        }
      })
  } else if (event.removeEventNode) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          eventNode: _.pullAll([event.eventId])
        }
      })
  } else if (event.addCompanys) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          companys: _.addToSet(event.companyId)
        }
      })
  } else if (event.removeCompanys) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          companys: _.pullAll([event.companyId])
        }
      })
  } else if (event.addPermission) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          addPermission: _.addToSet(event.userId)
        }
      })
  } else if (event.removeAddPermission) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          addPermission: _.pullAll([event.userId])
        }
      })
  } else if (event.deletePermission) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          deletePermission: _.addToSet(event.userId)
        }
      })
  } else if (event.removeDeletePermission) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          deletePermission: _.pullAll([event.userId])
        }
      })
  } else if (event.modifyPermission) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          modifyPermission: _.addToSet(event.userId)
        }
      })
  } else if (event.removeModifyPermission) {
    return await fileDB.doc(event.fileId)
      .update({
        data: {
          modifyPermission: _.pullAll([event.userId])
        }
      })
  }
}