//app.js
import { router } from './util/router.js'
App({
  onLaunch: function () {
    let _this = this
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        env: 'homework-84qwq',
        traceUser: true,
      })
      //openid 
      wx.cloud.callFunction({
        name: 'login',
        data: {},
        success: res => {
          console.log("云函数 [login] user openid: ", res.result.openid)
          this.globalData.openid = res.result.openid;
        },
        fail: res => {
          console.log("云函数 [login] 调用失败", err)
        }
      })
      router.clearCached()
      const {
        screenHeight,
        screenWidth,
        statusBarHeight,
        windowHeight,
        model
      } = wx.getSystemInfoSync()
      let width = wx.getMenuButtonBoundingClientRect().left
      let capsuleInfo = wx.getMenuButtonBoundingClientRect();
      console.log(capsuleInfo)
      const totalTopHeight = model.indexOf('iPhone X') > -1
        ? 88
        : model.indexOf('iPhone') > -1
          ? 64
          : 68
      this.globalData.navigatorH = totalTopHeight - statusBarHeight
      this.globalData.statusBarHeight = statusBarHeight
      this.globalData.screenHeight = screenHeight
      this.globalData.screenWidth = screenWidth
      this.globalData.width = width
      this.globalData.capsuleInfo = capsuleInfo
      this.globalData.router = router
    }
  },
  onShow: function(e) {
    console.log("onshow")
    console.log(e)
    
  },
  routerPage: router.routerPage.bind(router),
  destroyPage: router.destroyPage.bind(router),
  globalData: {
    userInfo: null,
    navigatorH: 0,
    statusBarHeight: 0,
    router: null
  }
})
