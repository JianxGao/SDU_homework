// pages/waddLink/waddLink.js
let app = getApp()
const util = require('../../util/wutils.js')
const images = require('../../util/images.js')
//获取数据库引用 
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
const eventDB = db.collection('events')
const fileDB = db.collection('files')
const folderDB = db.collection('folders')
Page({
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    navigatorH: app.globalData.navigatorH,//
    statusBarHeight: app.globalData.statusBarHeight,//状态栏的高度，单位px
    screenHeight: app.globalData.screenHeight,
    screenWidth: app.globalData.screenWidth,
    images: images
  },
  onLoad: function (options) {
    console.log("options: ", options);
    // const taskId = options.taskId;
    if (options.taskId) this.setData({ taskId: options.taskId });
    if (options.eventId) this.setData({eventId: options.eventId});
    if (options.link) this.setData({link:Number(options.link)});
    if (options.view) this.setData({view: true})
  },
  onShow: function () {
    let _this = this;
    if (this.data.taskId) {taskDB.doc(this.data.taskId).get().then(res => {
      _this.setData({taskInfo: res.data})
      let files = res.data.files || [];//任务文件的id;
      let folders = res.data.folders || [];//任务文件夹的id
      let filesTask = files.map(item => {return fileDB.doc(item).get()});
      Promise.all(filesTask).then(res => {
        let filesInfo = res.map(item => {return item.data});
        _this.setData({ filesInfo: filesInfo, filesId: files});
      });
      let foldersTask = folders.map(item => { return folderDB.doc(item).get() });
      Promise.all(foldersTask).then(res => {
        let foldersInfo = res.map(item => { return item.data });
        _this.setData({ foldersInfo: foldersInfo, foldersId: folders });
      });
    })};
    if (this.data.eventId) {eventDB.doc(this.data.eventId).get().then(res => {
      _this.setData({ eventInfo: res.data })
      let files = res.data.files || [];//日程文件的id;
      let folders = res.data.folders || [];//日程文件夹的id
      let filesTask = files.map(item => { return fileDB.doc(item).get() });
      Promise.all(filesTask).then(res => {
        let filesInfo = res.map(item => { return item.data });
        _this.setData({ filesInfo: filesInfo, filesId: files });
      });
      let foldersTask = folders.map(item => { return folderDB.doc(item).get() });
      Promise.all(foldersTask).then(res => {
        let foldersInfo = res.map(item => { return item.data });
        _this.setData({ foldersInfo: foldersInfo });
      });
    })};
  },
  innerScroll(e) {

  },
  goBack(){
    if (this.data.link) {
      console.log("返回。。。。", this.data.link)
      wx.navigateBack({ delta: Number(this.data.link)});
      return;
    }
    wx.navigateBack()
  },
  goProList(){
    if (this.data.taskId) wx.navigateTo({url: '../wproList/wproList?taskId='+this.data.taskId});
    if (this.data.eventId) wx.navigateTo({ url: '../wproList/wproList?eventId=' + this.data.eventId });
  },
  fileDetail(e) {
    if (this.data.editingFile) {
      return;
    }
    console.log(e)
    const fileId = e.currentTarget.dataset.fileid;
    wx.navigateTo({
      url: '../wfileDetail/wfileDetail?fileId=' + fileId,
    })
  },
  folderDetail: function (e) {
    if (this.data.editingFile) {
      return;
    }
    const folderId = e.currentTarget.dataset.folderid
    wx.navigateTo({
      url: '../wfolderDetail/wfolderDetail?folderId=' + folderId,
    })
  },
  /**
 * 上传文件
 */
  uploadFile: function () {
    let _this = this;
    wx.chooseMessageFile({
      count: 1,
      type: 'all',
      success(res) {
        console.log("chooseMessageFile:", res)
        const tempFilePath = res.tempFiles[0].path
        const tempFileName = res.tempFiles[0].name
        const setTempFileName = new Date().valueOf() + res.tempFiles[0].name
        console.log('choose: ', res, tempFileName)
        wx.showLoading({
          title: '加载中...',
          icon: 'none'
        })
        _this.setData({
          size: util.getFileSize(res.tempFiles[0].size)
        })
        console.log("size:  ", _this.data.size)
        const savePath = app.globalData.openid + '/' 
        console.log("savePath:  ", savePath)
        wx.cloud.uploadFile({
          cloudPath: savePath + setTempFileName,
          filePath: tempFilePath,
          success: res => {
            _this.saveFileToDB(res.fileID, tempFileName)
          },
          fail: res => {
            wx.showToast({
              title: '失败',
              icon: 'warn',
              duration: 2000
            })
          }
        })
      },
      fail: res => {
        console.log(res)
      }
    })
  },
  /**
   * 获取文件的下载链接
   */
  saveFileToDB: function (fileID, tempFileName) {
    let _this = this
    console.log("saveFileToDB 获取文件的下载链接",)
    console.log(fileID, tempFileName)
    let layer = -1;//层级
    console.log("layer: ", layer)
    let folderNode = null;//直接所属文件夹
    let allFolderNode = [];//所有所属文件夹
    // console.log("_this.data.eventInfo.members", _this.data.eventInfo.members)
    // console.log("_this.data.taskInfo.members", _this.data.taskInfo.members)
    console.log(_this.data.taskInfo ? _this.data.taskInfo.members : _this.data.eventInfo.members)
    let membersId = _this.data.taskInfo ? _this.data.taskInfo.members : _this.data.eventInfo.members;//项目成员
    console.log("membersId: ", membersId);
    let proNode = _this.data.taskInfo ? _this.data.taskInfo.proNode : _this.data.eventInfo.proNode;//所属项目
    let taskId = _this.data.taskId || null;
    console.log("taskId: ", taskId);
    let eventId = _this.data.eventId || null;
    console.log("eventId: ", eventId);
    let companysId = _this.data.taskInfo ?_this.data.taskInfo.companys : _this.data.eventInfo.companys;//所属公司
    let addPermission = _this.data.taskInfo ?_this.data.taskInfo.addPermission : _this.data.eventInfo.addPermission;
    let deletePermission = _this.data.taskInfo ?_this.data.taskInfo.deletePermission : _this.data.eventInfo.deletePermission;
    let modifyPermission = _this.data.taskInfo ?_this.data.taskInfo.modifyPermission : _this.data.eventInfo.modifyPermission;
    wx.showLoading({
      title: '上传中...',
    })
    //(fileID, tempFileName, _this, layer, folderNode, allFolderNode, proId)
    if (this.data.taskId) {
      util.saveFileToDB(fileID, tempFileName, _this, layer,
        folderNode, allFolderNode, membersId, proNode, companysId, taskId, null,
        addPermission, deletePermission, modifyPermission);
    }
    if (this.data.eventId) {
      util.saveFileToDB(fileID, tempFileName, _this, layer,
        folderNode, allFolderNode, membersId, proNode, companysId, null, eventId,
        addPermission, deletePermission, modifyPermission);
    }
  },
  rotateBtn: function (e) {
    console.log("旋转按钮");
    const dataset = e.currentTarget.dataset;
    console.log(dataset)
    let filesInfo = this.data.filesInfo
    let foldersInfo = this.data.foldersInfo
    if (dataset.fileid) {
      const fileid = dataset.fileid
      const index = filesInfo.indexOf(filesInfo.filter(item => { return item._id === fileid })[0]);
      console.log(index);
      filesInfo[index].isRotate = !filesInfo[index].isRotate;
      filesInfo.filter(item => { return item._id != fileid }).map(item => { return item.isRotate = false })
      foldersInfo.map(item => { return item.isRotate = false })
    } else if (dataset.folderid) {
      const folderid = dataset.folderid
      const index = foldersInfo.indexOf(foldersInfo.filter(item => { return item._id === folderid })[0]);
      console.log(index);
      foldersInfo[index].isRotate = !foldersInfo[index].isRotate;
      foldersInfo.filter(item => { return item._id != folderid }).map(item => { return item.isRotate = false })
      filesInfo.map(item => { return item.isRotate = false })
    }
    this.setData({
      filesInfo: filesInfo,
      foldersInfo: foldersInfo
    })
  },
  // edit event
  leaveEditFile: function () {
    console.log("退出编辑文件状态");
    this.data.filesInfo.map(item => { return item.isRotate = false })
    this.data.foldersInfo.map(item => { return item.isRotate = false })
    this.setData({ filesInfo: this.data.filesInfo, foldersInfo: this.data.foldersInfo })
    this.setData({
      editingFile: false
    })
  },
  enterEditFile: function () {
    console.log("进入编辑文件状态");
    this.setData({
      editingFile: true
    })
  },

  delfile(e){
    console.log("删除文件：", e);
    wx.showLoading({
      title: '移除文件...',
    })
    let _this = this;
    let taskId = this.data.taskId;
    let eventId = this.data.eventId;
    const fileId = e.currentTarget.dataset.fileid;
    fileDB.doc(fileId).get().then(res => {
      let fileIDpath = res.data.fileID;//存储位置
      console.log("fileIDpath: ", fileIDpath);
      let creatorId = res.data.creator;//上传者
      let taskNode = res.data.taskNode;//所属任务[]
      this.setData({ tasksPromise: []});
      if (res.data.layer === -1) {
        //更新文件表，files: taskNode, eventNode, remove()
        _this.updateFileFields(fileId, fileIDpath, taskId, eventId);
        //用户表，users：files
        _this.updateUserFields(fileId, creatorId);
        //任务表，tasks：files
        if (taskId) { _this.updateTaskFields(fileId, null, taskId)};
        if (eventId) { _this.updateEventFields(fileId,null, eventId)};
        Promise.all(_this.data.tasksPromise).then(res => {
          let filesId = _this.data.filesId.filter(item => {return item != fileId});
          let filesTask = filesId.map(item => { return fileDB.doc(item).get() });
          Promise.all(filesTask).then(res => {
            let filesInfo = res.map(item => { return item.data });
            _this.setData({ filesInfo: filesInfo, filesId: filesId });
            wx.hideLoading()
          });
        })
      } else {
        _this.updateFileFields(fileId, null, taskId, eventId);
        if (taskId) { _this.updateTaskFields(fileId,null, taskId) };
        if (eventId) { _this.updateEventFields(fileId,null, eventId) };
        Promise.all(_this.data.tasksPromise).then(res => {
          let filesId = _this.data.filesId.filter(item => { return item != fileId });
          let filesTask = filesId.map(item => { return fileDB.doc(item).get() });
          Promise.all(filesTask).then(res => {
            let filesInfo = res.map(item => { return item.data });
            _this.setData({ filesInfo: filesInfo, filesId: filesId });
            wx.hideLoading()
          });
        })
      }
    })
  },
  updateFileFields(fileId, fileID, taskId, eventId) {
    console.log("--------------------------------------updateFileFields---------------------------------");
    //该任务或日程的专属文件，需要删除
    if (fileID) {
      const removeFile = wx.cloud.callFunction({
        name: 'fileUpdate',
        data: {
          removeFile: true,
          fileId: fileId
        }
      });
      this.data.tasksPromise.push(removeFile);
      console.log("removeFile: ", removeFile)
      const deleteFile = wx.cloud.deleteFile({
        fileList: [fileID]
      });
      this.data.tasksPromise.push(deleteFile);
      console.log("deleteFile: ", deleteFile)
    } else {
      //取消任务的关联文件，taskNode
      if (taskId) {
        const taskNode = wx.cloud.callFunction({
          name: 'fileUpdate',
          data: {
            removeTaskNode: true,
            fileId: fileId,
            taskId: taskId
          }
        });
        this.data.tasksPromise.push(taskNode);
        console.log("taskNode: ", taskNode)
      } else if (eventId) {
        const eventNode = wx.cloud.callFunction({
          name: 'fileUpdate',
          data: {
            removeEventNode: true,
            fileId: fileId,
            eventId: eventId
          }
        });
        this.data.tasksPromise.push(eventNode);
        console.log("eventNode: ", eventNode)
      }
    }
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)

  },
  updateTaskFields(fileId, folderId, taskId) {
    console.log("--------------------------------------updateTaskFields---------------------------------");
    if (fileId) {
      const files = wx.cloud.callFunction({
        name: 'taskUpdate',
        data: {
          removeFiles: true,
          taskId: taskId,
          fileId: fileId
        }
      });
      this.data.tasksPromise.push(files);
      console.log("files: ", files)
      console.log("this.data.tasksPromise: ", this.data.tasksPromise)
    }
    if (folderId) {
      const folders = wx.cloud.callFunction({
        name: 'taskUpdate',
        data: {
          removeFolders: true,
          taskId: taskId,
          folderId: folderId
        }
      });
      this.data.tasksPromise.push(folders);
      console.log("folders: ", folders)
      console.log("this.data.tasksPromise: ", this.data.tasksPromise)
    }
  },
  updateEventFields(fileId, folderId, eventId) {
    console.log("--------------------------------------updateEventFields---------------------------------");
    if (fileId) {
      const files = wx.cloud.callFunction({
        name: 'eventUpdate',
        data: {
          removeFiles: true,
          eventId: eventId,
          fileId: fileId
        }
      });
      this.data.tasksPromise.push(files);
      console.log("files: ", files)
      console.log("this.data.tasksPromise: ", this.data.tasksPromise)
    }
    if (folderId) {
      const folders = wx.cloud.callFunction({
        name: 'eventUpdate',
        data: {
          removeFolders: true,
          eventId: eventId,
          folderId: folderId
        }
      });
      this.data.tasksPromise.push(folders);
      console.log("folders: ", folders)
      console.log("this.data.tasksPromise: ", this.data.tasksPromise)
    }
  },
  updateUserFields(fileId, creatorId) {
    console.log("--------------------------------------updateUserFields---------------------------------");
    const files = wx.cloud.callFunction({
      name: 'userUpdate',
      data: {
        removeFile: true,
        userId: creatorId,
        fileId: fileId
      }
    });
    this.data.tasksPromise.push(files);
    console.log("files: ", files)
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  updateFolderFields(folderId, taskId, eventId) {
    console.log("--------------------------------------updateFolderFields--------------------------------------")
    //取消任务的关联文件，taskNode
    if (taskId) {
      const taskNode = wx.cloud.callFunction({
        name: 'folderUpdate',
        data: {
          removeTaskNode: true,
          folderId: folderId,
          taskId: taskId
        }
      });
      this.data.tasksPromise.push(taskNode);
      console.log("taskNode: ", taskNode)
    } else if (eventId) {
      const eventNode = wx.cloud.callFunction({
        name: 'folderUpdate',
        data: {
          removeEventNode: true,
          folderId: folderId,
          eventId: eventId
        }
      });
      this.data.tasksPromise.push(eventNode);
      console.log("eventNode: ", eventNode)
    }
  },
  
  delfolder(e) {
    console.log("取消关联文件夹：", e);
    wx.showLoading({
      title: '移除文件夹...',
    })
    let _this = this;
    let taskId = this.data.taskId;
    let eventId = this.data.eventId;
    const folderId = e.currentTarget.dataset.folderid;
    folderDB.doc(folderId).get().then(res => {
      this.setData({ tasksPromise: [] });
      //更新文件表，files: taskNode, eventNode, remove()
      _this.updateFolderFields(folderId, taskId, eventId);
      //任务表，tasks：files
      if (taskId) { _this.updateTaskFields(null, folderId, taskId) };
      if (eventId) { _this.updateEventFields(null, folderId, eventId) };
      Promise.all(_this.data.tasksPromise).then(res => {
        let foldersId = _this.data.filesId.filter(item => { return item != fileId });
        let foldersTask = foldersId.map(item => { return folderDB.doc(item).get() });
        Promise.all(foldersTask).then(res => {
          let foldersInfo = res.map(item => { return item.data });
          _this.setData({ foldersInfo: foldersInfo, foldersId: foldersId });
          wx.hideLoading()
        });
      })
    })
  }
})



/*
let filesTask = files.map(item => {return fileDB.doc(item).get()});
      Promise.all(filesTask).then(res => {
        let filesInfo = res.map(item => {return item.data});
        _this.setData({ filesInfo: filesInfo, filesId: files});
      });
      let foldersTask = folders.map(item => { return folderDB.doc(item).get() });
      Promise.all(foldersTask).then(res => {
        let foldersInfo = res.map(item => { return item.data });
        _this.setData({ foldersInfo: foldersInfo, foldersId: folders });
      });
*/