// pages/wproDetail/wproDetail.js 
let app = getApp()
const util = require('../../util/wutils.js')
const images = require('../../util/images.js')
const { Wechat } = require('../../util/accessToken.js')
const w = new Wechat()
//获取数据库引用 
const db = wx. cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
const eventDB = db.collection('events')
const fileDB = db.collection('files')
const folderDB = db.collection('folders')
Page({
  data: { 
    capsuleInfo: app.globalData.capsuleInfo,
    navigatorH: app.globalData.navigatorH,//
    screenWidth: app.globalData.screenWidth,
    statusBarHeight: app.globalData.statusBarHeight,//状态栏的高度，单位px
    screenHeight: app.globalData.screenHeight,
    proId: null,
    projectInfo: null,//项目的信息
    tabIndex: 0,
    currentIndex: 0,
    tabs: ['任务', '文件', '日程', '群聊'],
    showRight: false,
    images: images,
    showOngoing: false,
    showAwaiting: false,
    showDone: false,
    content: '',
    noticeObj: [],
    height: 0,
    disable: true
  },
  /**
   * 页面跳转部分
   */
  goBack: function() {
    console.log(this.data.add)
    if(this.data.add){
      console.log("返回两个界面")
      wx.navigateBack({delta: 2})
    } else {
      wx.navigateBack({delta: 1})
    }
  },
 
  addMember: function() {
    // console.log('添加成员');
    let _this = this
    wx.navigateTo({
      url: '../waddMem/waddMem?proId=' + _this.data.projectInfo._id,
      success: function(res) {
        _this.setData({
          showRight: false
        })
      }
    })
  },

  addTask: function (e) {
    let administrator = this.data.projectInfo.addPermission.concat(this.data.projectInfo.deletePermission).concat(this.data.projectInfo.modifyPermission);
    if (administrator.indexOf(app.globalData.openid) === -1) {
      wx.showToast({ title: '对不起，您没有添加权限。', icon: 'none' });
      return;
    }
    wx.navigateTo({
      url: `../waddTask/waddTask?proId=${this.data.projectInfo._id}&label=${e.currentTarget.dataset.label}`,
    })
  },

  projectSetting: function() {
    let _this = this;
    // console.log("项目设置")
    wx.navigateTo({
      url: '../wproSetting/wproSetting?proId=' + _this.data.projectInfo._id,
    })
  },

  fileDetail: function (e) {
    if (this.data.editingFile) {
      return;
    }
    console.log(e)
    const fileId = e.currentTarget.dataset.fileid;
    wx.navigateTo({
      url: '../wfileDetail/wfileDetail?fileId=' + fileId,
    })
  },

  addEvent: function () {
    wx.navigateTo({
      url: `../waddEvent/waddEvent?proId=${this.data.projectInfo._id}`,
    })
  },

  eventDetail: function (e) {
    // console.log(e);
    const eventId = e.currentTarget.dataset.eventid;
    wx.navigateTo({
      url: '../weventDetail/weventDetail?eventId=' + eventId,
    })
  },

  folderDetail: function (e) {
    if (this.data.editingFile) {
      return;
    }
    const folderId = e.currentTarget.dataset.folderid
    wx.navigateTo({
      url: '../wfolderDetail/wfolderDetail?folderId=' + folderId,
    })
  },
  //设置吸顶函数
  innerScroll: function(e) {
    let _this = this
    const fixedTop = 112;
    let scrollTop = e.detail.scrollTop;
    this.setData({ scrollTop: scrollTop})
    console.log("scrollTop: ", scrollTop)
    if (scrollTop + fixedTop > this.data.awaitingTop && scrollTop + fixedTop < this.data.ongoingTop) {
      this.setData({
        awaitingFixed: true,
        ongoingFixed: false,
        doneFixed: false,
      })
    } else if (scrollTop + fixedTop > this.data.ongoingTop && scrollTop + fixedTop < this.data.doneTop) {
      // console.log(e.detail.scrollTop, this.data.awaitingTop, this.data.ongoingTop, this.data.doneTop);
      this.setData({
        awaitingFixed: false,
        ongoingFixed: true,
        doneFixed: false,
      })
    } else if (scrollTop + fixedTop > this.data.doneTop){
      // console.log(e.detail.scrollTop, this.data.awaitingTop, this.data.ongoingTop, this.data.doneTop);
      this.setData({
        awaitingFixed: false,
        ongoingFixed: false,
        doneFixed: true,
      })
    } else {
      this.setData({
        awaitingFixed: false,
        ongoingFixed: false,
        doneFixed: false
      })
    }
  },

  onLoad: function (options) {
    let _this = this;
    if (options.add) {
      this.setData({
        add: true
      })
    }
    const proId = options.proId;
    _this.setData({
      proId: proId, sender: app.globalData.openid
    })
    userDB.doc(app.globalData.openid).get().then(res => {
      _this.setData({user: res.data})
    });
    projectDB.doc(this.data.proId).get().then(res => {
      let allTasksNode = res.data.allTasksNode;
    })
  },
  /**
   * 获取三个tab距离顶部的距离
   */
  getLabelInfo: function (l1_itemNum, l2_itemNum) {
    // console.log(l1_itemNum, l2_itemNum)
    let _this = this;
    let fixTop = 126
    let labelHeight = 40;
    let displayAllHeight = 48;
    let itemHeight = 50;
    let ongoingTop = labelHeight + l1_itemNum * itemHeight + displayAllHeight + fixTop;
    let doneTop = ongoingTop + labelHeight + l2_itemNum * itemHeight + displayAllHeight;
    this.setData({
      awaitingTop: fixTop,
      ongoingTop: ongoingTop,
      doneTop: doneTop
    })
    // console.log("awaitingTop: ", fixTop);
    // console.log("ongoingTop: ", ongoingTop);
    // console.log("doneTop: ", doneTop);
  },

  /**
   * 获取各分组任务的信息
   */
  getTasksInfo: function(tasksnodeId) {
    let tasksnodeIdlength = tasksnodeId[0].length + tasksnodeId[1].length + tasksnodeId[2].length;
    console.log("getTasksInfo", tasksnodeId, tasksnodeIdlength)
    let tasksInfolength = 0;
    let tasksInfo = {0: [], 1: [], 2: []};
    let _this = this;
    for (let i in tasksnodeId) {
      let tasks = []
      let tasksNode = tasksnodeId[i];

      for (let j=0; j < tasksNode.length; j++) {
        let taskId = tasksNode[j];
        const promise = taskDB.doc(taskId).get();
        tasks.push(promise);
      }
      Promise.all(tasks).then(res => {
        let taskInfo = res.map(item => { return item.data })
        tasksInfolength += taskInfo.length
        tasksInfo[i] = taskInfo;
        let displayTaskInfo = {
          0: tasksInfo[0].slice(0, 2),
          1: tasksInfo[1].slice(0, 2),
          2: tasksInfo[2].slice(0, 2)
        };
        let hiddenTaskInfo = {
          0: tasksInfo[0].slice(2, ),
          1: tasksInfo[1].slice(2, ),
          2: tasksInfo[2].slice(2, )
        }
        _this.getLabelInfo(2, 2);
        
        while (tasksInfolength === tasksnodeIdlength) {
          // console.log("显示子节点：", displayTaskInfo)
          // console.log("隐藏子节点：", hiddenTaskInfo)
          _this.setData({
            tasksInfo: tasksInfo,
            displayTaskInfo: displayTaskInfo,
            hiddenTaskInfo: hiddenTaskInfo,
          });
          console.log(true)
          return;
        }
      })
    }
    
  },
  /**
   * 从创建任务界面返回时，重新请求该项目的子任务
   */
  onShow: function () {
    console.log("detail onShow");
    let _this = this;
    //根据proId查询项目
    projectDB.doc(this.data.proId).get({
      success: res => {
        console.log(res.data);
        let administrator = res.data.addPermission.concat(res.data.deletePermission).concat(res.data.modifyPermission);
        _this.setData({creator: res.data.creator, administrator: administrator });
        _this.setData({projectInfo: res.data,tasksnode: res.data.tasksnode,eventsId: res.data.events,
          filesId: res.data.files,foldersId: res.data.folders, messages: res.data.message});
        //获取公司信息
        if (res.data.company) {
          app.globalData.currentCompany = res.data.company;
          _this.setData({currentCompany: res.data.company})
        }
        //获取任务信息，如果当前tabIndex为0
        if (res.data.tasksnode && _this.data.tabIndex === 0) {
          console.log("加载任务信息。。。");
          let tasksnode = res.data.tasksnode
          for (let key in tasksnode) {
            tasksnode[key] = tasksnode[key].filter(item => {return res.data.allTasksNode.indexOf(item) != -1});
          };
          const tasksnodetask = wx.cloud.callFunction({
            name: 'projectUpdate',
            data: {
              proId: _this.data.projectInfo._id,
              data: {tasksnode: tasksnode}
            }
          })
          _this.getTasksInfo(tasksnode);
        } 
        //获取日程信息
        if (_this.data.tabIndex === 2) {
          console.log("--------------------------------加载日程信息-----------------------------------")
          const eventsId = res.data.events || [];
          wx.showLoading({title: '加载中...'})
          util.getEventInfo(_this, eventsId)
        }
        //获取文件信息
        if (_this.data.tabIndex === 1) {
          console.log("--------------------------------加载文件信息-----------------------------------")
          const filesId = res.data.files || [];
          let queryFiles = filesId.map(item => {return fileDB.doc(item).get()});
          Promise.all(queryFiles)
          .then(res => {
            let filesInfo = res.map(item => { return item.data });
            console.log("filesInfo: ", filesInfo)
            filesInfo.map(item => {return item.isRotate = false});
            _this.setData({filesInfo: filesInfo || []})
          })
        } 
        if (_this.data.tabIndex === 1) {
          console.log("--------------------------------加载文件夹信息-----------------------------------")
          const foldersId = res.data.folders || [];
          let queryFolders = foldersId.map(item => { return folderDB.doc(item).get() });
          Promise.all(queryFolders).then(res => {
            let foldersInfo = res.map(item => { return item.data });
            foldersInfo.map(item => { return item.isRotate = false })
            _this.setData({foldersInfo: foldersInfo})
          })
        }
        if (_this.data.tabIndex === 3) {
          let messagesInfo = res.data.message || [];
          let queryId = Array.from(new Set(messagesInfo.map(item => { return item.sender })));
          let queryMessageSender = queryId.map(item => { return userDB.doc(item).get() });
          let senderList = {}
          Promise.all(queryMessageSender).then(res => {
            res.map(item => { senderList[item.data._id] = item.data.name });
            messagesInfo = messagesInfo.map(item => { item.senderName = senderList[item.sender]; return item });
            console.log("messagesInfo: ", messagesInfo);
            _this.setData({ messagesInfo: messagesInfo || [], senderList: senderList })
          })
        }
        //获取成员信息 
        if (res.data.members) {
          // console.log("获取成员信息")
          let membersId = res.data.members;
          util.getMembersInfo(_this, membersId)
        }
      }
    })
  },

  taskDetail: function(e) {
    // console.log('go to this detail for task');
    // console.log(e) 
    const taskId = e.currentTarget.dataset.taskid
    const proId = this.data.projectInfo._id
    wx.navigateTo({
      url: `../wtaskDetail/wtaskDetail?proId=${proId}&taskId=${taskId}`,
    })
  },

  updateTaksStatu: function(e) {
    let _this = this;
    // console.log(e.currentTarget.dataset.taskid);
    const taskId = e.currentTarget.dataset.taskid;
    const currentIndex = e.currentTarget.dataset.index;
    console.log("当前处于阶段：", typeof(currentIndex), Number(currentIndex))
    // const currentIndex = Number(this.data.currentIndex)//当前任务所在的类别
    let tasksInfo = this.data.tasksInfo
    console.log("taskInfo[currentIndex]:", tasksInfo[currentIndex])
    //更新tasksInfo 
    tasksInfo[currentIndex] = util.updateTaksStatu(taskId, tasksInfo[currentIndex]);
    let displayTaskInfo = {
      0: tasksInfo[0].slice(0, 2),
      1: tasksInfo[1].slice(0, 2),
      2: tasksInfo[2].slice(0, 2)
    };
    let hiddenTaskInfo = {
      0: tasksInfo[0].slice(2),
      1: tasksInfo[1].slice(2),
      2: tasksInfo[2].slice(2)
    }
    _this.getLabelInfo(2, 2);
    this.setData({
      tasksInfo: tasksInfo,
      displayTaskInfo: displayTaskInfo,
      hiddenTaskInfo: hiddenTaskInfo
    })
  },
  /**
   * 上传文件
   */
  uploadFile: function() {
    let _this = this;
    let administrator = _this.data.projectInfo.addPermission.concat(_this.data.projectInfo.deletePermission).concat(_this.data.projectInfo.modifyPermission);
    if (administrator.indexOf(app.globalData.openid) === -1) {
      wx.showToast({ title: '对不起，您没有添加权限。', icon: 'none' });
      return;
    }
    wx.chooseMessageFile({
      count: 1,
      type: 'all',
      success(res) {
        console.log("chooseMessageFile:", res)
        const tempFilePath = res.tempFiles[0].path
        const tempFileName = res.tempFiles[0].name
        const setTempFileName = new Date().valueOf() + res.tempFiles[0].name
        console.log('choose: ', res, tempFileName)
        wx.showLoading({
          title: '加载中...',
          icon: 'none'
        })
        _this.setData({
          size: util.getFileSize(res.tempFiles[0].size)
        })
        const savePath = _this.data.projectInfo._id + '/'
        wx.cloud.uploadFile({
          cloudPath: savePath + setTempFileName,
          filePath: tempFilePath,
          success: res => {
            _this.saveFileToDB(res.fileID, tempFileName)
          },
          fail: res => {
            wx.showToast({
              title: '失败',
              icon: 'warn',
              duration: 2000
            })
          }
        })
      },
      fail: res => {
        console.log(res)
      }
    })
  },
  /**
   * 获取文件的下载链接
   */
  saveFileToDB: function (fileID, tempFileName) {
    let _this = this
    let layer = 0;//层级
    let folderNode = null;//直接所属文件夹
    let allFolderNode = [];//所有所属文件夹
    let membersId = _this.data.projectInfo.members;//项目成员
    let proNode = [_this.data.projectInfo._id];//所属项目
    let companysId = _this.data.projectInfo.companys;//所属公司
    let addPermission = _this.data.projectInfo.addPermission;
    let deletePermission = _this.data.projectInfo.deletePermission;
    let modifyPermission = _this.data.projectInfo.modifyPermission;
    wx.showLoading({
      title: '上传中...',
    })
    //(fileID, tempFileName, _this, layer, folderNode, allFolderNode, proId)
    util.saveFileToDB(fileID, tempFileName, _this, layer,
      folderNode, allFolderNode, membersId, proNode, companysId, null, null,
      addPermission, deletePermission, modifyPermission);
  },
  /**
   * drawer
   */
  show: function (e) {
    var currentStatu = e.currentTarget.dataset.statu;
    this.util(currentStatu)
  },
  util: function (currentStatu) {
    var animation = wx.createAnimation({
      duration: 300,
      timingFunction: 'easy',
      delay: 0
    })
    this.animation = animation;

    animation.translateX(300).step();
    this.setData({
      animationData: animation.export()
    })

    var animationMask = wx.createAnimation({
      duration: 500,
      delay: 0
    })
    animationMask.opacity(0).step();
    this.setData({
      animationMask: animationMask.export()
    })
    setTimeout(function () {
      animationMask.opacity(0.4).step()
      this.setData({
        animationMask: animationMask
      })
      //close
      if (currentStatu == 'close') {
        this.setData({
          showRight: false
        })
      }
    }.bind(this), 100)

    setTimeout(function () {
      animation.translateX(0).step()
      this.setData({
        animationData: animation
      })

      //close
      if (currentStatu == 'close') {
        this.setData({
          showRight: false
        })
      }
    }.bind(this), 200)

    if (currentStatu == 'open') {
      this.setData({
        showRight: true
      })
    }

  },
  /**
   * 切换选项卡
   */
  tabclick: function (e) {
    let _this = this
    console.log(e.detail.index)
    this.setData({
      tabIndex: e.detail.index,
      editingFile: false,
      editingEvent: false
    });
    if (_this.data.tabIndex === 1) {
      console.log("--------------------------------加载文件信息-----------------------------------")
      const filesId = _this.data.filesId || [];
      let queryFiles = filesId.map(item => { return fileDB.doc(item).get() });
      Promise.all(queryFiles)
        .then(res => {
          let filesInfo = res.map(item => { return item.data });
          console.log("filesInfo: ", filesInfo)
          filesInfo.map(item => { return item.isRotate = false });
          _this.setData({ filesInfo: filesInfo || [] })
        })
      console.log("--------------------------------加载文件夹信息-----------------------------------")
      const foldersId = _this.data.foldersId || [];
      let queryFolders = foldersId.map(item => { return folderDB.doc(item).get() });
      Promise.all(queryFolders).then(res => {
        let foldersInfo = res.map(item => { return item.data });
        foldersInfo.map(item => { return item.isRotate = false })
        _this.setData({ foldersInfo: foldersInfo })
      })
    } 
    if (_this.data.tabIndex === 2) {
      console.log("--------------------------------加载日程信息-----------------------------------")
      wx.showLoading({title: '加载中...',})
      let eventsId = _this.data.eventsId || [];
      util.getEventInfo(_this, eventsId)
    }
    if (_this.data.tabIndex === 3) {
      let messagesInfo = _this.data.messages || [];
      let queryId = Array.from(new Set(messagesInfo.map(item => { return item.sender })));
      let queryMessageSender = queryId.map(item => { return userDB.doc(item).get() });
      let senderList = {}
      Promise.all(queryMessageSender).then(res => {
        res.map(item => { senderList[item.data._id] = item.data.name });
        messagesInfo = messagesInfo.map(item => { item.senderName = senderList[item.sender]; return item });
        console.log("messagesInfo: ", messagesInfo);
        _this.setData({ messagesInfo: messagesInfo || [], senderList: senderList })
      })
    }
  },
  /**
   * 显示全部 / 收起
   */
  showOngoing: function() {
    this.setData({
      showOngoing: !this.data.showOngoing
    });
    let l1_itemNum = this.data.showAwaiting ? this.data.tasksInfo[0].length : 2;
    let l2_itemNum = this.data.showOngoing ? this.data.tasksInfo[1].length : 2;
    this.getLabelInfo(l1_itemNum, l2_itemNum)
  },
  showAwaiting: function() {
    this.setData({
      showAwaiting: !this.data.showAwaiting
    });
    let l1_itemNum = this.data.showAwaiting ? this.data.tasksInfo[0].length : 2;
    let l2_itemNum = this.data.showOngoing ? this.data.tasksInfo[1].length : 2;
    this.getLabelInfo(l1_itemNum, l2_itemNum);
  },
  showDone: function() {
    this.setData({
      showDone: !this.data.showDone
    })
    let l1_itemNum = this.data.showAwaiting ? this.data.tasksInfo[0].length : 2;
    let l2_itemNum = this.data.showOngoing ? this.data.tasksInfo[1].length : 2;
    this.getLabelInfo(l1_itemNum, l2_itemNum)
  },
  actionTap: function () {
    let _this = this;
    wx.showActionSheet({
      itemList: ['新文件', '新文件夹'],
      success: res => {
        if (res.tapIndex === 0) {
          console.log('新文件')
          _this.uploadFile();
        } else if (res.tapIndex === 1) {
          console.log('新文件夹');
          _this.setData({
            createFolder: true
          })
        }
      }
    })
  },

  addFolder: function() {
    let administrator = this.data.projectInfo.addPermission.concat(this.data.projectInfo.deletePermission).concat(this.data.projectInfo.modifyPermission);
    if (administrator.indexOf(app.globalData.openid) === -1) {
      wx.showToast({ title: '对不起，您没有添加权限。', icon: 'none' });
      return;
    }
    this.setData({createFolder: true})
  },

  inputFolderName: function(e) {
    this.setData({
      folderName: e.detail.value
    })
  },
  updateProjectFields(folderId, proId){
    console.log("------------------------------updateProjectFields-----------------------------")
    const folders = wx.cloud.callFunction({
      name: 'projectUpdate',
      data: {
        addFolder: true,
        proId: proId,
        folderId: folderId
      }
    });
    console.log("folders: ", folders);
    this.data.tasksPromise.push(folders);
    const allfolders = wx.cloud.callFunction({
      name: 'projectUpdate',
      data: {
        addAllFolder: true,
        proId: proId,
        folderId: folderId
      }
    });
    console.log("allfolders: ", allfolders);
    this.data.tasksPromise.push(allfolders);
    console.log("tasksPromise： ", this.data.tasksPromise);
  },
  updateUserFields(folderId){
    console.log("------------------------------updateUserFields-----------------------------")
    const folders = wx.cloud.callFunction({
      name: 'userUpdate',
      data: {
        addFolder: true,
        userId: app.globalData.openid,
        folderId: folderId
      }
    });
    console.log("folders: ", folders);
    this.data.tasksPromise.push(folders);
    console.log("tasksPromise： ", this.data.tasksPromise);
  },
  updateCompanysFields(folderId, companysId){
    console.log("------------------------------updateCompanysFields-----------------------------")
    const files = companysId.map(companyId => {
      return wx.cloud.callFunction({
        name: 'companyUpdate',
        data: {
          addFolders: true,
          companyId: companyId,
          folderId: folderId
        }
      });
    })
    console.log("files: ", files);
    this.data.tasksPromise = this.data.tasksPromise.concat(files);
    console.log("tasksPromise: ", this.data.tasksPromise)
  },
  updateFolderFields(foldersId, parentFolderId, folderId){
    console.log("------------------------------updateFolderFields-----------------------------")
    const subfolders = wx.cloud.callFunction({
      name: 'folderUpdate',
      data: {
        addSubFolders: true,
        folderId: parentFolderId,
        subFolderId: folderId
      }
    });
    console.log("subfolders: ", subfolders);
    this.data.tasksPromise.push(subfolders);
    const folders = foldersId.map(item => {
      return wx.cloud.callFunction({
        name: 'folderUpdate',
        data: {
          addFolders: true,
          folderId: item,
          subFolderId: folderId
        }
      })
    });
    console.log("folders: ", folders);
    this.data.tasksPromise = this.data.tasksPromise.concat(folders);
    console.log("tasksPromise: ", this.data.tasksPromise)
  },
  createFolder: function(e) {
    let _this = this;
    let allfolderNode = [];//全部所属文件夹
    let folderNode = null;//直接所属文件夹
    wx.showLoading({
      title: '创建中...',
    })
    wx.cloud.callFunction({
      name: 'addDoc',
      data: {
        addFolder: true,
        data: {
          name: _this.data.folderName,//文件夹名称
          creator: app.globalData.openid,//创建者
          creationTime: new Date().valueOf(),//创建时间
          proNode: [_this.data.proId],//所属项目
          companys: _this.data.projectInfo.companys,//所属班级
          members: _this.data.projectInfo.members,//项目成员
          addPermission: Array.from(new Set(_this.data.projectInfo.addPermission).add(app.globalData.openid)),//添加内容权限
          deletePermission: Array.from(new Set(_this.data.projectInfo.deletePermission).add(app.globalData.openid)),//删除项目及其内容权限
          modifyPermission: Array.from(new Set(_this.data.projectInfo.modifyPermission).add(app.globalData.openid)),//修改内容权限
          layer: 0
        } 
      }
    }).then(res => {
      console.log(res);
      //记录所创建文件的id
      const folderId = res.result._id;
      _this.setData({ folderId: folderId, tasksPromise:[]});
      //更新项目表；projects: folders, allfolders;
      _this.updateProjectFields(folderId, _this.data.proId);
      //更新用户表；user: folders
      _this.updateUserFields(folderId);
      //更新班级表；companys: folders
      _this.updateCompanysFields(folderId, _this.data.projectInfo.companys);
      if (allfolderNode.length > 0 && folderNode) {
        //更新文件夹表；folders：subfolders, folders
        _this.updateFolderFields(allfolderNode, folderNode, folderId)
      }
      console.log("_this.data.tasksPromise.length:", _this.data.tasksPromise.length)
      Promise.all(_this.data.tasksPromise).then( res => {
        console.log(res);
        util.getFoldersInfo([folderId].concat(_this.data.foldersId || [])).then(res => {
          console.log("文件夹信息：", res);
          let foldersInfo = res.map(item => { return item.data });
          foldersInfo.map(item => { return item.isRotate = false })
          _this.setData({
            foldersInfo: foldersInfo,
            foldersId: foldersInfo.map(item => { return item._id })
          });
          wx.hideLoading()
          _this.setData({
            createFolder: false
          })
        })
      })
    })
  },
  closeMask: function () {
    this.setData({
      createFolder: false
    })
  },
  leaveEditFile: function() {
    console.log("退出编辑文件状态");
    // let filesInfo = this.data.filesInfo || []
    this.data.filesInfo.map(item => { return item.isRotate = false })
    this.data.foldersInfo.map(item => { return item.isRotate = false })
    this.setData({filesInfo: this.data.filesInfo,foldersInfo: this.data.foldersInfo})
    this.setData({editingFile: false})
  },
  enterEditFile: function() {
    console.log("进入编辑文件状态");
    this.setData({
      editingFile: true
    })
  },
  delfile: function(e) {
    let administrator = this.data.projectInfo.addPermission.concat(this.data.projectInfo.deletePermission).concat(this.data.projectInfo.modifyPermission);
    if (administrator.indexOf(app.globalData.openid) === -1) {
      wx.showToast({ title: '对不起，您没有删除权限。', icon: 'none' });
      return;
    }
    console.log("删除文件：", e);
    wx.showLoading({title: '删除中...'});
    let _this = this;
    const fileId = e.currentTarget.dataset.fileid;
    const proId = this.data.proId
    fileDB.doc(fileId).get().then(res => {
      let fileIDpath = res.data.fileID;
      let creatorId = res.data.creator;
      let folderNode = res.data.folderNode;
      let membersId = res.data.members;
      let companysId = res.data.companys;
      let proNode = res.data.proNode;
      let taskNode = res.data.taskNode || [];
      let eventNode = res.data.eventNode || [];
      _this.setData({ tasksDFilePromise: []});
      //未关联时
      if (taskNode.length === 0 && eventNode.length === 0 && proNode.length === 1) {
        //更新files：根据是否有关联判断是否删除记录
        _this.updateDFileField(fileId, fileIDpath, proId);
        //更新projects：files
        _this.updateDProjectsFiels(fileId, proId);
        //更新user：files
        _this.updateDUserFields(fileId, membersId);
        //更新companys：files
        _this.updateDComanyFields(fileId, companysId)
      } else {
        //更新files：关联文件只更新proNode节点
        _this.updateDFileField(fileId, null, proId);
        //更新projects
        _this.updateDProjectsFiels(fileId, proId);
        if (eventNode.length === 1 && taskNode.length === 0) {
          console.log("eventNode.length === 1 && taskNode.length === 0")
          _this.updateDTaskEventFields(fileId, taskNode, eventNode)
        } else if (eventNode.length === 0 && taskNode.length === 1) {
          console.log("eventNode.length === 0 && taskNode.length === 1")
          _this.updateDTaskEventFields(fileId, taskNode, eventNode)
        }
      }
      Promise.all(_this.data.tasksDFilePromise).then(res => {
        console.log("删除文件成功");
        wx.hideLoading();
        let filesInfo = _this.data.filesInfo.filter(item => { return item._id != fileId });
        _this.setData({
          filesInfo: filesInfo,
          filesId: filesInfo.map(item => { return item._id })
        })
      })
    })
  },
  updateDFileField(fileId, filePath, proId){
    console.log("-------------------------------updateDFFilesFields-----------------------------");
    if (filePath) {
      //删除没有关联的文件
      const deleteunlinkfiles = wx.cloud.deleteFile({
        fileList: [filePath]
      });
      this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(deleteunlinkfiles);
      console.log("deleteunlinkfiles: ", deleteunlinkfiles);
      //删除记录
      let removeFiles = wx.cloud.callFunction({
        name: 'fileUpdate',
        data: {
          removeFile: true,
          fileId: fileId,
        }
      });
      this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(removeFiles);
      console.log("removeFiles: ", removeFiles);
      console.log("  this.data.tasksDFilePromise ", this.data.tasksDFilePromise)
      return;
    }    
    //对关联的文件linkFiles，移除本项目节点
    let proNode = wx.cloud.callFunction({
      name: 'fileUpdate',
      data: {
        removeProNode: true,
        fileId: fileId,
        proId: proId
      }
    });
    this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(proNode);
    console.log("proNode: ", proNode);
    console.log("  this.data.tasksDFilePromise ", this.data.tasksDFilePromise)
  },
  updateDProjectsFiels(fileId, proId) {
    console.log("-------------------------------------updateDProjectsFiels-----------------------------------")
    const files = wx.cloud.callFunction({
      name: 'projectUpdate',
      data: {
        removeFile: true,
        proId: proId,
        fileId: fileId
      }
    });
    console.log("files: ", files);
    this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(files);
    console.log("this.data.tasksDFilePromise: ", this.data.tasksDFilePromise);
  },
  updateDUserFields(fileId, membersId) {
    console.log("-------------------------------------updateDUserFields-----------------------------------")
    const files = membersId.map(item => {
      return wx.cloud.callFunction({
        name:'userUpdate',
        data: {
          removeFile: true,
          userId: item,
          fileId: fileId
        }
      })
    });
    console.log("files: ", files);
    this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(files);
    console.log("this.data.tasksDFilePromise: ", this.data.tasksDFilePromise);
  },
  updateDComanyFields(fileId, companysId) {
    console.log("----------------------------------updateDComanyFields--------------------------------------------");
    const files = companysId.map(item => {
      return wx.cloud.callFunction({
        name: 'companyUpdate',
        data: {
          removeFiles: true,
          companyId: item,
          fileId: fileId
        }
      })
    });
    console.log("files: ", files);
    this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(files);
    console.log("this.data.tasksDFilePromise: ", this.data.tasksDFilePromise);
  },
  updateDTaskEventFields(fileId, tasksId, eventsId) {
    console.log("-------------------------------updateDTaskEventFields--------------------------------------");
    const tasksprivateFiles = tasksId.map(item => {
      return wx.cloud.callFunction({
        name: 'taskUpdate',
        data: {
          addPrivateFiles: true,
          taskId: item,
          fileId: fileId
        }
      })
    });
    console.log("tasksprivateFiles: ", tasksprivateFiles);
    this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(tasksprivateFiles);
    const eventprivateFiles = eventsId.map(item => {
      return wx.cloud.callFunction({
        name: 'eventUpdate',
        data: {
          addPrivateFiles: true,
          eventId: item,
          fileId: fileId
        }
      })
    });
    console.log("eventprivateFiles: ", eventprivateFiles);
    this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(eventprivateFiles);
    console.log("this.data.tasksDFilePromise: ", this.data.tasksDFilePromise);
  },
  // updateDFolderFields(fileId, ){},

  delfolder: function (e) {
    console.log("删除文件夹：", e);
    wx.showLoading({
      title: '删除中...',
    })
    let _this = this;
    const folderId = e.currentTarget.dataset.folderid;
    const proId = this.data.proId
    folderDB.doc(folderId).get().then(res => {
      let layer = res.data.layer;//文件夹层级
      let creator = res.data.creator;//文件夹创建者
      let projectsId = res.data.proNode;//所属项目
      let companysId = res.data.companys;//所属班级
      let tasksId = res.data.taskNode || [];//所属任务
      let eventsId = res.data.eventNode || []; //所属日程
      let membersId = res.data.members;//成员
      let files = res.data.files || [];//全部子文件
      let folders = res.data.folders || [];//全部子文件夹；
      let parentFolders = res.data.allfolderNode || [];//全部父文件夹
      let unlinkfolders = (tasksId.length === 0 && eventsId.length === 0 && projectsId.length === 1) ? [folderId] : [];
      let linkfolders = (tasksId.length != 0 || eventsId.length != 0 || projectsId.length > 1) ? [folderId] : [];
      console.log("unlinkfolders: ", unlinkfolders);
      console.log("linkfolders: ", linkfolders);
      let unlinkfiles = [];
      let unlinkfilesPath = [];
      let linkfiles = [];
      let queryFoldersTask = folders.map(item => {return folderDB.doc(item).get()});
      Promise.all(queryFoldersTask).then(res => {
        let result = res.map(item => {
          let subId = item.data._id;//子文件夹的id
          let taskNode = item.data.taskNode;//子文件夹的关联任务
          let eventNode = item.data.eventNode;//子文件夹的关联日程
          let proNode = item.data.proNode;//子文件夹所属项目，若长度大于1，则表示该文件夹属于别的项目，从而不能删除，只能移除
          if ((!taskNode || taskNode.length === 0) && (!eventNode || eventNode.length === 0) && proNode.length === 1) {
            unlinkfolders.push(subId);//没有任何关联的文件夹
          } else {
            linkfolders.push(subId)//存在关联的文件夹
          };
        });
        console.log("unlinkfolders: ", unlinkfolders);
        console.log("linkfolders: ", linkfolders);
        //查询该文件夹中所有文件的关联性
        let queryFilesTask = files.map(item => { return fileDB.doc(item).get() });
        Promise.all(queryFilesTask).then(res => {
          let fileresult = res.map(item => {
            let fileId = item.data._id;//子文件的id
            let filePath = item.data.fileID;//子文件的存储位置
            let filetaskNode = item.data.taskNode;//子文件的关联任务
            let fileeventNode = item.data.eventNode;//子文件的关联日程
            let fileproNode = item.data.proNode;//子文件所属项目，若长度大于1，则表示该文件夹属于别的项目，从而不能删除，只能移除
            if ((!filetaskNode || filetaskNode.length === 0) && (!fileeventNode || fileeventNode.length === 0)) {
              unlinkfiles.push(fileId);//没有任何关联的文件
              unlinkfilesPath.push(filePath);
            } else {
              linkfiles.push(fileId)//存在关联的文件
            };
          });
          console.log("unlinkfiles: ", unlinkfiles);
          console.log("linkfiles: ", linkfiles);
          console.log("unlinkfilesPath :", unlinkfilesPath)
          _this.setData({ tasksDFPromise: []});
          //更新文件夹表
          _this.updateDFFolderFields(linkfolders, unlinkfolders, files, parentFolders, proId);
          //更新用户表；只删除非关联文件的id
          _this.updateDFUsersFields(unlinkfolders, unlinkfiles, membersId);
          //更新文件表；删除非关联文件/删除关联文件的proNode节点
          _this.updateDFFilesFields(linkfiles, unlinkfiles, unlinkfilesPath, proId);
          //更新项目表; 删除关联文件及非关联文件的id
          _this.updateDFProjects(files, [folderId].concat(folders), proId);
          //更新班级表；删除非关联文件的id
          _this.updateDFCompanysFileds(unlinkfiles, unlinkfolders, companysId);
          Promise.all(_this.data.tasksDFPromise).then(res => {
            console.log("删除文件夹成功");
            wx.hideLoading();
            let foldersInfo = _this.data.foldersInfo.filter(item => { return item._id != folderId });
            _this.setData({
              foldersInfo: foldersInfo,
              foldersId: foldersInfo.map(item => { return item._id })
            })
          })
        })
      })
    })
  },

  updateDFFolderFields(linkfoldersId, unlinkfoldersId, filesId, parentFoldersId, proId){
    console.log("-------------------------------updateDFFolderFields-----------------------------");
    //对没有关联的文件夹unlinkfoldersId，删除记录
    let removeUnlinkFolders = unlinkfoldersId.map(item => {
      return wx.cloud.callFunction({
        name: 'folderUpdate',
        data: {
          removeFolder: true,
          folderId: item
        }
      })
    });
    this.data.tasksDFPromise = this.data.tasksDFPromise.concat(removeUnlinkFolders);
    console.log("removeUnlinkFolders: ", removeUnlinkFolders);
    //对关联的文件夹linkfoldersId，移除本项目节点
    let proNode = linkfoldersId.map(item => {
      return wx.cloud.callFunction({
        name: 'folderUpdate',
        data: {
          removeProNode: true,
          folderId: item,
          proId: proId
        }
      })
    });
    this.data.tasksDFPromise = this.data.tasksDFPromise.concat(proNode);
    console.log("proNode: ", proNode);
    //在上一级父文件夹中 移除所有的关联的不关联的节点
    let allfoldersId = linkfoldersId.concat(unlinkfoldersId);
    let folders = []
    parentFoldersId.forEach(parentFolderId => {
      allfoldersId.map(item => {
        folders.push(wx.cloud.callFunction({
          name: 'folderUpdate',
          data: {
            removeSubFolder: true,
            folderId: parentFolderId,
            subFolderId: item
          }
        }));
      }) 
    });
    this.data.tasksDFPromise = this.data.tasksDFPromise.concat(folders);
    console.log("folders: ", folders);
    //删除父文件夹下，关联的和非关联的文件节点
    let files = []
    parentFoldersId.forEach(parentFolderId => {
      filesId.map(item => {
        files.push(wx.cloud.callFunction({
          name: 'folderUpdate',
          data: {
            removeFile: true,
            folderId: parentFolderId,
            fileId: item
          }
        }));
      })
    });
    this.data.tasksDFPromise = this.data.tasksDFPromise.concat(files);
    console.log("files: ", files);
    console.log("this.data.tasksDFPromise: ", this.data.tasksDFPromise);
  },
  updateDFUsersFields (foldersId, filesId, membersId) {
    console.log("-------------------------------updateDFUsersFields-----------------------------");
    let folders = [];
    foldersId.forEach(folderId => {
      membersId.map(item => {
        folders.push(wx.cloud.callFunction({
          name: 'userUpdate',
          data: {
            removeFolder: true,
            userId: item,
            folderId: folderId
          }
        }))
      })
    })
    this.data.tasksDFPromise = this.data.tasksDFPromise.concat(folders);
    console.log("folders: ", folders);
    let files = [];
    filesId.forEach(fileId => {
      membersId.map(item => {
        files.push(wx.cloud.callFunction({
          name: 'userUpdate',
          data: {
            removeFile: true,
            userId: item,
            fileId: fileId
          }
        }))
      })
    })
    this.data.tasksDFPromise = this.data.tasksDFPromise.concat(files);
    console.log("files: ", files);
    console.log("this.data.tasksDFPromise: ", this.data.tasksDFPromise);
  },
  updateDFFilesFields(linkFiles, unlinkFiles, unlinkFilesPath, proId) {
    console.log("-------------------------------updateDFFilesFields-----------------------------");
    //删除没有关联的文件
    const deleteunlinkfiles = wx.cloud.deleteFile({
      fileList: unlinkFilesPath
    });
    this.data.tasksDFPromise = this.data.tasksDFPromise.concat(deleteunlinkfiles);
    console.log("deleteunlinkfiles: ", deleteunlinkfiles);
    //删除files的记录 unlinkfiles
    const removeFile = unlinkFiles.map(item => {
      return wx.cloud.callFunction({
        name: 'fileUpdate',
        data: {
          removeFile: true,
          fileId: item,
        }
      })
    })
    this.data.tasksDFPromise = this.data.tasksDFPromise.concat(removeFile);
    console.log("removeFile: ", removeFile);
    //对关联的文件linkFiles，移除本项目节点
    let proNode = linkFiles.map(item => {
      return wx.cloud.callFunction({
        name: 'fileUpdate',
        data: {
          removeProNode: true,
          fileId: item,
          proId: proId
        }
      })
    });
    this.data.tasksDFPromise = this.data.tasksDFPromise.concat(proNode);
    console.log("proNode: ", proNode);
  },
  updateDFProjects(filesId, foldersId, proId) {
    console.log("-------------------------------updateDFProjects-----------------------------");
    let files = filesId.map(item => {
      return wx.cloud.callFunction({
        name: 'projectUpdate',
        data: {
          removeFile: true,
          proId: proId,
          fileId: item
        }
      })
    });
    this.data.tasksDFPromise = this.data.tasksDFPromise.concat(files);
    console.log("files: ", files);
    let folders = foldersId.map(item => {
      return wx.cloud.callFunction({
        name: 'projectUpdate',
        data: {
          removeFolder: true,
          proId: proId,
          folderId: item
        }
      })
    });
    this.data.tasksDFPromise = this.data.tasksDFPromise.concat(folders);
    console.log("folders: ", folders);
    console.log("this.data.tasksDFPromise: ", this.data.tasksDFPromise);
  },
  updateDFCompanysFileds(filesId, foldersId, companysId) {
    console.log("-------------------------------updateDFCompanysFileds-----------------------------");
    let files = []
    companysId.forEach(companyId => {
      filesId.map(item => {
        files.push(wx.cloud.callFunction({
          name: 'companyUpdate',
          data: {
            removeFiles: true,
            companyId: companyId,
            fileId: item
          }
        }))
      });
    })
    this.data.tasksDFPromise = this.data.tasksDFPromise.concat(files);
    console.log("files: ", files);
    let folders = []
    companysId.forEach(companyId => {
      foldersId.map(item => {
        folders.push(wx.cloud.callFunction({
          name: 'companyUpdate',
          data: {
            removeFolders: true,
            companyId: companyId,
            folderId: item
          }
        })) 
      });
    })
    this.data.tasksDFPromise = this.data.tasksDFPromise.concat(folders);
    console.log("folders: ", folders);
    console.log("this.data.tasksDFPromise: ", this.data.tasksDFPromise);
  },

  delEvent: function(e) {
    console.log("删除日程：", e);
    
    let _this = this;
    const eventId = e.currentTarget.dataset.eventid;
    eventDB.doc(eventId).get().then(res => {
      let administrator = res.data.creator;
      if (administrator != app.globalData.openid) {
        wx.showToast({ title: '对不起，您没有删除权限。', icon: 'none' });
        return;
      }
      wx.showLoading({title: '删除中...',})
      let projectsId = res.data.proNode;//所属项目
      let companysId = res.data.companys;//所属班级
      let membersId = res.data.members;//日程成员
      let foldersId = res.data.folders ? res.data.folders : [];//所关联的文件夹
      let privateFilesId = res.data.privatefiles ? res.data.privatefiles : [];//专属文件
      let filesId = res.data.files ? res.data.files.filter(item => {return privateFilesId.indexOf(item) === -1}) : [];//其他关联文件
      let queryFilesPathTask = privateFilesId.map(item => {return fileDB.doc(item).get()});
      Promise.all(queryFilesPathTask).then(res => {
        let privateFilesIdPath = res.map(item => {return item.data.fileID});
        _this.setData({ deleteEventPromise: []});
        //更新日程表；events：remove()
        _this.updateDelEventFields(eventId);
        //更新项目表；projects：events
        _this.updateDelProjectFields(eventId, projectsId);
        //更新班级表；companys: events
        _this.updateDelCompanyFields(eventId, companysId);
        //更新文件表; eventNode
        _this.updateDelFileFields(privateFilesId, privateFilesIdPath, filesId, eventId);
        //更新文件夹表；eventNode
        _this.updateDelFolderFields(foldersId, eventId);
        //更新用户表；user：events
        _this.updateDelUserFields(membersId, eventId)
        Promise.all(_this.data.deleteEventPromise).then(res => {
          console.log("删除日程成功:", res);
          let eventsId = _this.data.eventsId.filter(item => { return item != eventId });
          _this.setData({
            eventsId: eventsId
          });
          util.getEventInfo(_this, eventsId);
          wx.hideLoading()
        })
      })
    })
  },
  updateDelEventFields(eventId){
    console.log('-----------------------------------updateEventFields----------------------------------------')
    const removeEvent = wx.cloud.callFunction({
      name: 'eventUpdate',
      data: {
        removeEvent: true,
        eventId: eventId
      }
    });
    console.log("removeEvent: ", removeEvent)
    this.data.deleteEventPromise.push(removeEvent);
    console.log("this.data.deleteEventPromise: ", this.data.deleteEventPromise)
  },
  updateDelProjectFields(eventId, projectsId) {
    console.log('-----------------------------------updateProjectFields----------------------------------------')
    const events = projectsId.map(proId => {
      return wx.cloud.callFunction({
        name: 'projectUpdate',
        data: {
          removeEvent: true,
          proId: proId,
          eventId: eventId
        }
      })
    });
    console.log("events: ", events)
    this.data.deleteEventPromise = this.data.deleteEventPromise.concat(events);
    console.log("this.data.deleteEventPromise: ", this.data.deleteEventPromise)
  },
  updateDelCompanyFields(eventId, companysId) {
    console.log('-----------------------------------updateCompanyFields----------------------------------------')
    const events = companysId.map(companyId => {
      return wx.cloud.callFunction({
        name: 'companyUpdate',
        data: {
          removeEvents: true,
          companyId: companyId,
          eventId: eventId
        }
      })
    });
    console.log("events: ", events)
    this.data.deleteEventPromise = this.data.deleteEventPromise.concat(events);
    console.log("this.data.deleteEventPromise: ", this.data.deleteEventPromise)
  },
  updateDelFileFields(privateFilesId, privateFilesIdPath, filesId, eventId) {
    console.log('-----------------------------------updateFileFields----------------------------------------')
    //删除私有文件
    const removePrivateFiles = privateFilesId.map(item => {
      return wx.cloud.callFunction({
        name: 'fileUpdate',
        data: {
          removeFile: true,
          fileId: item
        }
      });
    });
    console.log("removePrivateFiles: ", removePrivateFiles);
    this.data.deleteEventPromise = this.data.deleteEventPromise.concat(removePrivateFiles);
    const deletePrivateFiles = wx.cloud.deleteFile({
      fileList: privateFilesIdPath
    });
    this.data.deleteEventPromise.push(deletePrivateFiles);
    //更新其他文件的eventNode
    const eventNode = filesId.map(item => {
      return wx.cloud.callFunction({
        name: 'fileUpdate',
        data: {
          removeEventNode: true,
          fileId: item,
          eventId: eventId
        }
      })
    })
    console.log("eventNode: ", eventNode);
    this.data.deleteEventPromise = this.data.deleteEventPromise.concat(eventNode);
    console.log("this.data.deleteEventPromise: ", this.data.deleteEventPromise)
  },
  updateDelFolderFields(foldersId, eventId) {
    console.log('-----------------------------------updateFolderFields----------------------------------------')
    const eventNode = foldersId.map(item => {
      return wx.cloud.callFunction({
        name: 'folderUpdate',
        data: {
          removeEventNode: true,
          folderId: item,
          eventId: eventId
        }
      })
    })
    console.log("eventNode: ", eventNode);
    this.data.deleteEventPromise = this.data.deleteEventPromise.concat(eventNode);
    console.log("this.data.deleteEventPromise: ", this.data.deleteEventPromise)
  },
  updateDelUserFields(membersId, eventId){
    console.log("-----------------------------------------updateDelUserFields------------------------------------");
    const events = membersId.map(item => {
      return wx.cloud.callFunction({
        name: 'userUpdate',
        data: {
          removeEvents: true,
          userId: item,
          eventId: eventId
        }
      });

    });
    console.log("events: ", events);
    this.data.deleteEventPromise = this.data.deleteEventPromise.concat(events);
    console.log("this.data.deleteEventPromise: ", this.data.deleteEventPromise)
  },
  rotateBtn: function(e) {
    console.log("旋转按钮");
    const dataset = e.currentTarget.dataset;
    console.log(dataset)
    let filesInfo = this.data.filesInfo || [];
    let foldersInfo = this.data.foldersInfo || [];
    let eventsInfoGroup = this.data.eventsInfoGroup || [];
    if (dataset.fileid) {
      const fileid = dataset.fileid
      const index = filesInfo.indexOf(filesInfo.filter(item => { return item._id === fileid })[0]);
      console.log(index);
      filesInfo[index].isRotate = !filesInfo[index].isRotate;
      filesInfo.filter(item => { return item._id != fileid }).map(item => { return item.isRotate = false})
      foldersInfo.map(item => { return item.isRotate = false })
    } else if (dataset.folderid) {
      const folderid = dataset.folderid
      const index = foldersInfo.indexOf(foldersInfo.filter(item => { return item._id === folderid })[0]);
      console.log(index);
      foldersInfo[index].isRotate = !foldersInfo[index].isRotate;
      foldersInfo.filter(item => { return item._id != folderid }).map(item => { return item.isRotate = false })
      filesInfo.map(item => { return item.isRotate = false })
    } else if (dataset.eventid) {
      const eventId = dataset.eventid;
      const groupDate = dataset.date;
      console.log(eventId, groupDate);
      let groupEventsInfo = eventsInfoGroup.filter(item => { return item.date === groupDate})[0].eventsInfo;
      console.log("groupEventsInfo: ", groupEventsInfo);
      let index = groupEventsInfo.indexOf(groupEventsInfo.filter(item => {return item._id === eventId})[0]);
      console.log(index);
      eventsInfoGroup.filter(item => { return item.date === groupDate })[0].eventsInfo[index].isRotate = 
      !eventsInfoGroup.filter(item => { return item.date === groupDate })[0].eventsInfo[index].isRotate;
      eventsInfoGroup.map(item => {
        if (item.date != groupDate) {
          item.eventsInfo.map(item => {return item.isRotate = false});
        } else {
          item.eventsInfo.filter(item => { return item._id != eventId }).map(item => { return item.isRotate = false })
        }
      })
      console.log("true: ", eventsInfoGroup)
    }
    this.setData({
      filesInfo: filesInfo,
      foldersInfo: foldersInfo,
      eventsInfoGroup: eventsInfoGroup
    })
  },
  // edit event
  leaveEditEvent: function() {
    console.log("退出编辑日程状态");
    this.data.eventsInfoGroup.map(item => {item.eventsInfo.map(item => { return item.isRotate = false });})
    this.setData({ eventsInfoGroup: this.data.eventsInfoGroup});
    this.setData({editingEvent: false})
  },
  enterEditEvent: function () {
    console.log("进入编辑日程状态");
    this.setData({
      editingEvent: true
    })
  },
  viewMember() {
    console.log("viewMember");
    let projectId = this.data.projectInfo._id;
    wx.navigateTo({ url: '../wlinkman/wlinkman?projectId=' + projectId })
  },
  inputSend(e) {
    let value = e.detail.value;
    let deleteContent = this.data.content > e.detail.value;
    this.setData({ content: value });
    if (this.data.content === '') { this.setData({ disable: true }) } else { this.setData({ disable: false }) }
    if (this.data.content.slice(-1) === "@") {
      console.log("提示弹窗");
      let start = this.data.content.length;
      this.setData({ displayNotice: true, startPosition: start})
      console.log("startPosition: ", this.data.startPosition)
    } else {
      console.log("关闭弹窗");
      this.setData({ displayNotice: false })
    }
    if (deleteContent) {
      let noticeObj = this.data.noticeObj;
      for (let i in noticeObj) {
        console.log(noticeObj[i])
        if (value.indexOf(noticeObj[i].name) === -1) {
          console.log("replace: ", noticeObj[i].name, noticeObj[i].name.slice(0, -1))
          let newContent = value.replace(noticeObj[i].name.slice(0, -1), "");
          console.log("newContent: ", newContent);
          let newNoticeObj = this.data.noticeObj.filter((ele, index) => {return index != i})
          this.setData({ content: newContent, displayNotice: false, noticeObj: newNoticeObj});
          return;
        }
      }
    }
  },
  saveMessage() {
    let _this = this;
    this.setData({height: 0 })
    let messagesInfo = _this.data.messagesInfo || []
    let currentTime = new Date().valueOf();
    let timeObj = util.getTimeInfo(currentTime);
    let sendTime = timeObj.year + '-' + timeObj.month + '-' + timeObj.day + ' ' + timeObj.hour + ':' + timeObj.minute;
    let message = { sender: app.globalData.openid, content: this.data.content, sendTime: sendTime, timestamp: currentTime }
    wx.cloud.callFunction({ 
      name: "projectUpdate", 
      data: { addMessage: true, proId: _this.data.projectInfo._id, message: message } 
    })
      .then(res => {
        console.log("保存成功", res, message);
        _this.setData({ content: '' });
        if (this.data.content === '') { this.setData({ disable: true }) } else { this.setData({ disable: false }) }
        messagesInfo.push(message);
        _this.setData({ messagesInfo: messagesInfo, toIndex: `A${message.timestamp}`});
        let noticeId = _this.data.noticeObj.map(item => { return item.userId});
        let noticeTime = util.formatDate(new Date());
        let sender = _this.data.user.name;
        console.log("noticeId: ", noticeId)
        let noticePromise = noticeId.map(item => { return w.requestSendTemplete(item, sender, noticeTime)});
        console.log("noticePromise: ", noticePromise);
        Promise.all(noticePromise).then(res => {
          console.log(res)
        })
      })
  },
  bindkeyboardheightchange: function (e) {
    console.log(e);
    const height = e.detail.height;
    if (height > this.data.height || height === 0) {
      this.setData({height: height});
    }
    console.log("height: ", height, this.data.height)
  },
  selectNoticeMem(e) {
    let userName = e.currentTarget.dataset.name;
    if (userName.length === 1) {userName = ' ' + userName +' '};
    let userId = e.currentTarget.dataset.id;
    this.setData({ displayNotice: false });
    const content = this.data.content;
    this.data.noticeObj[this.data.noticeObj.length] = { 'name': `@${userName}`, 'userId': userId};
    console.log(this.data.noticeObj);
    this.setData({noticeObj: this.data.noticeObj})
    const newContent = content + userName + ' ';
    this.setData({ content: newContent, endPosition: newContent.length});
    console.log("endPosition: ", this.data.endPosition)
    this.setData({ height: 0, isFocus: true})
  }
})