// pages/wlog/wlog.js
let app = getApp()
import { basePage } from '../../util/basePage.js'
//获取数据库引用 
const db = wx.cloud.database();
const userDB = db.collection('user')
let phone = null
let password = null
Page({
  data: {
    title: "登录",
    phone: null,
    password: null,
    capsuleInfo: app.globalData.capsuleInfo
  },

  inputPhone: function(e) {
    this.setData({
      phone: e.detail.value
    })
  },

  inputPassword: function (e) {
    this.setData({
      password: e.detail.value
    })
  },
  goBack: function () {
    wx.navigateBack()
  }, 

  login: function() {
    let _this = this;
    if(_this.data.phone === null && _this.data.password === null) {
      return
    }

    //登录获取用户信息
    userDB.doc(app.globalData.openid).get().then(res => {
      let userInfo = res.data;
      console.log(res.data)
      if (userInfo.phone !== _this.data.phone) {
        wx.showToast({
          title: '手机号不匹配',
        })
      } else if (userInfo.password !== _this.data.password) {
        wx.showToast({
          title: '密码错误',
        })
      } else {
        wx.showToast({ 
          title: '登录成功',
        })
        //更新登录状态
        app.globalData.login = true;
        wx.switchTab({
          url: '../wmine/wmine',
        })
        // if (res.data.companys && res.data.companys.length > 0) {
        // } else {
        //   wx.redirectTo({
        //     url: '../wtip/wtip',
        //   })
        // }
      }
    })
  },
  
  goRegister: function() {
    console.log("前往注册界面！")
    wx.navigateTo({
      url: '../wregister/wregister',
    })
  },
  
  onLoad: function (options) {
    const _this = this
    userDB.doc(app.globalData.openid).get({
      success: res => {
        console.log("自动填充该用户的信息！", res.data)
        _this.setData({
          phone: res.data.phone,
          password: res.data.password
        })
      }
    })
  },
})

