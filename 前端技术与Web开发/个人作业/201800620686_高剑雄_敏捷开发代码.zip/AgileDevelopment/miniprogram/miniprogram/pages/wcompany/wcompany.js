// pages/wcompany/wcompany.js
const app = getApp(); 
const util = require("../../util/wutils.js");
const wremove = require("../../util/wremove.js");
const images = require("../../util/images.js")
const db = wx.cloud.database();
const userDB = db.collection('user')
const companyDB = db.collection('companys')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
const eventDB = db.collection('events')
const fileDB = db.collection('files')

Page({

  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    currentCompany: null,
    isLogin: app.globalData.login,
    images: images,
    screenHeight: app.globalData.screenHeight,//屏幕高度，单位px
    screenWidth: app.globalData.screenWidth,
    navigatorH: app.globalData.navigatorH,//
    statusBarHeight: app.globalData.statusBarHeight,//状态栏的高度，单位px
  },

  onLoad: function (options) {
    let _this = this
    this.setData({
      isLogin: app.globalData.login
    })
  },
  onShow(){
    let _this = this
    userDB.doc(app.globalData.openid).get().then(res => {
      if (res.data.companys) {
        if (!app.globalData.currentCompany) {
          console.log("设置初始值")
          app.globalData.currentCompany = res.data.companys[0];
        }
        _this.setData({ currentCompany: app.globalData.currentCompany })
      }
      _this.setData({ companysId: res.data.companys || [] })
      let queryCompanys = this.data.companysId.map(item => { return companyDB.doc(item).get() });
      Promise.all(queryCompanys)
        .then(res => {
          let companysInfo = res.map(item => { return item.data });
          _this.setData({ companysInfo: companysInfo })
        }).catch(res => {
          console.log(res)
        });
    })
  },
  goBack: function() {
    wx.navigateBack({
      delta: 1
    })
  },
  createCompany: function() {
    wx.navigateTo({
      url: '../waddcompany/waddcompany',
    })
  },
  changeCompany: function(e) {
//添加内容----------------------------------------------------------------------------------------
    wx.cloud.callFunction({
      name: "companyUpdate",
      data: {
        removeMember:true,
        companyId: app.globalData.currentCompany,
        userId: app.globalData.openid,
      }
    })
    wx.cloud.callFunction({
      name: "companyUpdate",
      data: {
        addMember: true,
        companyId: e.currentTarget.dataset.companyid,
        userId: app.globalData.openid,
      }
    })
// ------------------原内容--------------------------------------
    if (this.data.editing) {return;}
    const companyId = e.currentTarget.dataset.companyid;
    console.log(companyId)
    app.globalData.currentCompany = companyId;
    app.globalData.scrollCompany = companyId
    this.setData({currentCompany: app.globalData.currentCompany}); 
    // wx.switchTab({url: '../wproject/wproject'})
// ------------------原内容--------------------------------------
  },
  leaveEdit: function () {
    console.log("退出编辑状态");
    this.data.companysInfo.map(item => { return item.isRotate = false })
    this.setData({ companysInfo: this.data.companysInfo})
    this.setData({ editing: false })
  },
  enterEdit: function () {
    console.log("进入编辑状态");
    this.setData({editing: true})
  },
  rotateBtn: function (e) {
    console.log("旋转按钮");
    const dataset = e.currentTarget.dataset;
    console.log(dataset)
    let companysInfo = this.data.companysInfo || [];
    if (dataset.companyid) {
      const companyid = dataset.companyid
      const index = companysInfo.indexOf(companysInfo.filter(item => { return item._id === companyid })[0]);
      console.log(index);
      companysInfo[index].isRotate = !companysInfo[index].isRotate;
      companysInfo.filter(item => { return item._id != companyid }).map(item => { return item.isRotate = false });
      this.setData({ companysInfo: companysInfo})
    }
  },
  deleteCompany(e){
    let _this = this;
    const companyid = e.currentTarget.dataset.companyid;  
    companyDB.doc(companyid).get().then(res => {
      console.log("companyInfo: ", res.data);
      let administrator = res.data.addPermission.concat(res.data.deletePermission).concat(res.data.modifyPermission);
      if (administrator.indexOf(app.globalData.openid) === -1) {
        wx.showToast({title: '对不起，您没有删除权限。', icon: 'none'});
        return;
      }
      wx.showLoading({ title: '删除中...', })
      let companyInfo = res.data;
      _this.setData({ _CtasksPromise: []})
      wremove.deleteCompany(companyInfo, _this.data._CtasksPromise, _this)
    })
  },
  viewMember(e) {
    console.log("viewMember");
    let companyid = e.currentTarget.dataset.companyid;
    console.log("companyid: ", companyid);
    let companysInfo = this.data.companysInfo;
    wx.navigateTo({ url: '../wlinkman/wlinkman?companyId=' + companyid})
  }
})