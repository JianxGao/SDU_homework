// pages/wtip/wtip.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  addCompany: function() {
    wx.redirectTo({
      url: '../waddcompany/waddcompany',
    })
  },
  logout: function() {
    wx.redirectTo({
      url: '../wlog/wlog'
    })
  },
  goBack: function () {
    wx.navigateBack()
  }, 

})