// pages/wlogMethod/wlogMethod.js
const images = require('../../util/images.js')
const app = getApp()
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
Page({
  /**
   * 页面的初始数据
   */
  data: {
    images: images,
    capsuleInfo: app.globalData.capsuleInfo
  },
  goBack: function () {
    wx.navigateBack()
  }, 

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.directly) {
      this.setData({
        directly: true
      })
    }
    userDB.doc(app.globalData.openid).get().then(res => {
      if (res.data) {
        console.log(res.data);
        this.setData({
          userInfo: res.data
        })
      }
    }).catch(res => {
      this.setData({
        isNew: true
      })
    })
  },
  wechatLog: function(e) {
    //如果是第一次登录
    if (this.data.isNew) {
      console.log(e)
      let userData = JSON.parse(e.detail.rawData);
      console.log(userData);
      let userInfo = {
        name: userData.nickName,
        // password: password,
        phone: "",
        mail: "",
        projects: [],
        userHeader: userData.avatarUrl
      };
      wx.cloud.callFunction({
        name: "addUser",
        data: {
          userId: app.globalData.openid,
          data: userInfo
        },
        success: res => {
          console.log("信息保存成功");
          //修改登录状态
          app.globalData.login = true
          console.log("修改登录状态")
          //跳转至我的界面
          if (this.data.directly) {
            wx.switchTab({
              url: '../wmine/wmine',
            });
            return;
          }
        },
        fail: res => {
          console.log(res)
        }
      })
    } else {
      //修改登录状态
      app.globalData.login = true
      console.log("修改登录状态")
      //跳转至我的界面
      if (this.data.directly) {
        wx.switchTab({
          url: '../wmine/wmine',
        });
        return;
      }
      wx.navigateBack({
        delay: 1,
        success: res => {
          console.log(res)
        }
      })
    }
  },
  userLog: function() {
    wx.navigateTo({
      url: '../wlog/wlog',
    })
  }
})