// pages/atest/atest.js
const util = require('../../util/wutils.js');
const wclass = require('../../util/wclass.js');
const {Wechat} = require('../../util/accessToken.js')
const w = new Wechat();
const {sendTemplete} = require('../../util/sendTemplete.js')
const { $Message } = require('../../components/base/index.js');
const app = getApp()
const db = wx.cloud.database();
const taskDB = db.collection('tasks')
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const _ = db.command
Page({
  data: {
    // x轴方向的偏移
    x: 0,
    // 当前x的值
    currentX: 0,
    items: [],
    startX: 0, //开始坐标
    startY: 0,
  
    actions2: [
      {
        name: '删除',
        color: '#ed3f14'
      }
    ],
  },
  handleCancel2() {
    this.setData({
      visible2: false,
      toggle: this.data.toggle ? false : true
    });
    console.log(this.data.toggle, 111111111)
  },
  handleClickItem2() {
    const action = [...this.data.actions2];
    action[0].loading = true;

    this.setData({
      actions2: action
    });

    setTimeout(() => {
      action[0].loading = false;
      this.setData({
        visible2: false,
        actions2: action,
        toggle: this.data.toggle ? false : true
      });

    }, 2000);
  },
  outerTap(){
    console.log("outerTap---------------------------------")
    
  },
  innerTap() {
    let _this = this
    console.log("innerTap---------------------------------");
    // userDB.doc(app.globalData.openid).get().then(res => {
    //   let tasksId = res.data.tasks;
    //   let tasksPromsie = tasksId.map(item => {return taskDB.doc(item).get()});
    //   Promise.all(tasksPromsie).then(res => {
    //     console.log(res);
    //     let tasksInfo = res.map(item => {return item.data});
    //     wclass.getTasksParentTaskName(tasksInfo, _this)
    //   })
    // })
    wx.cloud.callFunction({
      name: 'addFile',
      data: {
        userId:"oH7ua5RnzlS7aCUBBjAHpxP4Ij_0"
      }
    }).then(res => {
      console.log(res)
    })
  },
  tap2(){
    console.log("tap1===========================");
    w.reuqestSubscribMessage().then(res => { console.log(res);w.sendTemplete("oH7ua5aIhol25GEicLuG3roOKlaA", "sender", "2019-11-09") })
    
    // wx.requestSubscribeMessage({
    //   tmplIds: ['k0Fyyhv3eVsmVftmXcU4DyMrtULBW-4CNg64d_9PncI'],
    //   success: res => {
    //     console.log(res)
    //     // sendTemplete("oH7ua5aIhol25GEicLuG3roOKlaA", "sender", "2019-11-09");
    //     console.log(sendTemplete("oH7ua5aIhol25GEicLuG3roOKlaA", "sender", "2019-11-09"))
    //   },
    //   fail: res => {
    //     console.log(res)
    //    }
    // })
  },
  tap1() {
    console.log("tap2===========================");
    //27_WthRwO0-3TmVBm6_u_7wQubGngNk7gt-j1soxPKtqO8HM6HxWsPD1EnvW-FP2jFFRIkhxmNiWeJOZgdqWCFreBxVOKJEm-YnkHcKSvkR_GqFr2wfAhwpomQ9XNYc1vpkeJRO8FoSjBAFuMfrZSEfAEAOHT
    const w = new Wechat();
    // w.saveAccessToken({ access_token: '27_WthRwO0-3TmVBm6_u_7wQubGngNk7gt-j1soxPKtqO8HM6HxWsPD1EnvW-FP2jFFRIkhxmNiWeJOZgdqWCFreBxVOKJEm-YnkHcKSvkR_GqFr2wfAhwpomQ9XNYc1vpkeJRO8FoSjBAFuMfrZSEfAEAOHT', expires_in: 1573829115503}).then(res=> {console.log(res)});
    w.fetchAccessToken()
    .then(res => {
      console.log(res);
      let access_token = res.access_token;
      let fileID = 'cloud://mapp-5f3o8.6d61-mapp-5f3o8-1259747852/4a741dc95dcb549805f1f1dd5a9cd966/1573824147246dashline.png'
      util.fetchDownloadUrl(fileID,access_token).then(res => {
        console.log(res)
      })
    })
  },
  deleteTask: function() {
    wx.cloud.callFunction({
      name: 'userUpdate',
      data: {
        deleteExecutorTaskNode: true,
        userId: app.globalData.openid,
        taskId: "1c756ce65db5416700d5cc797efbb5fb"
      }
    })
  },
  actionsTap() {
    this.setData({
      visible2: true
    });
  },
  bindTap: function() {
    wx.cloud.callFunction({
      name: 'addFile',
      data: {
        uploadFile: true,
        fileName: 'atest.js',

      }
    })
  },
  /**
  * 上传文件
  */
  uploadFile: function () {
    let _this = this;
    wx.chooseMessageFile({
      count: 1,
      type: 'file',
      success(res) {
        const tempFilePath = res.tempFiles[0].path
        const tempFileName = res.tempFiles[0].name
        console.log('choose: ', res)
        _this.setData({
          size: util.getFileSize(res.tempFiles[0].size)
        })
        wx.cloud.uploadFile({
          cloudPath: tempFileName,
          filePath: tempFilePath,
          success: res => {
            // _this.getDownloadUrl(res.fileID, tempFileName)
            wx.showToast({
              title: '成功',
              icon: 'success',
              duration: 2000
            })
          },
          fail: res => {
            wx.showToast({
              title: '失败',
              icon: 'warn',
              duration: 2000
            })
          }
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    // wclass.getAllDoc()
    
    // for (var i = 0; i < 10; i++) {
    //   this.data.items.push({
    //     content: i + " 向左滑动删除哦,向左滑动删除哦,向左滑动删除哦,向左滑动删除哦,向左滑动删除哦",
    //     isTouchMove: false //默认全隐藏删除
    //   })
    // }
    // this.setData({
    //   items: this.data.items
    // })
  },

  touchstart: function (e) {
    //开始触摸时 重置所有删除
    this.data.items.forEach(function (v, i) {
      if (v.isTouchMove)//只操作为true的
        v.isTouchMove = false;
    })
    this.setData({
      startX: e.changedTouches[0].clientX,
      startY: e.changedTouches[0].clientY,
      items: this.data.items
    })
  },
  //滑动事件处理
  touchmove: function (e) {
    var that = this,
      index = e.currentTarget.dataset.index,//当前索引
      startX = that.data.startX,//开始X坐标
      startY = that.data.startY,//开始Y坐标
      touchMoveX = e.changedTouches[0].clientX,//滑动变化坐标
      touchMoveY = e.changedTouches[0].clientY,//滑动变化坐标
      //获取滑动角度
      angle = that.angle({ X: startX, Y: startY }, { X: touchMoveX, Y: touchMoveY });
    that.data.items.forEach(function (v, i) {
      v.isTouchMove = false
      //滑动超过30度角 return
      if (Math.abs(angle) > 30) return;
      if (i == index) {
        if (touchMoveX > startX) //右滑
          v.isTouchMove = false
        else //左滑
          v.isTouchMove = true
      }
    })
    //更新数据
    that.setData({
      items: that.data.items
    })
  },
  /**
   * 计算滑动角度
   * @param {Object} start 起点坐标
   * @param {Object} end 终点坐标
   */
  angle: function (start, end) {
    var _X = end.X - start.X,
      _Y = end.Y - start.Y
    //返回角度 /Math.atan()返回数字的反正切值
    return 360 * Math.atan(_Y / _X) / (2 * Math.PI);
  },
  //删除事件
  del: function (e) {
    this.data.items.splice(e.currentTarget.dataset.index, 1)
    this.setData({
      items: this.data.items
    })
  },
  //跳转
  goDetail() {
    console.log('点击元素跳转')
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let _this = this;
    // taskDB.get().then(res => {
      // let allTasksInfo = res.data;
      // _this.setData({
      //   allTasksInfo: allTasksInfo
      // });
      // console.log(res)
      // let allTasksInfo = util.sortInfobyDeadline(res.data);
      // console.log("allTasksInfo: ", allTasksInfo);
      // this.setData({ allTasksInfo: allTasksInfo})
    // })
  },
  sortArray(_TaskInfo) {
    _TaskInfo.filter(item => { return item.end !== null }).map(item => {
      return item.deadline = util.formatDate(item.end)
    })
    _TaskInfo.filter(item => { return item.end === null }).map(item => {
      return item.end = "2050-10-13"
    })
    //按截止时间排序
    _TaskInfo.sort((a, b) => new Date(a.end) - new Date(b.end))
    return _TaskInfo
  },
  getName() {
    let _this = this;
    // wclass.getProjectsTasksName(["83cc88815dbfe7eb0158a546143c6e0a", "83cc88815dbfe7eb0158a546143c6e0a"], _this)
    // wclass.getTasksParentTaskName(_this.data.allTasksInfo, _this)
    // wclass.getTasksProNodeName(_this.data.allTasksInfo, _this);
    wclass.getProjectsEventsName(["83cc88815dc166e301fb3c1b7aad797d", "83cc88815dc166e301fb3c1b7aad797d"], _this);
  }, 
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  testSubmit: function (e) {
    console.log(e)
    var self = this;
    let _access_token = '27_APjS0s1VI-M0JquGfDc5DQJo6u67KpEMrf0dQ0E_gp2YrNQuw15Gcd-rQHg4en6iOMw55753ynKl30Ci4CXuMo1ac29Kg7YMG6ZTTm2kIYCyRuiFqv8fXEIaMbUQAAiABALVV';
    let url = 'https://api.weixin.qq.com/cgi-bin/message/wxopen/template/send?access_token=' + _access_token; 
    let _jsonData = {
        access_token: _access_token,
        touser: "oH7ua5aIhol25GEicLuG3roOKlaA",
        template_id: 'bsNS1e4jyCFKMnrHTgDYPO70Ur4nqkEEOhGih-ovl8k',
        form_id: e.detail.formId,
        page: "pages/atest/atest",
        data: {
          "keyword1": { "value": "测试数据一", "color": "#173177" },
          "keyword2": { "value": "测试数据二", "color": "#173177" },
        }
      }
    wx.request({
      url: url,
      data: _jsonData,
      method: 'POST',
      success: function (res) {
        console.log(res)
      },
      fail: function (err) {
        console.log('request fail ', err);
      },
      complete: function (res) {
        console.log("request completed!");
      }

    })
  }
})