// pages/wprofile/wprofile.js
let app = getApp()
const images = require("../../util/images.js")
const permission = require("../../util/permission.js")
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const companyDB = db.collection('companys')
Page({
  goBack: function () {wx.navigateBack()}, 

  data: {
    isLogin: app.globalData.login,
    images: images,
    authority: true,
    capsuleInfo: app.globalData.capsuleInfo
  },

  onLoad: function (options) {
    let _this = this
    if (options.userId) { 
      this.setData({userId: options.userId})
      if (options.userId != app.globalData.openid) this.setData({ authority: false })
    }
    if (options.companyId) {
      this.setData({companyId: options.companyId, settingRole: true});
    }
    if (options.projectId) { this.setData({ projectId: options.projectId, settingRole: true})}
    this.setData({isLogin: app.globalData.login,})
    if (this.data.userId) {
      userDB.doc(this.data.userId).get().then(res => {
        console.log(res.data);
        _this.setData({userInfo: res.data,})
      });
    } else {
      userDB.doc(app.globalData.openid).get().then(res => {
        console.log(res.data);
        _this.setData({
          userInfo: res.data
        })
      })
    }
  },
  onShow(){
    let _this = this;
    if (this.data.companyId) {
      companyDB.doc(this.data.companyId).get().then(res => {
        let administrator = res.data.addPermission.concat(res.data.deletePermission).concat(res.data.modifyPermission);
        _this.setData({ administrator: administrator, companyInfo: res.data });
        if (administrator.indexOf(this.data.userId) != -1) { _this.setData({ switch1Checked: true }) }
        // 查看用户是否有修改权限
        if (administrator.indexOf(app.globalData.openid) === -1) { _this.setData({ settingRole: false }) }
      })
    }
    if (this.data.projectId) {
      projectDB.doc(this.data.projectId).get().then(res => {
        let administrator = res.data.addPermission.concat(res.data.deletePermission).concat(res.data.modifyPermission);
        _this.setData({ administrator: administrator, projectInfo: res.data });
        if (administrator.indexOf(this.data.userId) != -1) { _this.setData({ switch1Checked: true }) }
        // 查看用户是否有修改权限
        if (administrator.indexOf(app.globalData.openid) === -1) { _this.setData({ settingRole: false }) }
      })
    }
  },
  bindkeyboardheightchange: function(e) {
    // console.log(e);
    const height = e.detail.height;
    this.setData({
      height: height
    })
  },
  changeName: function() {
    this.setData({
      isChangeName: true
    })
  },
  changeMail: function() {
    this.setData({
      isChangeMail: true
    })
  },
  changePhone: function () {
    this.setData({
      isChangePhone: true
    })
  },
  inputName: function(e) {
    this.setData({
      name: e.detail.value
    })
    // console.log("修改：", this.data.name)
  },
  inputMail: function(e) {
    this.setData({
      mail: e.detail.value
    })
    // console.log("修改：", this.data.mail)
  },
  inputPhone: function (e) {
    this.setData({
      phone: e.detail.value
    })
    // console.log("修改：", this.data.mail)
  },
  cancelSaveName: function() {
    this.setData({
      isChangeName: false
    })
  },
  cancelSaveMail: function() {
    this.setData({
      isChangeMail: false
    })
  },
  cancelSavePhone: function () {
    this.setData({
      isChangePhone: false
    })
  },
  saveName: function() {
    let name = this.data.name;
    this.setData({
      "userInfo.name": name
    });
    let _this = this
    //更新用户表的信息
    wx.cloud.callFunction({
      name: 'userUpdate',
      data: {
        updateName: true,
        userId: app.globalData.openid,
        name: name
      }
    }).then(res => {
      console.log("修改成功");
      _this.setData({
        isChangeName: false
      })
    })
  },
  saveMail: function() {
    let mail = this.data.mail;
    var reg = /^([a-zA-Z0-9]+[_|_|.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|_|.]?)*[a-zA-Z0-9]+\.(?:com|cn)$/;
    if (!reg.test(mail)) {
      wx.showToast({
        title: '邮箱格式不正确',
        icon: 'none'
      });
      return;
    }
    this.setData({
      "userInfo.mail": mail
    });
    let _this = this;
    //更新用户表的信息
    wx.cloud.callFunction({
      name: 'userUpdate',
      data: {
        updateMail: true,
        userId: app.globalData.openid,
        mail: mail
      }
    }).then(res => {
      console.log("修改成功");
      _this.setData({
        isChangeMail: false
      })
    })
  },
  savePhone: function () {
    let phone = this.data.phone;
    var reg1 = /^\d{11,}$/;
    if (!reg1.test(phone)) {
      wx.showToast({
        title: '手机格式不正确',
        icon: 'none'
      });
      return;
    }
    this.setData({
      "userInfo.phone": phone
    });
    let _this = this;
    //更新用户表的信息
    wx.cloud.callFunction({
      name: 'userUpdate',
      data: {
        updatePhone: true,
        userId: app.globalData.openid,
        phone: phone
      }
    }).then(res => {
      console.log("修改成功");
      _this.setData({
        isChangePhone: false
      })
    })
  },
  changeHeader: function (e) {
    let _this = this
    // console.log('用户点击更换头像！');
    userDB.doc(app.globalData.openid).get()
      .then(res => {
        // console.log("查询用户信息成功！")
        const data = res.data;
        const userHeaderUrl = data.userHeader
        //如果头像存储在云数据库中，则删除
        if (userHeaderUrl && userHeaderUrl != 'cloud://mapp-5f3o8.6d61-mapp-5f3o8-1259747852/header.png' && userHeaderUrl.slice(0,5) === 'cloud') {
          console.log("头像存储在云数据库中")
          const fileID = data.userHeader;
          wx.cloud.deleteFile({
            fileList: [fileID],
            success: res => {
              console.log("已删除用户原有头像文件：", res)
            },
            fail: res => {
              console.log()
            }
          })
        }
      });

    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        const tempFilePath = res.tempFilePaths[0]
        // console.log(tempFilePath)
        const suffix = /\.[^\.]+$/.exec(tempFilePath)[0]
        const filename = _this.data.userInfo.name + _this.data.userInfo.phone
        wx.cloud.uploadFile({
          cloudPath: 'userHeader/' + filename + suffix,
          filePath: tempFilePath,
          success: res => {
            console.log("上传文件成功，且保存路径为：", res.fileID);
            const fileID = res.fileID;
            wx.cloud.callFunction({
              name: 'userUpdate',
              data: {
                updateUserHeader: true,
                userId: app.globalData.openid,
                userHeader: res.fileID
              },
              success: res => {
                console.log("更新用户头像信息成功！", res)
                _this.setData({
                  "userInfo.userHeader": fileID
                })
              },
              fail: res => {
                console.log("更新用户头像信息失败！", res)
              }
            })
          },
          fail: res => {
            console.log("上传头像文件失败！", res)
          }
        })
      },
      fail: res => {
        console.log(res)
      }
    })
  },
  switch1Change(){
    let _this = this
    let switch1Checked = this.data.switch1Checked;
    _this.setData({tasksPromise: []})
    if (!switch1Checked) {
      //设置为管理员
      if (this.data.companyId) {
        permission.addCompanyAdministrator(_this.data.companyInfo, _this.data.userId, _this.data.tasksPromise);
        Promise.all(_this.data.tasksPromise).then(res => {
          console.log("设置成功");
          wx.showToast({ title: '设置成功',icon: 'none'})
          _this.setData({ switch1Checked: true})
        })
      }
      if (this.data.projectId) {
        permission.addProjectAddministrator(_this.data.projectInfo, _this.data.userId, _this.data.tasksPromise);
        Promise.all(_this.data.tasksPromise).then(res => {
          console.log("设置成功");
          wx.showToast({ title: '设置成功', icon: 'none' })
          _this.setData({ switch1Checked: true })
        })
      }
    } else {
      //取消管理员身份
      if (this.data.companyId) {
        permission.removeCompanyAdministrator(_this.data.companyInfo, _this.data.userId, _this.data.tasksPromise);
        Promise.all(_this.data.tasksPromise).then(res => {
          console.log("成功");
          wx.showToast({ title: '设置成功', icon: 'none' })
          _this.setData({ switch1Checked: false })

        })
      }
      //取消管理员身份
      if (this.data.projectId) {
        permission.removeProjectAddministrator(_this.data.projectInfo, _this.data.userId, _this.data.tasksPromise);
        Promise.all(_this.data.tasksPromise).then(res => {
          console.log("成功");
          wx.showToast({ title: '设置成功', icon: 'none' })
          _this.setData({ switch1Checked: false })
        })
      }
    }
  }
})