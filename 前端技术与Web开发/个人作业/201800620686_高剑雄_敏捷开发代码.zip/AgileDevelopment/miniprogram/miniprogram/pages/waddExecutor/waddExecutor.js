// pages/waddExecutor/waddExecutor.js
const app = getApp()
const util = require('../../util/wutils.js')
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const taskDB = db.collection('tasks')
const projectDB = db.collection('projects');
const companyDB = db.collection('companys');
Page({  
  data: {
    phone: null,
    searchResult: [],
    hasExecutor: false,
    capsuleInfo: app.globalData.capsuleInfo
  },
  inputPhone: function (e) {
    this.setData({
      phone: e.detail.value
    })
  },

  goBack: function () {
    wx.navigateBack({
      delay: 1
    })
  },
  getRecommendUser: function (executorId) {
    //
    let _this = this
    console.log("当前班级：", app.globalData.currentCompany)
    companyDB.doc(app.globalData.currentCompany).get().then(res => {
      console.log(res.data)
      let companyMembers = res.data.members;
      let recommendUser = companyMembers.filter(function (ele, index) {
        return ele != executorId;
      });
      console.log(recommendUser);
      util.getMembersInfo(_this, recommendUser);
    })
    /*
    //获取全部推荐成员 
    userDB.get().then(res => {
      let recommendUser = res.data.filter(function (ele, index) {
        return ele['_id'] != executorId;
      })
      this.setData({
        recommendUser: recommendUser
      })
    })*/
  },
  onLoad: function (options) {
    // console.log(options)
    if(options.executorId) {
      if (options.executorId != "null") {
        // console.log("add task 存在执行者")
        let executorId = options.executorId
        //获取推荐的执行者
        this.getRecommendUser(executorId);
        //添加待认领选项
        this.setData({
          addStatu: true
        })
      } else if (options.executorId === "null") {
        // console.log("add task 设置为待认领");
        //获取推荐的执行者
        this.getRecommendUser("");
      }
    }
    if(options.taskId) {
      this.setData({
        taskId: options.taskId
      })
      taskDB.doc(options.taskId).get().then(res => {
        this.setData({
          proNode: res.data.proNode,//所属项目
          companys: res.data.companys//所属班级
        })
        if (res.data.executor) {
          // console.log("当前任务存在执行者");
          const executorId = res.data.executor;//执行者的id
          this.setData({
            oldExecutor: executorId
          })
          //获取推荐的执行者
          this.getRecommendUser(executorId);
          //添加待认领选项
          this.setData({
            addStatu: true
          })
        } else {
          // console.log("当前任务处于待认领状态");
          //获取推荐的执行者
          this.getRecommendUser("");
        }
      })
    }
  },

  selectedExecutor: function(e) {
    if (this.data.taskId) {
      this.detailExecutor(e)
    } else {
      this.createExecutor(e)
    }
  },

  createExecutor: function(e) {
    let _this = this;
    const id = e.currentTarget.dataset.id
    if (id === '待认领') {
      // console.log('选中了待认领');
      let page = getCurrentPages();
      let prepage = page[page.length - 2];
      prepage.setData({
        executor: null
      })
      wx.navigateBack({
        delay: 1
      })
    } else {
      // console.log('选中了待用户', id);
      let page = getCurrentPages();
      let prepage = page[page.length - 2];
      prepage.setData({
        executor: id
      })
      wx.navigateBack({
        delay: 1
      })
    }
  },

  updateTasksFields(executorId, taskId) {
    console.log("---------------------------------updateTasksFields---------------------------------")
    const executor = wx.cloud.callFunction({
      name: 'taskUpdate',
      data: {
        updateExecutor: true,
        taskId: taskId,
        executorId: executorId
      }
    })
    console.log("executor: ", executor)
    this.data.taskPromise.push(executor)
    const members = wx.cloud.callFunction({
      name: 'taskUpdate',
      data: {
        addMembers: true,
        taskId: taskId,
        userId: executorId
      }
    })
    console.log("members: ", members)
    this.data.taskPromise.push(members)
    console.log("this.data.taskPromise: ", this.data.taskPromise)
  },
  updateUserFields(executorId, taskId, projectsId, companysId){
    console.log("---------------------------------updateUserFields---------------------------------")
    const tasks = wx.cloud.callFunction({
      name: 'userUpdate',
      data: {
        addTasks: true,
        userId: executorId,
        taskId: taskId 
      }
    });
    console.log("tasks: ", tasks)
    this.data.taskPromise.push(tasks);
    const projects = projectsId.map(item => {
      return wx.cloud.callFunction({
        name: 'userUpdate',
        data: {
          addProjects: true,
          userId: executorId,
          proId: item
        }
      })
    });
    console.log("projects: ", projects)
    this.data.taskPromise.concat(projects);
    const companys = companysId.map(item => {
      return wx.cloud.callFunction({
        name: 'userUpdate',
        data: {
          addCompany: true,
          userId: executorId,
          companyId: item
        }
      })
    });
    console.log("companys: ", companys)
    this.data.taskPromise.concat(companys);
    console.log("this.data.taskPromise: ", this.data.taskPromise)
  },
  updateProjectsField(executorId, projectsId){
    console.log("---------------------------------updateProjectsField---------------------------------")
    const members = projectsId.map(item => {
      return wx.cloud.callFunction({
        name: 'projectUpdate',
        data: {
          addMembers: true,
          proId: item,
          userId: executorId
        }
      })
    });
    console.log("members: ", members)
    this.data.taskPromise.concat(members);
    console.log("this.data.taskPromise: ", this.data.taskPromise)
  },
  updateCompanysField(executorId, companysId) {
    console.log("---------------------------------updateCompanysField---------------------------------")
    const members = companysId.map(item => {
      return wx.cloud.callFunction({
        name: 'companyUpdate',
        data: {
          addMember: true,
          companyId: item,
          userId: executorId
        }
      })
    });
    console.log("members: ", members)
    this.data.taskPromise.concat(members);
    console.log("this.data.taskPromise: ", this.data.taskPromise)
  },
  detailExecutor: function(e) {
    let _this = this;
    //查看选中的成员
    const executorId = e.currentTarget.dataset.id
    // console.log(id)
    if (executorId === '待认领') {
      let tasks = [];
      //删除执行者字段
      const promise = wx.cloud.callFunction({
        name: 'taskUpdate',
        data: {
          field: true,
          taskId: _this.data.taskId,
        },
      })
      tasks.push(promise);
      Promise.all(tasks).then(res => {
        console.log("更新成功：", res);
        //跳转到任务详情界面
        wx.navigateBack({
          delta: 1
        })
      })
    } else {
      _this.setData({ taskPromise: []});
      //更新任务，tasks: executor, members
      _this.updateTasksFields(executorId, _this.data.taskId);
      //更新用户表，user: tasks, projects, companys
      _this.updateUserFields(executorId, _this.data.taskId, _this.data.proNode, _this.data.companys);
      //更新项目表，projects: members
      _this.updateProjectsField(executorId, _this.data.proNode);
      //更新班级表，companys：members
      _this.updateCompanysField(executorId, _this.data.companys);
      console.log("length: ", _this.data.taskPromise.length);
      Promise.all(_this.data.taskPromise).then(res => {
        console.log("修改成功",res);
        //跳转到任务详情界面
        wx.navigateBack({
          delta: 1
        })
      }).catch(res => {
        console.log(res)
      })
    }
  },

  
  searchMem: function () {
    console.log("搜索成员")
    userDB.where({
      phone: this.data.phone
    }).get({
      success: res => {
        let userInfo = res.data;
        if (userInfo && userInfo.length > 0) {
          this.setData({
            searchResult: userInfo
          })
        } else {
          wx.showModal({
            content: '该用户还不是注册用户',
          })
        }
      }
    })
  },
})