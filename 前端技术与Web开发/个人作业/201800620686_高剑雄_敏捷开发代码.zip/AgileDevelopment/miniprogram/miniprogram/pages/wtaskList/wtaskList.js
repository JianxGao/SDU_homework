// pages/wtaskList/wtaskList.js
const app = getApp()
//获取数据库引用 
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
Page({

  goBack: function () {
    wx.navigateBack()
  }, 

  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    labels: ['待处理', '进行中', '已完成'],
    checkedIndex: 0,
    isDisabled: true
  },

  checked: function(e) {
    // console.log(e);
    this.setData({
      checkedIndex: e.currentTarget.dataset.index
    })
    if (this.data.checkedIndex != this.data.oldIndex) {
      this.setData({
        isDisabled: false
      })
    } else {
      this.setData({
        isDisabled: true
      })
    }
  },

  saveOperation: function() {
    let _this = this
    let newLabel = _this.data.labels[_this.data.checkedIndex]
    //将选中的分组保存到任务的label字段中
    wx.cloud.callFunction({
      name: 'taskUpdate',data: {taskId: _this.data.taskInfo._id,data: {label: newLabel}}
    })
    //更新项目中的任务节点信息
    let tasksnode = _this.data.projectInfo.tasksnode;
    // console.log("初始的tasksnode：", tasksnode)
    const oldIndex = _this.data.oldIndex;
    let tasks = tasksnode[oldIndex]
    //在原来的位置删除该任务
    let newtasks = tasks.filter(function (ele, index) {return ele != _this.data.taskInfo._id})
    _this.data.projectInfo.tasksnode[oldIndex] = newtasks
    // console.log("删除任务节点的tasksnode：", _this.data.projectInfo.tasksnode)
    //在现在的位置添加该任务
    let newIndex = _this.data.checkedIndex;
    _this.data.projectInfo.tasksnode[newIndex].push(_this.data.taskInfo._id)
    // console.log("添加任务节点的tasksnode：", _this.data.projectInfo.tasksnode)
    //调用云函数updata project
    // console.log("调用云函数updata project")
    wx.cloud.callFunction({
      name: 'projectUpdate',
      data: {
        proId: _this.data.projectInfo._id,
        data: {
          tasksnode: _this.data.projectInfo.tasksnode
        }
      },
      success: res => {
        // console.log(`移动成功，从${_this.data.labels[_this.data.oldIndex]}中移动到${newLabel}`)
        _this.setData({
          loading: false
        })
        wx.navigateBack({
          delta: 1
        })
      }
    })

  },

  onLoad: function (options) {
    let _this = this;
    console.log(options)
    this.setData({taskId: options.taskId})
    //查询任务的默认分组 
    taskDB.doc(options.taskId).get({
      success: res => {
        _this.setData({
          checkedIndex: _this.data.labels.indexOf(res.data.label),
          oldIndex: _this.data.labels.indexOf(res.data.label),
          taskInfo: res.data
        })
        //查询项目的任务信息
        // 获取项目的信息，
        let proId = res.data.proNode[0]
        projectDB.doc(proId).get({
          success: res => {
            console.log(res.data)
            _this.setData({
              projectInfo: res.data,
            })
          }
        })
      }
    })
  },
})