// pages/wmine/wmine.js
let app = getApp() 
const images = require('../../util/images.js');
const { Wechat } = require('../../util/accessToken.js')
const w = new Wechat()
//获取数据库引用 
const db = wx.cloud.database();
const userDB = db.collection('user')
Page({
  /****
   * Page initial data
   */
  data: {
    infoList: ['班级', '项目', '任务', '消息',
     '资料', '日程', '联系人', '我'],
    mineList: [
      { name: '班级', icon: images._class},
      { name: '联系人', icon: images.group },
    ],
    renderList: [
      { name: '项目', icon: images.projects},
      { name: '任务', icon: images.taskSelected},
      { name: '日程', icon: images.eventSelected },
      { name: '资料', icon: images.file },
      { name: '消息', icon: images.notidicationSelected },
      { name: '书签', icon: images.tagSelected },
     
    ],
    add: false,
    animation: {},
    options: {},
    nickName: '',
    userHeader: null,
    screenHeight: app.globalData.screenHeight,//屏幕高度，单位px
    screenWidth: app.globalData.screenWidth,
    navigatorH: app.globalData.navigatorH,//
    statusBarHeight: app.globalData.statusBarHeight,//状态栏的高度，单位px
    images: images,
    loading: true
  },
 
  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {
    if (options.jsonStr) {
      // console.log("由上一界面传递过来的参数：", options.jsonStr);//此用户信息
    } else {
      console.log("由主界面传过来");
    };
    let _this = this;
    const query = wx.createSelectorQuery();
    query.select('.contentWrapper').boundingClientRect();
    query.exec(function (res) {
      // console.log(res)
      _this.setData({
        menuTop: res[0],
        marginLeft: (res[0].width - 150) / 4
      })
      // console.log(_this.data.marginLeft)
    })
  },


  bindPage: function(e) {
    const id = e.currentTarget.dataset.id;
    if (id === '消息') {
      console.log("跳转到信息页面")
      wx.navigateTo({
        url: '../wmessage/wmessage',
      })
    } else if (id === '班级') {
      // console.log("跳转到公司页面")
      wx.navigateTo({
        url: '../wcompany/wcompany',
      })
    } else if (id === '任务') {
      console.log("跳转到任务页面")
      wx.switchTab({
        url: '../wtask/wtask',
      })
    } else if (id === '资料') {
      // console.log("跳转到资料页面")
      wx.navigateTo({
        url: '../wdata/wdata',
      })
    } else if (id === '日程') {
      // console.log("跳转到日程页面")
      wx.switchTab({
        url: '../wschedule/wschedule',
      })
    } else if (id === '联系人') {
      // console.log("跳转到联系人页面")
      wx.navigateTo({
        url: '../wlinkman/wlinkman',
      })
    } else if (id === '项目') {
      // console.log("跳转到项目页面")
      wx.switchTab({
        url: '../wproject/wproject',
      })
    } else if (id === '书签') {
      // console.log("跳转到信息页面")
      wx.switchTab({
        url: '../wbookMark/wbookMark',
      })
    }
  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {
    //当用户点击登录之后 
    let _this = this;
    if (app.globalData.login) {
      userDB.doc(app.globalData.openid).get().then(res => {
        if (res.data) {
          console.log(res.data);
          if (res.data.companys && res.data.companys.length>0) {
            if (!app.globalData.currentCompany) {
              console.log("设置初始值")
              app.globalData.currentCompany = res.data.companys[0];
            }
            _this.setData({
              currentCompany: app.globalData.currentCompany
            })
          } else {
            if (!_this.data.hidden) {
              wx.hideTabBar({})
              _this.setData({
                displayMask: true
              })
            } 
          }
          _this.setData({
            userInfo: res.data,
            loading: false
          });
          // options = JSON.parse(options.jsonStr)
          _this.setData({
            options: res.data,
            userHeader: res.data.userHeader
          });
        }
      })
    }
  },
  bindLogMethod: function() {
    wx.navigateTo({
      url: '../wlogMethod/wlogMethod',
    })
  },
  bindLogout: function() {
    wx.redirectTo({
      url: '../windex/windex',
      success: res => {
        //修改登录状态
        app.globalData.login = null;
      }
    })
  },
  goBack: function () {
    wx.navigateBack()
  }, 

  editUserInfo: function() {
    wx.navigateTo({
      url: '../wprofile/wprofile',
    })
  },
  addCompany: function () {
    wx.redirectTo({
      url: '../waddcompany/waddcompany',
    })
    wx.showTabBar()
  },
  cancelCreate: function() {
    wx.showTabBar()
    this.setData({
      displayMask: false,
      hidden: true
    });
  }
})