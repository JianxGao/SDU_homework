// pages/waddcompany/waddcompany.js
let app = getApp()
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
Page({
  /**
   * 页面的初始数据
   */
  data: {
    enterprise: null,
    capsuleInfo: app.globalData.capsuleInfo,
    
  },
  inputEnterprise: function (e) {
    this.setData({
      enterprise: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  goBack: function () {
    wx.navigateBack()
  }, 
  addCompany: function() {
    let _this = this;
    wx.showLoading({
      title: '创建中...',
    })
    this.setData({
      saving: true
    })
    wx.cloud.callFunction({
      name: "addDoc",
      data: {
        addCompany: true,
        data: {
          name: _this.data.enterprise,//公司名
          creator: app.globalData.openid,//创建者，此用户本身
          creationTime: new Date().valueOf(),//创建时间
          members: [app.globalData.openid],//默认成员包括该用户本身
          projectsNode: [],//项目节点
          addPermission: [app.globalData.openid],//添加内容权限
          deletePermission: [app.globalData.openid],//删除项目及其内容权限
          modifyPermission: [app.globalData.openid]//修改内容权限
        }
      }
    }).then(res => {
      console.log("创建企业成功", res);
      const companyId = res.result._id;
      app.globalData.currentCompany = companyId;
      _this.setData({
        currentCompany: app.globalData.currentCompany
      })
      console.log("切换企业成功", app.globalData.currentCompany);
      // 更新用户表，在该用户的companys字段添加上该公司的id
      wx.cloud.callFunction({
        name: 'userUpdate',
        data: {
          addCompany: true,
          userId: app.globalData.openid,
          companyId: companyId
        }
      }).then(res => {
        console.log("更新用户表成功");
        wx.hideLoading()
        this.setData({
          saving: false
        })
        //跳转至添加成员界面
        wx.redirectTo({
          url: '../waddMem/waddMem?companyId=' + companyId,
        })
      })
    })
  },
})