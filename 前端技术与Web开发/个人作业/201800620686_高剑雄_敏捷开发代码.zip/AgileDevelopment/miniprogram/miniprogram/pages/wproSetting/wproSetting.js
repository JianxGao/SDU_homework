// pages/wproSetting/wproSetting.js 
let app = getApp()
var dateTimePicker = require('../../util/dateTimePicker.js');
var util = require('../../util/wutils.js')
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
 
Page({
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    projectInfo: {},
    //picker
    //设置时间相关
    dateTimeArray: null,
    // dateTime: null,
    endDateTime: null,
    startDateTime: null,
    startYear: 2019,
    endYear: 2050
  },

  inputProject: function(e) {
    // console.log(e.detail.value)
    this.setData({
      "projectInfo.name": e.detail.value
    })
  },

  inputBrief: function(e) {
    // console.log(e.detail.value)
    this.setData({
      "projectInfo.brief": e.detail.value
    })
  },
  getTime: function (dateArr, arr) {
    var _year = dateArr[0][arr[0]];
    var _month = dateArr[1][arr[1]];
    var _day = dateArr[2][arr[2]];
    var _hour = dateArr[3][arr[3]];
    var _minute = dateArr[4][arr[4]];
    return `${_year}-${_month}-${_day} ${_hour}:${_minute}`
  },
  changeStartDateTime(e) {
    console.log("changeStartDateTime: ", e.detail.value)
    let _this = this;
    let startTime = _this.getTime(_this.data.startdateTimeArray, _this.data.startDateTime);
    let startTimestamp = new Date(startTime).valueOf();
    if (startTimestamp > this.data.end) {
      this.setData({
        endTime: "请设置结束时间",
        end: null,
        startTime: startTime,
        start: startTimestamp
      })
    } else {
      this.setData({
        startTime: startTime,
        start: startTimestamp
      });
    }  
  },
  changeStartDateTimeColumn(e) {
    // console.log("changeStartDateTimeColumn: ", e)
    var arr = this.data.startDateTime, dateArr = this.data.startdateTimeArray;

    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    this.setData({
      // startDateTime: arr,
      dateTimeArray: dateArr
    })
  },
    /**
   * 
   */
  changeEndDateTime(e) {
    let _this = this
    console.log("changeEndDateTime: ", e.detail.value, _this.data.endDateTime)
    let endTime = _this.getTime(_this.data.enddateTimeArray, e.detail.value);
    console.log(endTime)
    let endTimestamp = new Date(endTime).valueOf();
    if (endTimestamp < this.data.start) {
      wx.showToast({
        title: ' 设置时间无效！',
        icon: "none",
      })
      if (_this.data.oldEndDateTime) {
        console.log(_this.data.endDateTime, _this.data.oldEndDateTime)
        _this.setData({
          endDateTime: _this.data.oldEndDateTime.split(",").map(item => { return Number(item) })
        })
        console.log(_this.data.oldEndDateTime.split(",").map(item => { return Number(item) }), _this.data.endDateTime)
      }
    } else {
      this.setData({
        endTime: endTime,
        end: endTimestamp
      });
    }
  },
  

  changeEndDateTimeColumn(e) {
    // console.log("changeDateTimeColumn: ", e)
    var arr = this.data.endDateTime, dateArr = this.data.enddateTimeArray;
    arr[e.detail.column] = e.detail.value;
    this.setData({
      oldEndDateTime: arr.toString()
    })
    console.log("ols: ", this.data.oldEndDateTime)
    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    this.setData({
      // endDateTime: arr,
      dateTimeArray: dateArr
    })
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {
    console.log(options)
    const proId = options.proId;
    let _this = this;
    //当前项目的_id
    projectDB.doc(proId).get({
      success: res => {
        console.log(res.data)
        _this.setData({
          projectInfo: res.data,
        });
        let projectInfo = res.data
        let resultObj = util.getInitStartEndDetail(projectInfo, _this.data.startYear, _this.data.endYear);
        console.log("resultObj: ", resultObj)
        _this.setData({
          startDateTime: resultObj.startDateTime,
          endDateTime: resultObj.endDateTime,
          startdateTimeArray: resultObj.startdateTimeArray,
          enddateTimeArray: resultObj.enddateTimeArray
        })
        // // 获取当前时间
        _this.setData({
          startTime: resultObj.start  ? _this.getTime(_this.data.startdateTimeArray, _this.data.startDateTime) : null,
          start: resultObj.start  ? new Date(_this.getTime(_this.data.startdateTimeArray, _this.data.startDateTime)).valueOf() : null,
          endTime: resultObj.end ? _this.getTime(_this.data.enddateTimeArray, _this.data.endDateTime) : null,
          end: resultObj.end ? new Date(_this.getTime(_this.data.enddateTimeArray, _this.data.endDateTime)).valueOf() : null,
        });
      }
    })
  },
  goBack: function() {
    wx.navigateBack({
      delta: 1
    })
  },

  save: function() {
    let _this = this;
    //更新项目在数据库中的存储信息
    wx.cloud.callFunction({
      name: 'projectUpdate',
      data: {
        proId: _this.data.projectInfo._id,
        data: {
          id: _this.data.projectInfo.name,
          name: _this.data.projectInfo.name,
          brief: _this.data.projectInfo.brief,
          start: _this.data.start,
          end: _this.data.end,
        }
      },
      success: res => {
        wx.showToast({
          title: '保存成功',
        })
      },
      fail: res => {
        // console.log(res)
      }
    })
  },

  deleteProject() {
    let _this = this
    wx.showLoading({
      title: '删除中...',
    })
    this.setData({
      saving: true
    })
    let queryProject = this.data.projectInfo;
    console.log("需要删除的项目信息:", queryProject);
    util.deletProject(queryProject).then(res => {
      wx.hideLoading()
      this.setData({
        saving: false
      })
      wx.showToast({
        title: '删除成功',
        icon: 'none'
      });
      wx.switchTab({
        url: '../wproject/wproject',
      })
    })
  },
})