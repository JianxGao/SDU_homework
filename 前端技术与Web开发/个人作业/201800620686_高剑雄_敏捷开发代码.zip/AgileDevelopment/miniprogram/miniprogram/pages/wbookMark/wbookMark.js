// pages/wbookMark/wbookMark.js
const app = getApp() 
const util = require('../../util/wutils.js')
const wclass = require('../../util/wclass.js')

const images = require('../../util/images.js')
//获取数据库引用 
const db = wx.cloud.database();
const userDB = db.collection('user')
const taskDB = db.collection('tasks')
const projectDB = db.collection('projects')
Page({
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    navigatorH: app.globalData.navigatorH,
    statusBarHeight: app.globalData.statusBarHeight,
    screenHeight: app.globalData.screenHeight,
    images: images,
    loading: true
  },
  goBack: function () {
    wx.switchTab({
      url: '../wmine/wmine',
    })
  },
  onLoad: function (options) {
  },

  onShow: function () {
    let _this = this
    if (app.globalData.login) {
      this.setData({
        isLogin: app.globalData.login
      })
    };
    if (app.globalData.login) {
      userDB.doc(app.globalData.openid).get().then(res => {
        let favoritesTaskNode = res.data.tags;
        if (favoritesTaskNode && favoritesTaskNode.length > 0) {
          util.getTaskInfo(favoritesTaskNode).then(res => {
            let tasksInfo = util.sortArray(res);
            // let tasksInfo = res.map(item => {return item.data});
            console.log("收藏:", tasksInfo);
            // _this.setData({ tasksInfo: tasksInfo})
            for (let i = 0; i < tasksInfo.length; i++) {
              if (tasksInfo[i].proNode) {
                console.log(tasksInfo[i].proNode)
                projectDB.doc(tasksInfo[i].proNode[0]).get().then(res => {
                  console.log("父任务：", res.data)
                  tasksInfo[i].parentTaskName = res.data.name
                  _this.setData({
                    tasksInfo: tasksInfo,
                    loading: false
                  })
                })
              } else {
                _this.setData({
                  tasksInfo: tasksInfo,
                  loading: false
                })
              }
            }
          })
        } else {
          _this.setData({
            loading: false
          })
        }
      })
    }
  },
  openAdd: function () {
    // 隐藏tabbar
    wx.hideTabBar()
    // console.log("点击添加");
    this.setData({
      add: true
    });
  },
  closeAdd: function () {
    //显示tabbar
    wx.showTabBar()
    this.setData({
      add: false
    });
  },
  addProject: function () {
    var _this = this;
    wx.navigateTo({
      url: '../waddPro/waddPro',
      success: (res) => {
        _this.setData({
          add: false
        });
        //显示tabbar
        wx.showTabBar()
      }
    })
  },

  addTask: function () {
    var _this = this
    // console.log("add task");
    wx.navigateTo({
      url: '../waddTask/waddTask',
      success: (res) => {
        _this.setData({
          add: false
        });
        //显示tabbar
        wx.showTabBar()
      }
    })
  },

  addEvent: function () {
    var _this = this;
    // console.log("add file");
    wx.navigateTo({
      url: '../waddEvent/waddEvent',
      success: (res) => {
        _this.setData({
          add: false
        });
      }
    })
  },
  updateTaksStatu: function (e) {
    console.log(e.currentTarget.dataset.taskid);
    let _this = this
    const taskId = e.currentTarget.dataset.taskid;
    let status;
    this.data.tasksInfo
      .filter(item => { return item._id === taskId })
      .map(item => {
        console.log(item);
        item.finished = !item.finished;
        console.log(item)
        status = item.finished
        return item
      });
    wx.cloud.callFunction({
      name: 'taskUpdate',
      data: {
        updateFinished: true,
        taskId: taskId,
        finished: status
      }
    }).then(res => {
      _this.setData({ tasksInfo: this.data.tasksInfo})
    })
  },
  taskDetail(e){
    console.log(e.currentTarget.dataset.taskid);
    let _this = this
    const taskId = e.currentTarget.dataset.taskid;
    wx.navigateTo({
      url: '../wtaskDetail/wtaskDetail?taskId=' + taskId,
    })
  }
})