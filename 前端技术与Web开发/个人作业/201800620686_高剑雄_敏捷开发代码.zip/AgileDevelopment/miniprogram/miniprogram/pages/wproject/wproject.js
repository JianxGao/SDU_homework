// pages/wproject/wproject.js
let app = getApp()
const util = require('../../util/wutils.js')
const wremove = require('../../util/wremove.js')

const images = require('../../util/images.js')
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const companyDB = db.collection('companys')
Page({
  data: {
    images: images,
    projects: [],
    capsuleInfo: app.globalData.capsuleInfo,
    loading: true,
    navigatorH: app.globalData.navigatorH,//
    screenHeight: app.globalData.screenHeight,
    statusBarHeight: app.globalData.statusBarHeight,//状态栏的高度，单位px
    screenWidth: app.globalData.screenWidth, //
    title: '项目',
  },
  onLoad: function (options) {
    let _this = this;
    console.log("project: onload");
  },
  onShow: function() {
    //显示tabbar
    wx.showTabBar()
    let _this = this;
    _this.setData({
      isLogin: app.globalData.login,
      displaySearch: false
    })
    if (app.globalData.login) {
      if (app.globalData.currentCompany) {
        _this.setData({
          currentCompany: app.globalData.currentCompany
        });
      }
      if (app.globalData.scrollCompany) {
        _this.setData({
          scrollCompany: app.globalData.scrollCompany
        });
      }
      userDB.doc(app.globalData.openid).get().then(res => {
        console.log(res.data, res.data.projects, res.data.companys)
        let companysId = res.data.companys;//用户所在的班级节点
        let projects = res.data.projects;//用户所在的项目节点
        _this.setData({ projects: projects, companys: res.data.companys})
        if (companysId && companysId.length > 0 && projects.length > 0) {
          util.getCompanyName2ProjectsInfo(companysId, projects, _this);
        } else if (companysId && companysId.length > 0) {
          util.getCompanyName2ProjectsInfo(companysId, [], _this);
        } else {
          _this.setData({
            loading: false
          })
          //若不存在在任何一个班级
          return;
        }
      })
    }
  },

  innerScroll: function(e) {
    let scrollTop = e.detail.scrollTop;
    console.log(scrollTop);
    this.setData({
      scrollTop: scrollTop
    })
  },
  
  goProject: function(e) {
    console.log(e)
    const proId = e.currentTarget.dataset.id
    const isTouchMove = e.currentTarget.dataset.istouchmove
    if (isTouchMove) {
      return;
    }
    wx.navigateTo({
      url: '../wproDetail/wproDetail?proId=' + proId
    })
  }, 
  goBack: function () {
    wx.switchTab({
      url: '../wmine/wmine',
    })
  },
  addPro: function() {
    companyDB.doc(app.globalData.currentCompany).get().then(res => {
      let administrator = res.data.addPermission.concat(res.data.deletePermission).concat(res.data.modifyPermission);
      if (administrator.indexOf(app.globalData.openid) === -1) {
        wx.showToast({ title: '对不起，您没有添加权限。', icon: 'none' });
        return;
      } else {
        wx.navigateTo({ url: '../waddPro/waddPro' })
      }
    }) 
  },
  openAdd: function () {
    // 隐藏tabbar
    wx.hideTabBar()
    // console.log("点击添加");
    this.setData({
      add: true
    });
  },
  closeAdd: function () {
    //显示tabbar
    wx.showTabBar()
    this.setData({
      add: false
    });
  },

  addProject: function () {
    var _this = this;
    wx.navigateTo({
      url: '../waddPro/waddPro',
      success: (res) => {
        _this.setData({
          add: false
        });
        //显示tabbar
        wx.showTabBar()
      },
      fail: res => {
        console.log(res)
      }
    })
  },

  addTask: function () {
    var _this = this
    // console.log("add task");
    wx.navigateTo({
      url: '../waddTask/waddTask',
      success: (res) => {
        _this.setData({
          add: false
        });
        //显示tabbar
        wx.showTabBar()
      }
    })
  },

  addEvent: function () {
    var _this = this;
    // console.log("add file");
    wx.navigateTo({
      url: '../waddEvent/waddEvent',
      success: (res) => {
        _this.setData({
          add: false
        });
      }
    })
  },
  inputSearch: function(e) {
    let value = e.detail.value;
    this.setData({searchContent: value});
    var regStr = `.*${value}`
    var reg = RegExp(`${regStr}`);
    //查询项目的名字
    let allprojectsInfo = this.data.allprojectsInfo;
    let res = allprojectsInfo.filter(item => {
      let projectName = item.name;
      if (reg.test(projectName)) {
        return item
      }
    });
    // console.log(res);
    if (value.length > 0) {
      this.setData({searchProjectsInfo: res})
    } else {
      this.setData({searchProjectsInfo: []})
    }
  },
  openSearch: function() {
    this.setData({
      displaySearch: true
    })
    wx.hideTabBar({});
  },
  closeSearch: function() {
    this.setData({
      displaySearch: false
    })
    wx.showTabBar({})
  },

  touchstart: function (e) {
    if (this.data.editing) {return;}
    let projectsInfoGroup = this.data.projectsInfoGroup;
    projectsInfoGroup.forEach((group, index) => {
      group.projectsInfo.map(item => { return item.isTouchMove = false})
    })
    this.setData({
      startX: e.changedTouches[0].clientX,
      startY: e.changedTouches[0].clientY,
      projectsInfoGroup: projectsInfoGroup
    })
  },
  //滑动事件处理
  touchmove: function (e) {
    if (this.data.editing) { return; }
    var that = this, id = e.currentTarget.dataset.id,//当前索引
      startX = that.data.startX,//开始X坐标
      startY = that.data.startY,//开始Y坐标
      touchMoveX = e.changedTouches[0].clientX,//滑动变化坐标
      touchMoveY = e.changedTouches[0].clientY,//滑动变化坐标
      //获取滑动角度
      angle = that.angle({ X: startX, Y: startY }, { X: touchMoveX, Y: touchMoveY });
    let projectsInfoGroup = this.data.projectsInfoGroup;
    projectsInfoGroup.forEach((group, index) => {
      group.projectsInfo.map(item => { return item.isTouchMove = false });
      for (let j=0; j<group.projectsInfo.length; j++) {
        if (Math.abs(angle) > 30) return;
        if (group.projectsInfo[j]._id === id) {
          if (touchMoveX > startX) {
            group.projectsInfo[j].isTouchMove = false
          } else {
            group.projectsInfo[j].isTouchMove = true
          }
        }
      }
    });
    this.setData({projectsInfoGroup: projectsInfoGroup})
  },
  /**
   * 计算滑动角度
   * @param {Object} start 起点坐标
   * @param {Object} end 终点坐标
   */
  angle: function (start, end) {
    var _X = end.X - start.X,
      _Y = end.Y - start.Y
    //返回角度 /Math.atan()返回数字的反正切值
    return 360 * Math.atan(_Y / _X) / (2 * Math.PI);
  },
  actionsTap(e) {
    console.log(e)
    //此时关闭tabbar
    wx.hideTabBar({});
    let proName = e.currentTarget.dataset.proname
    this.setData({
      deleteName: proName
    })
    this.setData({
      visible2: true,
      actions2: [
        {
          name: '删除',
          color: '#ed3f14',
          proId: e.currentTarget.dataset.id,
          proName: e.currentTarget.dataset.proname
        }
      ]
    });
  },
  handleCancel2() {
    this.setData({
      visible2: false,
      toggle: this.data.toggle ? false : true
    });
    console.log(this.data.toggle, 111111111)
  },

  deleteProject(e) {
    let _this = this
    let allprojectsInfo = this.data.allprojectsInfo;
    let proId;
    console.log(e)
    if (e.detail.dataset) { 
      proId = e.detail.dataset.proid; 
      let queryProject = allprojectsInfo.filter(item => {return item._id === proId})[0];
      console.log(allprojectsInfo, "需要删除的项目信息:", queryProject);
      let administrator = queryProject.addPermission.concat(queryProject.deletePermission).concat(queryProject.modifyPermission);
      if (administrator.indexOf(app.globalData.openid) === -1) {
        wx.showToast({ title: '对不起，您没有删除权限。', icon: 'none' });
        return;
      }
      const action = [...this.data.actions2];
      action[0].loading = true;
      this.setData({actions2: action,tasksPromise: []});
      wremove.deletProject(queryProject[0], _this.data.tasksPromise, action, _this);
    } else { 
      proId = e.currentTarget.dataset.proid; 
      let queryProject = allprojectsInfo.filter(item => { return item._id === proId })[0];
      let administrator = queryProject.addPermission.concat(queryProject.deletePermission).concat(queryProject.modifyPermission);
      if (administrator.indexOf(app.globalData.openid) === -1) {
        wx.showToast({ title: '对不起，您没有删除权限。', icon: 'none' });
        return;
      }
      console.log(allprojectsInfo, "需要删除的项目信息:", queryProject);
      this.setData({tasksPromise: [] });
      wremove.deletProject(queryProject, _this.data.tasksPromise, null, _this);
    }
  },
  leaveEdit: function () {
    console.log("退出编辑状态");
    this.data.projectsInfoGroup.map(item => {item.projectsInfo.map(item => { return item.isRotate = false });});
    this.setData({ projectsInfoGroup: this.data.projectsInfoGroup})
    this.setData({ editing: false })
  },
  enterEdit: function () {
    console.log("进入编辑状态");
    this.setData({
      editing: true
    })
  },
  rotateBtn: function (e) {
    console.log("旋转按钮");
    const dataset = e.currentTarget.dataset;
    console.log(dataset)
    let projectsInfoGroup = this.data.projectsInfoGroup || [];
    if (dataset.projectid) {
      const projectId = dataset.projectid;
      const classId = dataset.classid;
      console.log(projectId, classId);
      let groupclassesInfo = projectsInfoGroup.filter(item => { return item.name === classId })[0].projectsInfo;
      console.log("groupclassesInfo: ", groupclassesInfo);
      let index = groupclassesInfo.indexOf(groupclassesInfo.filter(item => { return item._id === projectId })[0]);
      console.log(index);
      projectsInfoGroup.filter(item => { return item.name === classId })[0].projectsInfo[index].isRotate =
        !projectsInfoGroup.filter(item => { return item.name === classId })[0].projectsInfo[index].isRotate;
      projectsInfoGroup.map(item => {
        if (item.name != classId) {
          item.projectsInfo.map(item => { return item.isRotate = false });
        } else {
          item.projectsInfo.filter(item => { return item._id != projectId }).map(item => { return item.isRotate = false })
        }
      })
      console.log("true: ", projectsInfoGroup)
    }
    this.setData({projectsInfoGroup: projectsInfoGroup})
  },
})