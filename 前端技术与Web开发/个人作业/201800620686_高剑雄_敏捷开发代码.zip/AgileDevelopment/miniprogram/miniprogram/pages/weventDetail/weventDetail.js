// pages/weventDetail/weventDetail.js 
const app = getApp()
const util = require('../../util/wutils.js')
const wclass = require('../../util/wclass.js')
const images = require('../../util/images.js');
const dateTimePicker = require('../../util/dateTimePicker.js')
//获取数据库引用 
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
const eventDB = db.collection('events')
Page({
  data: {
    screenHeight: app.globalData.screenHeight,
    screenWidth: app.globalData.screenWidth,
    capsuleInfo: app.globalData.capsuleInfo,
    display: false,
    images: images,
    height: 0,
    content: '',
    //picker
    //设置时间相关
    dateTimeArray: null,
    // dateTime: null,
    endDateTime: null,
    startDateTime: null,
    startYear: 2019,
    endYear: 2050,
    toIndex: '',
    disable: true
  },
  getDisplayTime(time) {
    let timeArr = [...time.split(' ')[0].split('-'), ...time.split(" ")[1].split(":")]
    return `${timeArr[0]}年${timeArr[1]}月${timeArr[2]}日 ${timeArr[3]}:${timeArr[4]}`
  },
  onLoad: function (options) {
    let _this = this;
    let eventId = options.eventId;
    this.setData({ eventId: eventId, sender: app.globalData.openid});
  },
  changeStartDateTime(e) {
    console.log("changeStartDateTime: ", e.detail.value);
    let _this = this;
    let startTime = _this.getTime(_this.data.startdateTimeArray, _this.data.startDateTime);
    let startTimestamp = new Date(startTime).valueOf();
    if (startTimestamp > this.data.end) {
      this.setData({
        endTime: "请设置结束时间",
        end: null,
        startTime: startTime,
        start: startTimestamp
      });
    
    } else {
      this.setData({
        startTime: startTime,
        start: startTimestamp
      });
    }
  },
  changeEndDateTime(e) {
    let _this = this
    console.log("changeEndDateTime: ", e.detail.value, _this.data.endDateTime)
    let endTime = _this.getTime(_this.data.enddateTimeArray, e.detail.value);
    console.log(endTime)
    let endTimestamp = new Date(endTime).valueOf();
    if (endTimestamp < this.data.start) {
      wx.showToast({
        title: ' 设置时间无效！',
        icon: "none",
      })
      if (_this.data.oldEndDateTime) {
        console.log(_this.data.endDateTime, _this.data.oldEndDateTime)
        _this.setData({
          endDateTime: _this.data.oldEndDateTime.split(",").map(item => { return Number(item) })
        })
        console.log(_this.data.oldEndDateTime.split(",").map(item => { return Number(item) }), _this.data.endDateTime)
      }
    } else {
      _this.setData({
        endTime: endTime,
        end: endTimestamp
      });
    }
  },
  /**
    * 
    */
  changeStartDateTimeColumn(e) {
    let _this = this;
    // console.log("changeStartDateTimeColumn: ", e)
    var arr = this.data.startDateTime, dateArr = this.data.startdateTimeArray;

    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    this.setData({
      // startDateTime: arr,
      startdateTimeArray: dateArr
    })

  },
  changeEndDateTimeColumn(e) {
    let _this = this;
    // console.log("changeDateTimeColumn: ", e)
    var arr = this.data.endDateTime, dateArr = this.data.enddateTimeArray;
    arr[e.detail.column] = e.detail.value;
    this.setData({
      oldEndDateTime: arr.toString()
    })
    console.log("ols: ", this.data.oldEndDateTime)
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    this.setData({
      // endDateTime: arr,
      enddateTimeArray: dateArr
    })
  },
  getTime: function (dateArr, arr) {
    var _year = dateArr[0][arr[0]];
    var _month = dateArr[1][arr[1]];
    var _day = dateArr[2][arr[2]];
    var _hour = dateArr[3][arr[3]];
    var _minute = dateArr[4][arr[4]];
    console.log(`${_year}-${_month}-${_day} ${_hour}:${_minute}`)
    return `${_year}-${_month}-${_day} ${_hour}:${_minute}`
  },
  saveTime: function() {
    let _this = this;
    if (_this.data.end) {
      //修改结束时间
      const promise1 = wx.cloud.callFunction({
        name: "eventUpdate",
        data: {
          updateEnd: true,
          eventId: _this.data.eventId,
          end: _this.data.end
        }
      })
      //修改开始时间
      const promise2 = wx.cloud.callFunction({
        name: "eventUpdate",
        data: {
          updateStart: true,
          eventId: _this.data.eventId,
          start: _this.data.start
        }
      })
      Promise.all([promise1, promise2]).then(res => {
        console.log("修改时间成功：",res);
        this.setData({
          displayStartTime: _this.getDisplayTime(_this.data.startTime),
          displayEndTime: _this.getDisplayTime(_this.data.endTime),
          display: false
        })
      })
    } else {
      wx.showToast({
        title: '请设置结束时间！',
        icon: 'none'
      })
    }
  },
  /**
   * 获取成员的信息
   */
  getMembersInfo: function (membersId) {
    let _this = this;
    let membersInfo = [];
    for (let i = 0; i < membersId.length; i++) {
      userDB.doc(membersId[i]).get().then(res => {
        // console.log(`第${i}个成员：`, res.data)
        membersInfo.push(res.data);
        _this.setData({
          membersInfo: membersInfo
        })
      })
    }
  },
  onShow: function() {
    let _this = this;
    this.setData({height: 0})
    eventDB.doc(_this.data.eventId).get().then(res => {
      console.log(res.data);
      let eventInfo = res.data;
      let messagesInfo = res.data.message || [];
      let queryId = Array.from(new Set(messagesInfo.map(item => { return item.sender })));
      let queryMessageSender = queryId.map(item => {return userDB.doc(item).get()});
      let senderList = {}
      Promise.all(queryMessageSender).then(res => {
        res.map(item => {senderList[item.data._id] = item.data.name});
        messagesInfo = messagesInfo.map(item => {item.senderName = senderList[item.sender];return item});
        console.log("messagesInfo: ", messagesInfo);
        _this.setData({ messagesInfo: messagesInfo || [], senderList: senderList })
      })
      let resultObj = util.getInitStartEndDetail(eventInfo, _this.data.startYear, _this.data.endYear);
      console.log("resultObj: ", resultObj)
      _this.setData({
        startDateTime: resultObj.startDateTime,
        endDateTime: resultObj.endDateTime,
        startdateTimeArray: resultObj.startdateTimeArray,
        enddateTimeArray: resultObj.enddateTimeArray
      })
      // 获取当前时间 
      _this.setData({
        startTime: resultObj.start ? _this.getTime(_this.data.startdateTimeArray, _this.data.startDateTime) : null,
        start: resultObj.start ? new Date(_this.getTime(_this.data.startdateTimeArray, _this.data.startDateTime)).valueOf() : null,
        endTime: resultObj.end ? _this.getTime(_this.data.enddateTimeArray, _this.data.endDateTime) : null,
        end: resultObj.end ? new Date(_this.getTime(_this.data.enddateTimeArray, _this.data.endDateTime)).valueOf() : null,
      });
      //
      _this.setData({
        displayStartTime: _this.getDisplayTime(_this.data.startTime),
        displayEndTime: _this.getDisplayTime(_this.data.endTime)
      })
      var startForm = resultObj.startForm;
      var endForm = resultObj.endForm;
      // const start = util.getTimeInfo(eventInfo.start, true);
      eventInfo.startTime = `${startForm.year}年${startForm.month}月${startForm.day}日 ${startForm.hour}:${startForm.minute}`;
      eventInfo.date = `${startForm.year}年${startForm.month}月${startForm.day}日`
      eventInfo.start = startForm;
      // const end = util.getTimeInfo(eventInfo.end);
      eventInfo.endTime = `${endForm.year}年${endForm.month}月${endForm.day}日 ${endForm.hour}:${endForm.minute}`;
      eventInfo.end = endForm;
      this.setData({
        eventInfo: eventInfo,
        proNode: eventInfo.proNode
      });
      //获取所属项目中的所有日程的名称
      wclass.getProjectsEventsName(_this.data.proNode, _this);
      //获取成员的信息
      this.getMembersInfo(eventInfo.members);
    })
  },
  /**
   * 输入框聚焦时
   */
  focusInput: function (e) {
    this.setData({
      isFocus: true
    })
  },
  eventsNameInput: function (e) {
    const alleventsNameList = this.data.alleventsNameList;
    var value = e.detail.value;
    var oldName = this.data.eventInfo.name
    if (value != oldName) {
      if (alleventsNameList.indexOf(value) === -1 && value.length > 0) {
        this.setData({
          newEventName: value,
          isChanged: true,
        })
      } else if (value.length === 0) {
        wx.showToast({
          title: '日程标题不能为空。',
          icon: 'none'
        });
        this.setData({
          isChanged: false
        })
      } else {
        wx.showToast({
          title: '该日程已存在，请更换日程名称。',
          icon: 'none'
        });
        this.setData({
          isChanged: false
        })
      }
    } else {
      this.setData({
        isChanged: false
      })
    }
  },
  /**
   * 更新数据库中任务的名字
   */
  saveEventName: function (e) {
    let _this = this;
    wx.cloud.callFunction({
      name: 'eventUpdate',
      data: {
        updateName: true,
        eventId: _this.data.eventInfo._id,
        name: _this.data.newEventName
      }
    }).then(res => {
      console.log("修改了日程内容！")
      //显示导航
      _this.setData({
        isFocus: false
      })
    }).catch(res => {
      console.log(res)
    })
  },
  /**
   * 取消保存，显示导航
   */
  cancelSave: function () {
    // console.log("点击取消")
    this.setData({
      isFocus: false,
      "eventInfo.name": this.data.eventInfo.name
    })
  },
  goBack: function() {
    wx.navigateBack({
      delta: 1
    })
  },
  displayMask: function() {
    this.setData({
      display: true
    })
  },
  closeMask: function() {
    this.setData({
      display: false
    })
  },
  bindkeyboardheightchange: function (e) {
    console.log(e);
    const height = e.detail.height;
    if (height > this.data.height || height === 0) {
      this.setData({
        height: height
      });
    }
    console.log("height: ", height, this.data.height)
  },
  addLink: function () {
    let _this = this;
    wx.navigateTo({
      url: '../waddLink/waddLink?eventId=' + _this.data.eventInfo._id,
    })
  },
  inputSend(e) {
    this.setData({content: e.detail.value});
    if (this.data.content === '') { this.setData({ disable: true }) } else { this.setData({ disable: false }) }
  },
  saveMessage() {
    let _this = this;
    this.setData({height: 0});
    let currentTime = new Date().valueOf();
    let timeObj = util.getTimeInfo(currentTime);
    let sendTime = timeObj.year + '-' + timeObj.month + '-' + timeObj.day + ' ' + timeObj.hour + ':' + timeObj.minute;
    let message = { sender: app.globalData.openid, content: this.data.content, sendTime: sendTime, timestamp: currentTime}
    wx.cloud.callFunction({name: "eventUpdate", data: { addMessage: true, eventId: _this.data.eventInfo._id, message: message}})
    .then(res=>{
      console.log("保存成功", res, message);
      // message.senderName = '我';
      _this.setData({content: ''});
      if (this.data.content === '') { this.setData({ disable: true }) } else { this.setData({ disable: false }) }
      _this.data.messagesInfo.push(message);
      _this.setData({ messagesInfo: _this.data.messagesInfo, toIndex: `A${message.timestamp}`});
    })
  },
  addFollower: function () {
    console.log("点击addFollower");
    let _this = this;
    wx.navigateTo({
      url: '../waddFollower/waddFollower?eventId=' + _this.data.eventId,
      success: res => {
        console.log(res)
      },
      fail: res => {
        console.log(res)
      }
    })
  },
})