// pages/wtask/wtask.js
const app = getApp()
const util = require('../../util/wutils.js')
const wclass = require('../../util/wclass.js')
const images = require('../../util/images.js')
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const taskDB = db.collection('tasks')
const projectDB = db.collection('projects')
Page({
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    screenHeight: app.globalData.screenHeight,//屏幕高度，单位px
    navigatorH: app.globalData.navigatorH,//
    statusBarHeight: app.globalData.statusBarHeight,//状态栏的高度，单位px
    tabIndex: 0,
    tabs: ['我执行的', '我创建的', '我参与的'],
    loading: true,
    images: images
  }, 
  innerScroll: function (e) {
    let tabTop = 64;//导航条加头部信息
    if (e.detail.scrollTop + this.data.navigatorH + this.data.statusBarHeight > tabTop) {
      this.setData({
        viewFixed: true
      })
    } else {
      this.setData({
        viewFixed: false
      })
    }
  },
  tabclick: function (e) {
    console.log(e.detail.index);
    this.setData({
      tabIndex: e.detail.index
    })
    let index = this.data.tabIndex
    if (index === 0) {
      this.getExecuteTaskInfo(this.data.tasksExecutor)
    } else if (index === 1) {
      this.getCreatorTaskInfo(this.data.tasksCreator)
    } else if (index === 2) {
      this.getFollowerTaskInfo(this.data.tasksFollower)
    }
  },
  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {
    console.log("on load")
    console.log(app.globalData.login)
    let _this = this;
  },
  /**
   * 获取执行者为当前用户的任务信息
   */
  getExecuteTaskInfo: function(tasksNode) {
    let _this = this;
    if (tasksNode) {
      util.getTaskInfo(tasksNode).then(res => {
        _this.setData({
          executorInfoloading: false,
        })
        let executeTaskInfo = util.sortArray(res);
        for (let i = 0; i < executeTaskInfo.length; i++) {
          if (executeTaskInfo[i].taskNode) {
            taskDB.doc(executeTaskInfo[i].taskNode).get().then(res => {
              executeTaskInfo[i].parentTaskName = res.data.name
              _this.setData({
                executeTaskInfo: executeTaskInfo
              })
            })
          }
          projectDB.doc(executeTaskInfo[i].proNode).get().then(res => {
            executeTaskInfo[i].projectName = res.data.name
            _this.setData({
              executeTaskInfo: executeTaskInfo
            })
          })
        }
      })
    } else {
      _this.setData({
        executorInfoloading: false,
      })
    }
  },
  /**
   * 获取参与者中有当前用户的任务信息
   */
  getFollowerTaskInfo: function (tasksNode) {
    let _this = this;
    if (tasksNode) {
      util.getTaskInfo(tasksNode).then(res => {
        _this.setData({
          followerInfoloading: false
        })
        let followerTaskInfo = util.sortArray(res);
        for (let i = 0; i < followerTaskInfo.length; i++) {
          if (followerTaskInfo[i].taskNode) {
            taskDB.doc(followerTaskInfo[i].taskNode).get().then(res => {
              // console.log("父任务：", res.data)
              followerTaskInfo[i].parentTaskName = res.data.name
              _this.setData({
                followerTaskInfo: followerTaskInfo
              })
            })
          }
          projectDB.doc(followerTaskInfo[i].proNode).get().then(res => {
            followerTaskInfo[i].projectName = res.data.name
            _this.setData({
              followerTaskInfo: followerTaskInfo
            })
          })
        }
      })
    } else {
      _this.setData({
        followerInfoloading: false
      })
    }
  },
  /**
   * 对对象数组进行排序等处理
   */
  sortArray: function(array) {
    let _TaskInfo = array.map(item => { return item.data })
    _TaskInfo.filter(item => { return item.end !== null }).map(item => {
      return item.deadline = util.formatDate(item.end)
    })
    _TaskInfo.filter(item => { return item.end === null }).map(item => {
      return item.end = "2050-10-13"
    })
    //按截止时间排序
    _TaskInfo.sort((a, b) => new Date(a.end) - new Date(b.end))
    return _TaskInfo
  },


  /**
     * 获取当前用户作为创建者的任务信息
     */
  getCreatorTaskInfo: function (tasksNode) {
    let _this = this;
    if (tasksNode) {
      util.getTaskInfo(tasksNode).then(res => {
        // console.log(res)
        _this.setData({
          creatorInfoloading: false
        })
        let creatorTaskInfo = util.sortArray(res);

        for (let i = 0; i < creatorTaskInfo.length; i++) {
          if (creatorTaskInfo[i].taskNode) {
            taskDB.doc(creatorTaskInfo[i].taskNode).get().then(res => {
              creatorTaskInfo[i].parentTaskName = res.data.name
              _this.setData({
                creatorTaskInfo: creatorTaskInfo
              })
            })
          }
          projectDB.doc(creatorTaskInfo[i].proNode).get().then(res => {
            creatorTaskInfo[i].projectName = res.data.name
            _this.setData({
              creatorTaskInfo: creatorTaskInfo
            })
          })
        }
      })
    } else {
      _this.setData({
        creatorInfoloading: false
      })
    }
  },

  taskDetail: function(e) {
    console.log(e)
    const taskId = e.currentTarget.dataset.taskid;
    console.log(taskId)
    const proId = e.currentTarget.dataset.proid
    wx.navigateTo({
      url: `../wtaskDetail/wtaskDetail?taskId=${taskId}`,
    })
  },
  goBack: function () {
    wx.switchTab({
      url: '../wmine/wmine',
    })
  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {
    let _this = this;
    console.log("onshow");
    this.setData({
      isLogin: app.globalData.login
    })
    console.log("-------------------------------------onShow--------------------------------------")
    wx.cloud.callFunction({ name: 'queryDB', data: { _DBName: 'tasks', userId: app.globalData.openid } })
      .then(res => {
        wx.showLoading({ title: '加载中...' })
        if (res.result) {
          let allTasksInfo = res.result.data;
          allTasksInfo = allTasksInfo.filter(item => { return item.members.indexOf(app.globalData.openid) != -1 })
          console.log("allTasksInfo.length: ", allTasksInfo.length)
          allTasksInfo = util.sortInfobyDeadline(allTasksInfo);
          console.log("allTasksInfo: ", allTasksInfo)
          _this.setData({ allTasksInfo: allTasksInfo })
          wclass.getTasksParentTaskName(_this.data.allTasksInfo, _this)
        } else {
          wx.hideLoading();
          this.setData({ createTaskInfo: [], followerTaskInfo: [], executeTaskInfo: []})
        }
      })
    console.log(_this.data.tabIndex)
  },
  updateTaksStatu: function (e) {
    console.log(e.currentTarget.dataset.taskid);
    let _this = this
    const taskId = e.currentTarget.dataset.taskid;
    wclass.updateStatus(_this.data.allTasksInfo, taskId, _this);
  },
  openAdd: function () {
    // 隐藏tabbar
    wx.hideTabBar()
    // console.log("点击添加");
    this.setData({
      add: true
    });
  },
  closeAdd: function () {
    //显示tabbar
    wx.showTabBar()
    this.setData({
      add: false
    });
  },

  addProject: function () {
    var _this = this;
    wx.navigateTo({
      url: '../waddPro/waddPro',
      success: (res) => {
        _this.setData({
          add: false
        });
        //显示tabbar
        wx.showTabBar()
      }
    })
  },

  addTask: function () {
    var _this = this
    // console.log("add task");
    wx.navigateTo({
      url: '../waddTask/waddTask',
      success: (res) => {
        _this.setData({
          add: false
        });
        //显示tabbar
        wx.showTabBar()
      }
    })
  },

  addEvent: function () {
    var _this = this;
    // console.log("add file");
    wx.navigateTo({
      url: '../waddEvent/waddEvent',
      success: (res) => {
        _this.setData({
          add: false
        });
      }
    })
  },
})
