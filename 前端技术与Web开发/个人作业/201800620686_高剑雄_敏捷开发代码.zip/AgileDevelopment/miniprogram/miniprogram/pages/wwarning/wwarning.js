// pages/wwarning/wwarning.js
const app = getApp();
Page({

  /**
   * Page initial data
   */
  data: {
    capsuleInfo: app.globalData.capsuleInfo
  },
  onLoad(){
    setTimeout(function () {
      wx.redirectTo({
        url: '../wlogMethod/wlogMethod?directly=true',
      })
    }, 5000);
  },
  goBack: function () {
    wx.navigateBack()
  }, 

})