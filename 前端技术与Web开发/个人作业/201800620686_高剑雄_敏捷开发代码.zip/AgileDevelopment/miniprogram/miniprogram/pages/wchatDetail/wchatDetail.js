// pages/wchatDetail/wchatDetail.js
const app = getApp();
const images = require('../../util/images.js')
const util = require("../../util/wutils.js")
//获取数据库引用 
const db = wx.cloud.database();
const userDB = db.collection('user');
const chatGroupDB = db.collection('chatGroups');
Page({

  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    screenWidth: app.globalData.screenWidth,
    screenHeight: app.globalData.screenHeight,
    images: images,
    height: 0,
    disable: true
  },

  onLoad: function (options) {
    let _this = this;
    const chatgroupId = options.chatgroupId;
    this.setData({ chatgroupId: chatgroupId, sender: app.globalData.openid});
    chatGroupDB.doc(chatgroupId).get().then(res => {
      let members = res.data.members;
      let queryMembers = members.map(item => { return userDB.doc(item).get() });
      let membersNameList = [];
      Promise.all(queryMembers).then(res => {
        res.map(item => { membersNameList[item.data._id] = item.data.name });
        let friendsName = '';
        for (let key in membersNameList) {if(key!=app.globalData.openid) {friendsName += (membersNameList[key] + '、')}}
        _this.setData({ friendsName: friendsName.slice(0,-1) })
      })
      let messagesInfo = res.data.message || [];
      let queryId = Array.from(new Set(messagesInfo.map(item => { return item.sender })));
      let queryMessageSender = queryId.map(item => { return userDB.doc(item).get() });
      Promise.all(queryMessageSender).then(res => {
        messagesInfo = messagesInfo.map(item => { item.senderName = membersNameList[item.sender]; return item });
        console.log("messagesInfo: ", messagesInfo);
        _this.setData({ messagesInfo: messagesInfo || [], membersNameList: membersNameList })
      });
      
    })
  },
  onShow: function () {
    this.setData({ height: 0 })
  },
  bindkeyboardheightchange: function (e) {
    console.log(e);
    const height = e.detail.height;
    if (height > this.data.height || height === 0) {
      this.setData({
        height: height
      });
    }
    console.log("height: ", height, this.data.height)
  },
  goBack(){wx.navigateBack()},
  inputSend(e) {
    this.setData({ content: e.detail.value });
    if (this.data.content === '') { this.setData({ disable: true }) } else { this.setData({ disable: false }) }
  },
  saveMessage() {
    let _this = this;
    _this.setData({height: 0})
    let currentTime = new Date().valueOf();
    let timeObj = util.getTimeInfo(currentTime);
    let sendTime = timeObj.year + '-' + timeObj.month + '-' + timeObj.day + ' ' + timeObj.hour + ':' + timeObj.minute;
    let message = { sender: app.globalData.openid, content: this.data.content, sendTime: sendTime, timestamp: currentTime }
    wx.cloud.callFunction({ 
      name: "chatGroupUpdate", data: { addMessage: true, chatgroupId: _this.data.chatgroupId, message: message 
    }})
      .then(res => {
        console.log("保存成功", res, message);
        // message.senderName = '我';
        _this.setData({ content: '' });
        if (this.data.content === '') { this.setData({ disable: true }) } else { this.setData({ disable: false }) }
        _this.data.messagesInfo.push(message);
        _this.setData({ messagesInfo: _this.data.messagesInfo, toIndex: `A${message.timestamp}` });
      })
  },
})