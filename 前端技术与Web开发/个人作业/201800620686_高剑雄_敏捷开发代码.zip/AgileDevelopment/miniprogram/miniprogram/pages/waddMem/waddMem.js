// pages/waddMem/waddMem.js
const app = getApp()
const util = require('../../util/wutils.js')
const images = require('../../util/images.js')
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const taskDB = db.collection('tasks')
const projectDB = db.collection('projects')
const chatGroupDB = db.collection('chatGroups');

Page({
  data: {
    searchContent: null,
    searchResult: null,
    isDisabled: true,
    capsuleInfo: app.globalData.capsuleInfo,
    screenHeight: app.globalData.screenHeight,
    screenWidth: app.globalData.screenWidth,
    images: images
  },
  inputName: function(e) {
    let value = e.detail.value;
    this.setData({ searchContent: value });
    var regStr = `.*${value}`
    var reg = RegExp(`${regStr}`);
    //查询项目的名字
    let allUsersInfo = this.data.allUsersInfo;
    let res = allUsersInfo.filter(item => {
      let userName = item.name;if (reg.test(userName)) {return item }
    });
    if (value.length > 0) {this.setData({ searchUsersInfo: res })} 
    else {this.setData({ searchUsersInfo: allUsersInfo })}
  },

  searchMem: function() {
    let _this = this;
    userDB.where({phone: this.data.phone}).get({
      success: res => {
        let userInfo = res.data;
        if (userInfo && userInfo.length > 0) {
          userInfo.map(item => {if (_this.data.membersId.indexOf(item._id) != -1) {item.isExist = true}})
          this.setData({searchResult: userInfo})
          console.log(_this.data.searchResult)
        } else {
          wx.showModal({
            content: '该用户还不是注册用户',
          })
        }
      }
    })
  },
  add2Members: function(e) {
    let _this = this;
    wx.showLoading({
      title: '添加中...',
    });
    _this.setData({
      saving: false
    })
    console.log(e)
    const userId = e.currentTarget.dataset.userid;
    //将该成员的id添加至项目和公司；
    if (this.data.companyId) {

    } else if (this.data.proId) {
      //
      const promise = wx.cloud.callFunction({
        name: 'projectUpdate',
        data: {
          addMembers: true,
          proId: _this.data.proId,
          userId: userId
        }
      })
      const promise1 = wx.cloud.callFunction({
        name: 'companyUpdate',
        data: {
          addMember: true,
          companyId: _this.data.currentCompany,
          userId: userId
        }
      })
      Promise.all([promise, promise1]).then(res => {
        console.log("添加成员成功", res);
        wx.hideLoading();
        _this.setData({
          saving: false
        })
        wx.navigateBack({
          delay: 1
        })
      }).catch(res=> {
        console.log(res)
      })
    }
  },
  goBack: function() {
    if (this.data.companyId) {
      const companyId = this.data.companyId
      wx.navigateBack({delta: 1})
    } else if (this.data.proId) {
      wx.navigateBack({delta: 1})
    } else {
      wx.navigateBack({delta: 1})
    }
  },

  getRecommendUser: function (membersId) {
    let _this = this
    //获取全部推荐成员
    wx.cloud.callFunction({ name: 'queryDB', data: { _DBName: 'user'} })
    .then(res => {
      let usersInfo = res.result.data;
      console.log("usersInfo: ", usersInfo);
      let recommendUser = usersInfo.filter(function (ele, index) {
        return membersId.indexOf(ele['_id']) === -1;
      })
      recommendUser.map(item => {
        return item.checked = false
      })
      this.setData({ recommendUser: recommendUser, allUsersInfo: recommendUser, searchUsersInfo: recommendUser})
    })
  },
  onLoad: function (options) {
    let _this = this
    console.log(options);
    if (options.membersIdJsonStr) {
      // console.log("由上一界面传递过来的参数：", options.membersIdJsonStr);
      let membersId = JSON.parse(options.membersIdJsonStr).membersId;
      _this.setData({ addFriends: true, membersId: membersId});
      _this.getRecommendUser(membersId)
    }
    if (options.companyId) {
      this.setData({companyId: options.companyId});
      let membersId = [app.globalData.openid]
      _this.getRecommendUser(membersId)
    } 
    if (options.proId) {
      this.setData({proId: options.proId})
      projectDB.doc(options.proId).get().then(res => {
        console.log(res);
        let membersId = res.data.members;
        _this.setData({membersId: membersId,proId: options.proId,
        currentCompany: res.data.company, companysId: res.data.companys});
        //获取推荐人员
        _this.getRecommendUser(membersId)
      })
    }
    if (options.createChatGroup) {
      this.setData({ createChatGroup: true});
      _this.getRecommendUser([]);
    }
  },
  /**
   *  根据是否选中，更新推荐者的信息
   */
  updateRecommendUser: function (e) {
    let _this = this;
    // console.log(e)
    let _id = e.currentTarget.dataset.id;//选中成员的id
    let _index = e.currentTarget.dataset.index
    // console.log(_id, _index)
    let searchUsersInfo = this.data.searchUsersInfo;
    searchUsersInfo[_index].checked = !this.data.searchUsersInfo[_index].checked
    // console.log(recommendUser, recommendUser.filter((ele, index) => { return ele.checked === true }).length)
    this.setData({
      isDisabled: searchUsersInfo.filter((ele, index) => { return ele.checked === true }).length == 0
    })
    this.setData({searchUsersInfo: searchUsersInfo})
  },
  saveOperation: function () {
    //记录添加的id，不包括原有的id
    let _this = this;
    const companyId = this.data.companyId
    console.log(companyId)
    let checkedMembersId = this.data.recommendUser.filter((ele, index) => {
      return ele.checked === true
    }).map(item => {
      return item._id
    })
    console.log("checkedMembersId: ", checkedMembersId)
    this.setData({tasksPromise: []})
    //company
    if (this.data.companyId) {
      //更新公司表的成员字段
      const members = checkedMembersId.map(item => {return wx.cloud.callFunction({
        name: 'companyUpdate', data: { addMember: true, companyId: this.data.companyId, userId: item }
      })})
      console.log("members: ", members);
      _this.data.tasksPromise = _this.data.tasksPromise.concat(members);
      console.log("_this.data.tasksPromise: ", _this.data.tasksPromise);
      const companys = checkedMembersId.map(item => {return wx.cloud.callFunction({
        name: 'userUpdate', data: { addCompany: true, userId: item, companyId: _this.data.companyId}
      })})
      console.log("companys: ", companys);
      _this.data.tasksPromise = _this.data.tasksPromise.concat(companys);
      console.log("_this.data.tasksPromise: ", _this.data.tasksPromise);
      Promise.all(_this.data.tasksPromise).then(res => {
        console.log("miao添加了成员");
        var pages = getCurrentPages();
        var pagenow = pages[pages.length - 1];//当前页
        console.log(pagenow)
        var pagepre = pages[pages.length - 2];//上一页
        if (pagepre == undefined){
          wx.navigateTo({
            url: '../wmine/wmine',
          })
        }else{
        wx.navigateBack({delta: 1})
        }
      })
    } else if (this.data.proId) {
      const _Cmembers = []
      _this.data.companysId.forEach(companyId => {
        checkedMembersId.map(item => {return wx.cloud.callFunction({
          name: 'companyUpdate', data: { addMember: true, companyId: companyId, userId: item }
      })})})
      console.log("_Cmembers: ", _Cmembers);
      _this.data.tasksPromise = _this.data.tasksPromise.concat(_Cmembers);
      const companys = []
      _this.data.companysId.forEach(companyId => {
        checkedMembersId.map(item => {companys.push(wx.cloud.callFunction({
          name: 'userUpdate', data: { addCompany: true, userId: item, companyId: companyId }
        }))})})
      console.log("companys: ", companys);
      _this.data.tasksPromise = _this.data.tasksPromise.concat(companys);
      console.log("_this.data.tasksPromise: ", _this.data.tasksPromise); 
      const projects = checkedMembersId.map(item => {return wx.cloud.callFunction({
        name: 'userUpdate', data: { addProjects: true, userId: item, proId: _this.data.proId}
      })})
      console.log("projects: ", projects);
      _this.data.tasksPromise = _this.data.tasksPromise.concat(projects);
      console.log("_this.data.tasksPromise: ", _this.data.tasksPromise); 
      const _Pmembers = checkedMembersId.map(item => {return wx.cloud.callFunction({
        name: 'projectUpdate', data: { addMembers: true, proId: _this.data.proId, userId: item}
      })})
      console.log("_Pmembers: ", _Pmembers);
      _this.data.tasksPromise = _this.data.tasksPromise.concat(_Pmembers);
      console.log("_this.data.tasksPromise: ", _this.data.tasksPromise); 
      Promise.all(_this.data.tasksPromise).then(res => {
        console.log("miao在项目中添加了成员");
        wx.navigateBack({delta: 1})
      })
    } else if (this.data.addFriends) {
      let friendsId = checkedMembersId;
      const friends = friendsId.map(item => {return wx.cloud.callFunction({
        name: 'userUpdate', data: { addFriends: true, userId: app.globalData.openid, friendId: item}
      })});
      console.log("friends: ", friends)
      this.data.tasksPromise = this.data.tasksPromise.concat(friends);
      const addSelf = friendsId.map(item => {return wx.cloud.callFunction({
        name: 'userUpdate', data: { addFriends: true, friendId: app.globalData.openid, userId: item }
      })});
      console.log("addSelf: ", addSelf)
      this.data.tasksPromise = this.data.tasksPromise.concat(addSelf);
      console.log("this.data.tasksPromise: ", this.data.tasksPromise);
      Promise.all(this.data.tasksPromise).then(res => {
        console.log("添加联系人成功");
        wx.navigateBack({ delta: 1 })
      })
    } else if (this.data.createChatGroup) {
      const data = { members: checkedMembersId, creationTime: new Date().valueOf() };
      //判断是否有聊天
      chatGroupDB.where({ members: checkedMembersId }).get().then(res => {
        if (res.data.length === 1) {
          console.log("存在聊天，");
          const chatgroupId = res.data[0]._id;
          wx.redirectTo({ url: '../wchatDetail/wchatDetail?chatgroupId=' + chatgroupId });
        } else if (res.data.length === 0) {
          //建立一个聊天
          wx.cloud.callFunction({ name: 'addDoc', data: { addChatGroup: true, data: data } })
            .then(res => {
              const chatgroupId = res.result._id;//创建聊天的id
              const tasksPromise = data.members.map(item => {return wx.cloud.callFunction({
                name: 'userUpdate', data: { addChatGroups: true, userId: item, chatgroupId: chatgroupId }
              })})
              Promise.all(tasksPromise).then(res => {
                console.log("创建成功");
                wx.redirectTo({ url: '../wchatDetail/wchatDetail?chatgroupId=' + chatgroupId });
              })
            })
        }
      })
    }
  },

  onReady: function () {

  },
})