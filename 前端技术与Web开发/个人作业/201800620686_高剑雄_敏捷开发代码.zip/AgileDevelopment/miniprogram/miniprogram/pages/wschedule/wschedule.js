// pages/wschedule/wschedule.js
const app = getApp()
const util = require('../../util/wutils.js')
const images = require('../../util/images.js')
//获取数据库引用 
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const eventDB = db.collection('events')
Page({
  /**
   * Page initial data
   */
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    screenHeight: app.globalData.screenHeight,//屏幕高度，单位px
    navigatorH: app.globalData.navigatorH,//
    statusBarHeight: app.globalData.statusBarHeight,//状态栏的高度，单位px
    images: images,
    isLogin: app.globalData.login,
    // loading: true,
  },
  innerScroll: function (e) {
    let scrollTop = e.detail.scrollTop;
    // console.log(scrollTop);
    this.setData({
      scrollTop: scrollTop
    })
  },
  
  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {
    
  },
  onShow: function() {
    console.log("onshow");
    let _this = this;
    this.setData({
      isLogin: app.globalData.login
    })
    if (app.globalData.login) {
      //获取所有的日程信息
      console.log('获取所有的日程信息')
      userDB.doc(app.globalData.openid).get().then(res => {
        console.log(res.data);
        _this.setData({
          name: res.data.name,
          phone: res.data.phone,
          userHeader: res.data.userHeader
        })
        let eventsId = res.data.events;
        if (eventsId) {
          // console.log("events: ", eventsId)
          wx.showLoading({
            title: '加载中...',
          })
          util.getEventInfo(_this, eventsId);
        } else {
          _this.setData({
            loading: false
          })
          //若不存在在任何一个班级
          return;
        }
      })
    }
  },
  goBack: function() {
    wx.switchTab({
      url: '../wmine/wmine',
    })
  },
  eventDetail: function(e) {
    // console.log(e);
    const eventId = e.currentTarget.dataset.eventid;
    wx.navigateTo({
      url: '../weventDetail/weventDetail?eventId=' + eventId,
    })
  },
  openAdd: function () {
    // 隐藏tabbar
    wx.hideTabBar()
    // console.log("点击添加");
    this.setData({
      add: true
    });
  },
  closeAdd: function () {
    //显示tabbar
    wx.showTabBar()
    this.setData({
      add: false
    });
  },
  addProject: function () {
    var _this = this;
    wx.navigateTo({
      url: '../waddPro/waddPro',
      success: (res) => {
        _this.setData({
          add: false
        });
        //显示tabbar
        wx.showTabBar()
      }
    })
  },

  addTask: function () {
    var _this = this
    // console.log("add task");
    wx.navigateTo({
      url: '../waddTask/waddTask',
      success: (res) => {
        _this.setData({
          add: false
        });
        //显示tabbar
        wx.showTabBar()
      }
    })
  },

  addEvent: function () {
    var _this = this;
    // console.log("add file");
    wx.navigateTo({
      url: '../waddEvent/waddEvent',
      success: (res) => {
        _this.setData({
          add: false
        });
      }
    })
  },

})