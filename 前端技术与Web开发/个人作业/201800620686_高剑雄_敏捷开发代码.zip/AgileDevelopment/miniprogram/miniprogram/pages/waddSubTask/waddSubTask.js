// pages/waddSubTask/waddSubTask.js
let app = getApp()  
const util = require('../../util/wutils.js');
const wclass = require('../../util/wclass.js')
var dateTimePicker = require('../../util/dateTimePicker.js');
//获取数据库引用 
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
Page({ 
  data: { 
    capsuleInfo: app.globalData.capsuleInfo,
    navigatorH: app.globalData.navigatorH,
    screenHeight: app.globalData.screenHeight,
    statusBarHeight: app.globalData.statusBarHeight,
    subTaskname: null,
    user: null,
    start: null,
    end: null,
    executor: null,
    display: false,
    //picker
    //设置时间相关
    dateTimeArray: null,
    // dateTime: null,
    endDateTime: null,
    startDateTime: null,
    startYear: 2019,
    endYear: 2050,
    disabled: true
  },

  inputTask: function (e) {
    const alltasksNameList = this.data.alltasksNameList;
    var value = e.detail.value;
    if (this.data.alltasksNameList) {
      if (alltasksNameList.indexOf(value) === -1 && value.length > 0) {
        this.setData({
          subTaskname: e.detail.value,
          disabled: false
        })
      } else if (value.length === 0) {
        wx.showToast({
          title: '任务标题不能为空。',
          icon: 'none'
        });
        this.setData({
          disabled: true
        })
      } else {
        wx.showToast({
          title: '该任务已存在，请更换任务名称。',
          icon: 'none'
        });
        this.setData({
          disabled: true
        })
      }
    } else {
      this.setData({
        subTaskname: e.detail.value,
        disabled: false
      })
    }
  },

  onLoad: function (options) {
    // console.log(options)
    let _this = this
    // 获取完整的年月日 时分，以及默认显示的数组
    var obj = dateTimePicker.dateTimePicker(this.data.startYear, this.data.endYear);
    var dateArr = obj.dateTimeArray;
    var startarr = obj.dateTime;
    console.log(startarr);
    var endarr = startarr.map(item => { if (startarr.indexOf(item) === 3) { return item + 1 } return item }); 
    console.log(startarr.map(item => { if (startarr.indexOf(item) === 3) { return item + 1 } return item }))
    this.setData({
      startDateTime: startarr,
      endDateTime: endarr,
      dateTimeArray: dateArr
    })
    // 获取当前时间
    this.setData({
      startTime: _this.getTime(dateArr, startarr),
      start: new Date(_this.getTime(dateArr, startarr)).valueOf(),
      endTime: _this.getTime(dateArr, endarr),
      end: new Date(_this.getTime(dateArr, endarr)).valueOf(),
    });
    this.setData({
      taskId: options.taskId,
      layer: options.layer
    })
    //查询user
    userDB.doc(app.globalData.openid).get({
      success: function (res) {
        let user = res.data;
        _this.setData({
          user: user,
          //默认的参与者（user）
          _MembersId: [user._id],
        })
        util.getMembersInfo(_this, _this.data._MembersId)
      }
    })
    //查询task
    taskDB.doc(options.taskId).get().then(res => {
      // console.log(res)
      let taskInfo = res.data;
      _this.setData({
        taskInfo: taskInfo,
        proNode: taskInfo.proNode//所属父任务
      });
      //获取所属项目中的所有任务的名称
      wclass.getProjectsTasksName(_this.data.proNode, _this);
    })
    
  },
  /**
   *  获取子任务执行者的信息
   */
  getExecutorInfo: function (executorId) {
    // console.log(executorId)
    let _this = this;
    if (executorId) {
      userDB.doc(executorId).get().then(res => {
        // console.log("detail 执行者：", res.data)
        _this.setData({
          executorInfo: res.data
        })
      }).catch(res => {
        // console.log(res)
      })
    } else {
      _this.setData({
        executorInfo: null
      })
    }
  },

  /**
   * 获取成员的id
   */
  getMembersId: function (newmembersId) {
    let _this = this;
    // console.log(_this.data._MembersId)
    let _MembersIdSet = new Set(_this.data._MembersId);
    for (let i = 0; i < newmembersId.length; i++) {
      _MembersIdSet.add(newmembersId[i]);
      // console.log(`添加第${i}个成员的id：`, newmembersId[i])
      _this.setData({
        _MembersId: Array.from(_MembersIdSet)
      })
    }
  },
  /**
   * 跳转至waddExecutor界面
   */
  addexecutor: function () {
    let _this = this;
    wx.navigateTo({
      url: '../waddExecutor/waddExecutor?executorId=' + _this.data.executor,
    })
  },
  /**
   * 跳转至waddFollower界面
   */
  addFollower: function () {
    let _this = this;
    let membersIdJsonStr = JSON.stringify({ 'membersId': this.data._MembersId })
    // console.log("membersIdJsonStr: ", membersIdJsonStr)
    wx.navigateTo({
      url: '../waddFollower/waddFollower?membersIdJsonStr=' + membersIdJsonStr,
    })
  },
  onShow: function () {
    // console.log("add subtask onshow")
    let _this = this;
    //获取执行者的信息
    this.getExecutorInfo(this.data.executor)
    //根据新添加的执行者讨论是否需要添加成员
    if (this.data.executor && this.data.executor != app.globalData.openid) {
      util.getMembersInfo(_this, [app.globalData.openid, this.data.executor])
      this.getMembersId([app.globalData.openid, this.data.executor])
      // console.log("成员的全部id：", this.data._MembersId)
    }
    //checkedMembersId是由addFollower界面传过来的参数：添加的成员的id
    if (this.data.checkedMembersId) {
      let _MembersId = this.data._MembersId.concat(this.data.checkedMembersId).filter((element, index, self) => {
        //indexOf只返回元素在数组中第一次出现的位置，如果与元素位置不一致，说明该元素在前面已经出现过，是重复元素
        return self.indexOf(element) == index;
      })
      this.setData({
        _MembersId: _MembersId
      })
      // console.log("合并之后：", this.data._MembersId);
      //获取参与者的全部信息
      util.getMembersInfo(_this, this.data._MembersId)
    }
  },

  goBack: function () {
    let _this = this
    console.log(this.data.layer)
    if (this.data.layer) {
      wx.redirectTo({
        url: '../wtaskDetail/wtaskDetail?taskId=' + _this.data.taskInfo._id + '&layer=' + (_this.data.taskInfo.layer),
      });
      return;
    };
    console.log("直接返回");
    wx.navigateBack({
      delay: 1
    })
  },

  
  /**
   * 更新任务表，父任务，members，subtasksNode, allsubtasks
   */
  updateTasksFields(parentTasksId, taskId, subtaskId, membersId) {
    console.log("-------------------updateTasksFields---------------------")
    //subtaskNode,直接子任务
    const subtaskNode = wx.cloud.callFunction({
      name: 'taskUpdate',
      data: {
        addSubtask: true,
        taskId: taskId,
        subtaskId: subtaskId
      }
    });
    console.log("subtaskNode: ", subtaskNode)
    this.data.tasksPromise.push(subtaskNode);
    //allsubtasknode，所有子任务
    const allsubtaskNode = parentTasksId.map(taskId => {
      return wx.cloud.callFunction({
        name: 'taskUpdate',
        data: {
          addAllSubtask: true,
          taskId: taskId,
          subtaskId: subtaskId
        }
      });
    })
    console.log("allsubtaskNode: ", allsubtaskNode)
    this.data.tasksPromise.push(allsubtaskNode);
    //members
    let members = [];
    parentTasksId.forEach(taskid => {
      membersId.map(item => {
        members.push(wx.cloud.callFunction({
          name: 'taskUpdate',
          data: {
            addMembers: true,
            taskId: taskid,
            userId: item
          }
        }))
      })
    });
    console.log("members: ", members)
    this.data.tasksPromise = this.data.tasksPromise.concat(members);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  /**
   * 更新用户表，tasks, projects, companys
   */
  updateUserFields(membersId, taskId, prosId, companysId) {
    console.log("-------------------updateUserFields------------------")
    //user: tasks
    const tasks = membersId.map(item => {
      return wx.cloud.callFunction({
        name: 'userUpdate',
        data: {
          addTasks: true,
          userId: item,
          taskId: taskId
        }
      })
    });
    console.log("tasks: ", tasks)
    this.data.tasksPromise.push(tasks)
    //projects
    const projects = []
    prosId.forEach(proId => {
      membersId.map(item => {
        projects.push(wx.cloud.callFunction({
          name: 'userUpdate',
          data: {
            addProjects: true,
            userId: item,
            proId: proId
          }
        }))
      });
    })
    console.log("projects: ", projects)
    this.data.tasksPromise.concat(projects);
    const companys = []
    companysId.forEach(companysid => {
      membersId.map(memberid => {
        companys.push(wx.cloud.callFunction({
          name: 'userUpdate',
          data: {
            addCompany: true,
            userId: memberid,
            companyId: companysid
          }
        }));
      })
    })
    console.log("companys: ", companys)
    this.data.tasksPromise = this.data.tasksPromise.concat(companys);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  /**
  * 更新项目表字段 alltasksnode, members
  * 
  */
  updateProjectFields: function (prosId, taskId, membersId) {
    console.log("-------------------updateProjectFields---------------------")
    let _this = this;
    const allTasksNode = prosId.map(item => {
      return wx.cloud.callFunction({
        name: 'projectUpdate',
        data: {
          addAllTask: true,
          proId: item,
          taskId: taskId
        }
      });
    })
    console.log("allTasksNode: ", allTasksNode)
    this.data.tasksPromise.push(allTasksNode);
    const members = []
    prosId.forEach(proId => {
      membersId.map(item => {
        members.push(wx.cloud.callFunction({
          name: 'projectUpdate',
          data: {
            addMembers: true,
            proId: proId,
            userId: item
          }
        }))
      })
    })
    console.log("members: ", members)
    this.data.tasksPromise = this.data.tasksPromise.concat(members);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  /**
   * 更新公司表，members, tasks
   */
  updateCompanysFields(companysId, membersId, taskId) {
    console.log("-------------------updateCompanysFields------------------")
    const tasks = companysId.map(item => {
      return wx.cloud.callFunction({
        name: 'companyUpdate',
        data: {
          addTasks: true,
          companyId: item,
          taskId: taskId
        }
      })
    });
    console.log("tasks: ", tasks)
    this.data.tasksPromise = this.data.tasksPromise.concat(tasks);

    let members = [];
    companysId.forEach(companyid => {
      membersId.map(item => {
        members.push(wx.cloud.callFunction({
          name: 'companyUpdate',
          data: {
            addMember: true,
            companyId: companyid,
            userId: item
          }
        }))
      })
    });
    console.log("members: ", members)
    this.data.tasksPromise = this.data.tasksPromise.concat(members);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  saveTask: function () {
    let _this = this;
    //查询父任务的所在的layer值
    let layer = _this.data.taskInfo.layer + 1;
    let proNode = _this.data.taskInfo.proNode;
    let parentTaskId = _this.data.taskInfo._id;//直接父任务
    let parentTasksId = _this.data.taskInfo.alltaskNode ? 
      _this.data.taskInfo.alltaskNode.concat([_this.data.taskInfo._id])
    : [_this.data.taskInfo._id];//所有父任务
    wx.showLoading({
      title: '创建中...',
    });
    this.setData({
      saving: true
    })
    wx.cloud.callFunction({
      name: "addDoc",
      data: {
        addTask: true,
        data: _this.data.executor ? {
          name: _this.data.subTaskname,//任务名称
          creator: app.globalData.openid,//创建者
          creationTime: new Date().valueOf(),//创建时间
          executor: _this.data.executor,//首次添加任务时的执行者
          members: _this.data._MembersId,//任务成员
          start: _this.data.start ? new Date(_this.data.start).valueOf() : null,//开始时间
          end: _this.data.end ? new Date(_this.data.end).valueOf() : null,//结束时间
          label: _this.data.taskInfo.label,//默认分组
          addPermission: Array.from(new Set(_this.data.taskInfo.addPermission).add(app.globalData.openid)),//添加内容权限
          deletePermission: Array.from(new Set(_this.data.taskInfo.deletePermission).add(app.globalData.openid)),//删除项目及其内容权限
          modifyPermission: Array.from(new Set(_this.data.taskInfo.modifyPermission).add(app.globalData.openid)),//修改内容权限
          finished: false,//是否完成
          layer: layer,//层级
          taskNode: parentTaskId,//父任务
          alltaskNode: parentTasksId,//所有父任务
          proNode: _this.data.taskInfo.proNode,//所属项目[]
          companys: _this.data.taskInfo.companys//所属公司
        } : {
            name: _this.data.subTaskname,//任务名称
            creator: app.globalData.openid,//创建者
            creationTime: new Date().valueOf(),//创建时间
            // executor: _this.data.executor,//首次添加任务时的执行者
            members: _this.data._MembersId,//任务成员
            start: _this.data.start ? new Date(_this.data.start).valueOf() : null,//开始时间
            end: _this.data.end ? new Date(_this.data.end).valueOf() : null,//结束时间
            label: _this.data.taskInfo.label,//默认分组
            addPermission: Array.from(new Set(_this.data.taskInfo.addPermission).add(app.globalData.openid)),//添加内容权限
            deletePermission: Array.from(new Set(_this.data.taskInfo.deletePermission).add(app.globalData.openid)),//删除项目及其内容权限
            modifyPermission: Array.from(new Set(_this.data.taskInfo.modifyPermission).add(app.globalData.openid)),//修改内容权限
            finished: false,//是否完成
            layer: layer,//层级
            taskNode: parentTaskId,//父任务
            alltaskNode: parentTasksId,//所有父任务
            proNode: proNode,//所属项目[]
            companys: _this.data.taskInfo.companys//所属公司
        }
      },
      success: res => {
        console.log("添加子任务成功：", res)
        _this.setData({
          tasksPromise: []
        })
        //记录所创建任务的id
        const subTaskId = res.result._id;
        _this.setData({subTaskId: subTaskId})
        //更新父任务的字段：subtasksnode (parentTasksId, taskId, subtaskId, membersId)
        _this.updateTasksFields(parentTasksId, parentTaskId, subTaskId, _this.data._MembersId)
        //更新所属项目中的任务节点,projects: tasksnode，alltasksnode，members (prosId, taskId, membersId)
        _this.updateProjectFields(proNode, subTaskId, _this.data._MembersId);
        //更新所有相关成员的用户表，user: tasks, projects, companys (membersId, taskId, prosId, companysId)
        _this.updateUserFields(_this.data._MembersId, subTaskId, proNode, _this.data.taskInfo.companys);
        //更新公司表，companys: members, tasks (companysId, membersId, taskId) 
        _this.updateCompanysFields(_this.data.taskInfo.companys, _this.data._MembersId, subTaskId);
        console.log(_this.data.tasksPromise.length)
        Promise.all(_this.data.tasksPromise).then(res => {
          // console.log(res);
          wx.hideLoading();
          this.setData({
            saving: false
          })
          if (layer < 2) {
            //弹窗提示添加子任务
            _this.setData({
              display: true
            })
          } else {
            console.log("_this.data.subTaskId: ", _this.data.subTaskId);
            wx.redirectTo({
              url: '../wtaskDetail/wtaskDetail?taskId=' + _this.data.subTaskId + '&layer=2',
            })
          }
        }).catch(res => {
          console.log(res)
        })
      },
      fail: res => {
        // console.log(res)
      }
    })
  },
  createSubtask: function () {
    let _this = this
    wx.redirectTo({
      url: `../waddSubTask/waddSubTask?taskId=${_this.data.subTaskId}&layer=${_this.data.taskInfo.layer + 1}`,
    })
    this.setData({
      display: false
    })
  },
  closeMask: function () {
    let _this = this;
    wx.redirectTo({
      url: '../wtaskDetail/wtaskDetail?taskId=' + _this.data.subTaskId + '&layer=' + (_this.data.taskInfo.layer + 1),
    });
  },

  changeStartDateTime(e) {
    console.log("changeStartDateTime: ", e.detail.value)
    let _this = this;
    let startTime = _this.getTime(_this.data.dateTimeArray, _this.data.startDateTime);
    let startTimestamp = new Date(startTime).valueOf();
    if (startTimestamp > this.data.end) {
      this.setData({
        endTime: "请设置结束时间",
        end: null,
        startTime: startTime,
        start: startTimestamp
      })
    } else {
      this.setData({
        startTime: startTime,
        start: startTimestamp
      });
    }
  },
  
  /**
    * 
    */
  changeStartDateTimeColumn(e) {
    // console.log("changeStartDateTimeColumn: ", e)
    var arr = this.data.startDateTime, dateArr = this.data.dateTimeArray;

    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    this.setData({
      // startDateTime: arr,
      dateTimeArray: dateArr
    })
    // console.log(this.data.startTime)
  },
  getTime: function (dateArr, arr) {
    var _year = dateArr[0][arr[0]];
    var _month = dateArr[1][arr[1]];
    var _day = dateArr[2][arr[2]];
    var _hour = dateArr[3][arr[3]];
    var _minute = dateArr[4][arr[4]];
    return `${_year}-${_month}-${_day} ${_hour}:${_minute}`
  },
  /**
   * 
   */
  changeEndDateTime(e) {
    let _this = this
    console.log("changeEndDateTime: ", e.detail.value, _this.data.endDateTime)
    let endTime = _this.getTime(_this.data.dateTimeArray, e.detail.value);
    console.log(endTime)
    let endTimestamp = new Date(endTime).valueOf();
    if (endTimestamp < this.data.start) {
      wx.showToast({
        title: ' 设置时间无效！',
        icon: "none",
      })
      if (_this.data.oldEndDateTime) {
        console.log(_this.data.endDateTime, _this.data.oldEndDateTime)
        _this.setData({
          endDateTime: _this.data.oldEndDateTime.split(",").map(item => { return Number(item) })
        })
        console.log(_this.data.oldEndDateTime.split(",").map(item => { return Number(item) }), _this.data.endDateTime)
      }
    } else {
      this.setData({
        endTime: endTime,
        end: endTimestamp
      });
    }
  },
  changeEndDateTimeColumn(e) {
    // console.log("changeDateTimeColumn: ", e)
    var arr = this.data.endDateTime, dateArr = this.data.dateTimeArray;
    arr[e.detail.column] = e.detail.value;
    this.setData({
      oldEndDateTime: arr.toString()
    })
    console.log("ols: ", this.data.oldEndDateTime)
    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    this.setData({
      // endDateTime: arr,
      dateTimeArray: dateArr
    })
  },
  
})
