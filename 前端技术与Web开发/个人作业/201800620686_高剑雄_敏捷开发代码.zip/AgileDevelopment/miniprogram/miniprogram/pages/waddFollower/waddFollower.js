// pages/waddFollower/waddFollower.js
const app = getApp() 
const util = require('../../util/wutils.js')
const images = require('../../util/images.js')
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const taskDB = db.collection('tasks')
const eventDB = db.collection('events')
const projectDB = db.collection('projects')
Page({  
  data: {
    phone: null,
    searchResult: [],
    capsuleInfo: app.globalData.capsuleInfo,
    recommendUser: [],
    checkedUser: [],
    members: null,
    isDisabled: true,
    images: images
  },

  inputPhone: function (e) {
    this.setData({
      phone: e.detail.value
    })
  },

  searchMem: function () {
    // console.log("搜索成员")
    userDB.where({
      phone: this.data.phone
    }).get({
      success: res => {
        let userInfo = res.data;
        if (userInfo && userInfo.length > 0) {
          this.setData({
            searchResult: userInfo
          })
        } else {
          wx.showModal({
            content: '该用户还不是注册用户',
          })
        }
      }
    })
  },

  goBack: function () {
    wx.navigateBack({
      delay: 1
    })
  },
  updateMembers: function(e) {
    let _this = this;
    // console.log(e)
    let _id = e.currentTarget.dataset.id;//选中成员的id
    let _index = e.currentTarget.dataset.index;
    let _MembersInfo = this.data._MembersInfo;
    _MembersInfo[_index].checked = !this.data._MembersInfo[_index].checked;
    this.setData({
      isDisabled: _MembersInfo.filter((ele, index) => { return ele.checked === false }).length == 0
    });
    this.setData({
      _MembersInfo: _MembersInfo
    })
  },

  /**
   *  根据是否选中，更新推荐者的信息
   */
  updateRecommendUser: function(e) {
    let _this = this;
    // console.log(e)
    let _id = e.currentTarget.dataset.id;//选中成员的id
    let _index = e.currentTarget.dataset.index
    // console.log(_id, _index)
    let recommendUser = this.data.recommendUser;
    recommendUser[_index].checked = !this.data.recommendUser[_index].checked
    // console.log(recommendUser, recommendUser.filter((ele, index) => { return ele.checked === true }).length)
    this.setData({
      isDisabled: recommendUser.filter((ele, index) => { return ele.checked === true }).length == 0
    })
    this.setData({
      recommendUser: recommendUser
    })
  },

  getRecommendUser: function (membersId) {
    //获取全部推荐成员 
    userDB.get().then(res => {
      let recommendUser = res.data.filter(function (ele, index) {
        return membersId.indexOf(ele['_id']) === -1;
      })
      recommendUser.map(item => {
        return item.checked = false
      })
      // console.log("推荐人员信息： ", recommendUser)
      this.setData({
        recommendUser: recommendUser
      })
    })
  },
  onLoad: function (options) {
    console.log(options);
    let _this = this;
    if (options.membersIdJsonStr) {
      // console.log("由上一界面传递过来的参数：", options.membersIdJsonStr);
      let membersId = JSON.parse(options.membersIdJsonStr).membersId
      // console.log("membersId: ", membersId)
      this.setData({membersId: membersId})
      util.getMembersInfo(_this, membersId)
      this.getRecommendUser(membersId)
    }
    if (options.taskId) {
      // console.log("由上一界面传递过来的参数：", options.taskId);
      this.setData({taskId: options.taskId})
      taskDB.doc(options.taskId).get().then(res => {
        let proNode = res.data.proNode
        let membersId = res.data.members;
        _this.setData({
          membersId: membersId,
          proNode: proNode,//所属项目
          companys: res.data.companys,//所属班级
          alltaskNode: res.data.alltaskNode || [],//所有父任务
        })
        util.getMembersInfo(_this, membersId)
        this.getRecommendUser(membersId)
      })
    }
    if (options.eventId) {
      this.setData({ eventId: options.eventId })
      eventDB.doc(options.eventId).get().then(res => {
        let proNode = res.data.proNode
        let membersId = res.data.members;
        _this.setData({
          membersId: membersId,
          proNode: proNode,//所属项目
          companys: res.data.companys,//所属班级
          alltaskNode: res.data.alltaskNode || [],//所有父任务
        })
        util.getMembersInfo(_this, membersId)
        this.getRecommendUser(membersId)
      })
    }
    if (options.proId) {
      // console.log("由上一界面传递过来的参数：", options.proId);
      this.setData({
        proId: options.proId
      })
      projectDB.doc(options.proId).get().then(res => {
        let membersId = res.data.members;//该项目的成员id
        _this.setData({
          membersId: membersId
        })
        util.getMembersInfo(_this,membersId);
        _this.getRecommendUser(membersId)
      })
    }
  },
  updateEventsFields(membersId, eventId) {
    console.log("---------------------------------updateEventsFields---------------------------------")
    console.log("eventId: ", eventId)
    const members = membersId.map(item => {return wx.cloud.callFunction({
      name: 'eventUpdate', data: { addMembers: true, eventId: eventId,userId: item}
    })})
    console.log("members: ", members)
    this.data.taskPromise.concat(members)
    console.log("this.data.taskPromise: ", this.data.taskPromise)
  },
  updateTasksFields(membersId, tasksId) {
    console.log("---------------------------------updateTasksFields---------------------------------")
    console.log("tasksId: ", tasksId)
    const members = [];
    tasksId.forEach(taskId => {
      membersId.map(item => {
        members.push(wx.cloud.callFunction({
          name: 'taskUpdate',
          data: {
            addMembers: true,
            taskId: taskId,
            userId: item
          }
        }))
      })
    })
    console.log("members: ", members)
    this.data.taskPromise.concat(members)
    console.log("this.data.taskPromise: ", this.data.taskPromise)
  },
  updateUserFields(membersId, tasksId, eventId, projectsId, companysId) {
    console.log("---------------------------------updateUserFields---------------------------------")
    if (tasksId) {
      const tasks = [];
      tasksId.forEach(taskId => {membersId.map(item => {tasks.push(wx.cloud.callFunction({
        name: 'userUpdate',data: {addTasks: true,userId: item,taskId: taskId}
      }))})})
      console.log("tasks: ", tasks)
      this.data.taskPromise.concat(tasks);
    }
    if (eventId) {
      const events = [];
      membersId.map(item => {return wx.cloud.callFunction({
        name: 'userUpdate',data: {addEvents: true,userId: item,eventId: eventId}
      })})
      console.log("events: ", events)
      this.data.taskPromise.concat(events);
    }
    const projects = [];
    membersId.forEach(memberid => {
      projectsId.map(item => {
        projects.push(wx.cloud.callFunction({
          name: 'userUpdate',
          data: {
            addProjects: true,
            userId: memberid,
            proId: item
          }
        }))
      });
    })
    console.log("projects: ", projects)
    this.data.taskPromise.concat(projects);
    const companys = [];
    membersId.forEach(memberid => {
      companysId.map(item => {
        companys.push(wx.cloud.callFunction({
          name: 'userUpdate',
          data: {
            addCompany: true,
            userId: memberid,
            companyId: item
          }
        }))
      });
    })
    console.log("companys: ", companys)
    this.data.taskPromise.concat(companys);
    console.log("this.data.taskPromise: ", this.data.taskPromise)
  },
  updateProjectsField(membersId, projectsId) {
    console.log("---------------------------------updateProjectsField---------------------------------")
    const members = []
    membersId.forEach(memberid => {
      projectsId.map(item => {
        members.push(wx.cloud.callFunction({
          name: 'projectUpdate',
          data: {
            addMembers: true,
            proId: item,
            userId: memberid
          }
        }))
      });
    })
    console.log("members: ", members)
    this.data.taskPromise.concat(members);
    console.log("this.data.taskPromise: ", this.data.taskPromise)
  },
  updateCompanysField(membersId, companysId) {
    console.log("---------------------------------updateCompanysField---------------------------------")
    const members = [];
    membersId.forEach(memberid => {
      companysId.map(item => {
        members.push(wx.cloud.callFunction({
          name: 'companyUpdate',
          data: {
            addMember: true,
            companyId: item,
            userId: memberid
          }
        }))
      });
    }) 
    console.log("members: ", members)
    this.data.taskPromise.concat(members);
    console.log("this.data.taskPromise: ", this.data.taskPromise)
  },

  saveOperation: function () {
    //记录添加的id，不包括原有的id
    let _this = this;
    wx.showLoading({
      title: '添加中...',
    })
    _this.setData({
      saving: true
    })
    let deletedMembersId = this.data._MembersInfo.filter((ele, index) => {
      return ele.checked === false
    }).map(item => {
      return item._id
    });
    let checkedMembersId = this.data.recommendUser.filter((ele, index) => { 
      return ele.checked === true 
      }).map(item => {
        return item._id 
      });
    // console.log("checkedMembersId: ", checkedMembersId)
    if (checkedMembersId.length > 0) {
      if (this.data.taskId) {
        // console.log("在任务详情界面添加成员");
        this.setData({taskPromise: []})
        //更新用户表，user: tasks, projects, companys
        _this.updateUserFields(checkedMembersId, _this.data.alltaskNode.concat([_this.data.taskId]), null, _this.data.proNode, _this.data.companys);
        //更新任务表，tasks: members
        _this.updateTasksFields(checkedMembersId, _this.data.alltaskNode.concat([_this.data.taskId]));
        //更新项目表，projects：members
        _this.updateProjectsField(checkedMembersId, _this.data.proNode);
        //更新班级表，companys: members
        _this.updateCompanysField(checkedMembersId, _this.data.companys);
        Promise.all(_this.data.taskPromise).then(res => {
          console.log("miao添加了成员");
          wx.hideLoading()
          _this.setData({
            saving: false
          })
          wx.navigateBack({
            delay: 1
          })
        })
      } else if (this.data.eventId) {
        // console.log("在任务详情界面添加成员");
        this.setData({ taskPromise: [] })
        //更新用户表，user: events, projects, companys
        _this.updateUserFields(checkedMembersId, null, this.data.eventId, _this.data.proNode, _this.data.companys);
        //更新日程表，tasks: members
        _this.updateEventsFields(checkedMembersId, this.data.eventId);
        //更新项目表，projects：members
        _this.updateProjectsField(checkedMembersId, _this.data.proNode);
        //更新班级表，companys: members
        _this.updateCompanysField(checkedMembersId, _this.data.companys);
        Promise.all(_this.data.taskPromise).then(res => {
          console.log("miao添加了成员");
          wx.hideLoading()
          _this.setData({saving: false})
          wx.navigateBack({delta: 1})
        })
      } else if (this.data.proId && !this.data.taskId) {
        // console.log("在文件详情界面添加成员");
        this.setData({
          tasksPromise: []
        })
        //直接将成员添加到项目中的members字段中
        util.updateProjectMembers(checkedMembersId, _this.data.proId, _this.data.tasksPromise);
        //更新公司的成员members字段
        util.updateCompanysMembers(checkedMembersId, app.globalData.currentCompany, _this.data.tasksPromise)
        //更新任务成员的companys字段
        util.updateCompanys(checkedMembersId, app.globalData.currentCompany, _this.data.tasksPromise)
        //更新任务成员的taskFollower字段和projects字段
        util.updateTasksFollower(checkedMembersId, _this.data.taskId, _this.data.tasksPromise);
        util.updateProjects(checkedMembersId, _this.data.proId, _this.data.tasksPromise);
        // console.log(_this.data.tasksPromise.length)
        Promise.all(_this.data.tasksPromise).then(res => {
          console.log("miao添加了成员");
          wx.navigateBack({
            delay: 1
          })
        })
      } else {
        //创建任务时
        let page = getCurrentPages();
        let prepage = page[page.length - 2];
        prepage.setData({
          checkedMembersId: checkedMembersId
        });
        wx.navigateBack({
          delay: 1
        })
      }  
    }
    if (deletedMembersId.length > 0) {
      if (this.data.taskId) {
        let tasks = [];
        for (let i = 0; i < deletedMembersId.length; i++) {
          let userId = deletedMembersId[i];
          const promise = wx.cloud.callFunction({
            name: 'userUpdate',
            data: {
              deleteFollowerTaskNode: true,
              userId: userId,
              taskId: _this.data.taskId
            }
          });
          tasks.push(promise);
          const promise1 = wx.cloud.callFunction({
            name: 'taskUpdate',
            data: {
              deleteMembers: true,
              taskId: _this.data.taskId,
              userId: userId
            }
          });
          tasks.push(promise1);
        };
        Promise.all(tasks).then(res => {
          console.log("shanchu chenggong", res)
          wx.hideLoading()
          _this.setData({
            saving: false
          });
          wx.navigateBack({
            delay: 1
          })
        })
      } 

    }
  },



})