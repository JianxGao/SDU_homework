// pages/windex/windex.js
const {Wechat} = require("../../util/accessToken.js");
const w = new Wechat();
Page({
  data: {
    checked: false,
    info: [{ value: 'yes', checked: false }, { value: 'no', checked: false}]
  },
  onShow: function() {
    this.setData({
      info: [{ value: 'yes', checked: false }, { value: 'no', checked: false }]
    })
  },
  
  updateStatu: function(e) {
    console.log(e.currentTarget.dataset.value);
    const value = e.currentTarget.dataset.value;
    let info = this.data.info
    if(value === 'yes') {
      info[0].checked = true
      this.setData({info: info})
      w.reuqestSubscribMessage().then(res => { console.log(res) })
      wx.navigateTo({
        url: '../wlogMethod/wlogMethod?directly=true'
      })
    } else if (value === 'no') {
      info[1].checked = true
      this.setData({
        info: info
      })
      wx.navigateTo({
        url: '../wwarning/wwarning',
      })
    }
  },
})