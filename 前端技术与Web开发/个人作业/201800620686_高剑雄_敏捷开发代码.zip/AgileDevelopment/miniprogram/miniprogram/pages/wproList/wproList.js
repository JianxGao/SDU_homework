// pages/wproList/wproList.js
const app = getApp()
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
Page({
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
  },
  goBack: function () {
    wx.navigateBack()
  }, 

  getProjectsInfo: function (projectsId) {
    let _this = this
    let tasks = []
    for (let i = 0; i < projectsId.length; i++) {
      const promise = projectDB.doc(projectsId[i]).get()
      tasks.push(promise)
    }
    Promise.all(tasks).then(res => {
      // console.log(res)
      let projectsInfo = res.map(item => { return item.data })
      _this.setData({
        selectedProject: projectsInfo
      })
      // console.log(_this.data.selectedProject)
    }).catch(res => {
      console.log(res)
    })
  },
  onLoad: function (options) {
    let _this = this
    console.log("options: ", options)
    if (options.taskId) {this.setData({ taskId: options.taskId})};
    if (options.eventId) { this.setData({ eventId: options.eventId })};
    if (options.selectTap) {
      this.setData({ selectTap: Number(options.selectTap) === 0});
      console.log("this.data.selectTap: ", this.data.selectTap)
    }
    //获取该用户参与的所有项目
    userDB.doc(app.globalData.openid).get()
      .then(res => {
        // console.log(res.data.projects);
        this.setData({
          _AllProjectsId: res.data.projects
        })
        this.getProjectsInfo(_this.data._AllProjectsId)
      })
  },
  selectTap: function(e) {
    // console.log(e)
    const selectProjectId = e.currentTarget.dataset.proid 
    let page = getCurrentPages();
    let prepage = page[page.length - 2];
    projectDB.doc(selectProjectId).get().then(res => {
      // console.log(res.data);
      prepage.setData({
        selectProject: res.data
      })
      wx.navigateBack({
        delta: 1
      })
    })
  },

  fileListTap(e){
    console.log("-----------------------------进入项目文件列表--------------------------");
    const selectProjectId = e.currentTarget.dataset.proid;
    if(this.data.taskId) {  
      const taskId = this.data.taskId;
      console.log("selectProjectId:", selectProjectId, taskId);
      wx.navigateTo({url: '../wfileList/wfileList?taskId=' + taskId + '&proId=' + selectProjectId})
    }
    if (this.data.eventId) {
      const eventId = this.data.eventId;
      console.log("selectProjectId:", selectProjectId, eventId);
      wx.navigateTo({ url: '../wfileList/wfileList?eventId=' + eventId + '&proId=' + selectProjectId })
    }
  },
})