// pages/wsubTask/wsubTask.js
const app = getApp()
const util = require('../../util/wutils.js')
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
   
Page({

  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    navigatorH: app.globalData.navigatorH,//
    statusBarHeight: app.globalData.statusBarHeight,//状态栏的高度，单位px
  },

  createSubTask: function () {
    let _this = this
    // console.log("创建子任务")
    wx.navigateTo({
      url: `../waddSubTask/waddSubTask?proId=${_this.data.proId}&taskId=${_this.data.taskId}`,
    })
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {
    // console.log(options);
    const taskId = options.taskId;
    const proId = options.proId
    this.setData({
      taskId: taskId,
      proId: proId
    })
    if (options.directly) {
      this.setData({
        directly: true
      })
    }
  },

  /**
   * 对对象数组进行排序等处理
   */
  sortArray: function (array) {
    let _TaskInfo = array.map(item => { return item.data })
    _TaskInfo.filter(item => { return item.end !== null }).map(item => {
      return item.deadline = util.formatDate(item.end)
    })
    _TaskInfo.filter(item => { return item.end === null }).map(item => {
      return item.end = "2050-10-13"
    })
    //按截止时间排序
    _TaskInfo.sort((a, b) => new Date(a.end) - new Date(b.end))
    return _TaskInfo
  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {
    let _this = this
    //查询task
    taskDB.doc(this.data.taskId).get({
      success: function (res) {
        let taskInfo = res.data;
        _this.setData({
          taskInfo: taskInfo
        })
        let subtasksId = res.data.subtasksNode
        _this.getSubtasksInfo(subtasksId).then(res => {
          let subtasksInfo = _this.sortArray(res);
          _this.setData({
            subtasksInfo: subtasksInfo
          })
          for (let i = 0; i<subtasksInfo.length; i++) {
            if (subtasksInfo[i].executor) {
              userDB.doc(subtasksInfo[i].executor).get().then(res => {
                subtasksInfo[i].userHeader = res.data.userHeader
                _this.setData({
                  subtasksInfo: subtasksInfo
                })
              })
            } 
          }
        })
      }
    })
  },
  getSubtasksInfo: function(subutasksId) {
    let _this = this;
    let subtasksInfo = [];
    let tasks = []
    for (let i=0; i<subutasksId.length; i++) {
      const promise = taskDB.doc(subutasksId[i]).get()
      tasks.push(promise)
    }
    return Promise.all(tasks)
  },
  taskDetail: function (e) {
    const taskId = e.currentTarget.dataset.taskid
    wx.navigateTo({
      url: `../wtaskDetail/wtaskDetail?proId=${this.data.proId}&taskId=${taskId}`,
    })
  },
  goBack: function() {
    if (this.data.directly) {
      wx.navigateBack({
        delta: 2
      });
    } else {
      wx.navigateBack({
        delta: 1
      });
    }
  },
  updateTaksStatu: function(e) {
    const taskId = e.currentTarget.dataset.taskid
    // console.log(taskId)
    let subtasksInfo = this.data.subtasksInfo
    //更新tasksInfo 
    subtasksInfo = util.updateTaksStatu(taskId, subtasksInfo)
    this.setData({
      subtasksInfo: subtasksInfo
    })
  }
})