// pages/waddEvent/waddEvent.js
var dateTimePicker = require('../../util/dateTimePicker.js');
const util = require('../../util/wutils.js')
const images = require('../../util/images.js')
const app = getApp()
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
const eventDB = db.collection('events')
Page({ 
  /** 
   * 页面的初始数据
   */
  data: {
    images: images,
    capsuleInfo: app.globalData.capsuleInfo,
    //设置时间相关
    dateTimeArray: null,
    // dateTime: null,
    endDateTime: null,
    startDateTime: null,
    startYear: 2019,
    endYear: 2050,
    disabled: true,
  },

  inputEvent: function (e) {
    const eventsNameList = this.data.eventsNameList;
    var value = e.detail.value;
    //
    if (!this.data.projectInfo) {
      wx.showToast({
        title: '请先选择一个项目。',
        icon: 'none'
      })
      return;
    } else {
      if (this.data.eventsNameList) {
        if (eventsNameList.indexOf(value) === -1 && value.length > 0) {
          this.setData({
            eventName: value,
            disabled: false
          })
        } else if (value.length === 0) {
          wx.showToast({
            title: '日程标题不能为空。',
            icon: 'none'
          });
          this.setData({
            disabled: true
          })
        } else {
          wx.showToast({
            title: '该日程已存在，请更换日程名称。',
            icon: 'none'
          });
          this.setData({
            disabled: true
          })
        }
      } else {
        this.setData({
          eventName: value,
          disabled: false
        })
      }
    }
  },

  getTime: function (dateArr, arr) {
    var _year = dateArr[0][arr[0]];
    var _month = dateArr[1][arr[1]];
    var _day = dateArr[2][arr[2]];
    var _hour = dateArr[3][arr[3]];
    var _minute = dateArr[4][arr[4]];
    return `${_year}-${_month}-${_day} ${_hour}:${_minute}`
  },

  onLoad: function (options) {
    let _this = this
    // 获取完整的年月日 时分，以及默认显示的数组
    var obj = dateTimePicker.dateTimePicker(this.data.startYear, this.data.endYear);
    var dateArr = obj.dateTimeArray;
    var startarr = obj.dateTime;
    console.log(startarr);
    var endarr = startarr.map(item => { if (startarr.indexOf(item) === 3) { return item + 1 } return item });
    console.log(startarr.map(item => { if (startarr.indexOf(item) === 3) { return item + 1 } return item }))
    console.log(endarr)
    this.setData({
      // dateTime: arr,
      startDateTime: startarr,
      endDateTime: endarr,
      dateTimeArray: dateArr
    })
    // 获取当前时间
    this.setData({
      startTime: _this.getTime(dateArr, startarr),
      start: new Date(_this.getTime(dateArr, startarr)).valueOf(),
      endTime: _this.getTime(dateArr, endarr),
      end: new Date(_this.getTime(dateArr, endarr)).valueOf(),
    });
    
    //查询user
    userDB.doc(app.globalData.openid).get({
      success: function (res) {
        let user = res.data;
        _this.setData({
          //默认的参与者
          _MembersId: [user._id],
        })
        util.getMembersInfo(_this, _this.data._MembersId)
        // console.log(_this.data.membersId)
      }
    })
    if (options.proId) {
      //查询project
      projectDB.doc(options.proId).get().then(res => {
        _this.setData({
          projectInfo: res.data
        });
        //获取所有的日程信息;
        let alleventsNode = res.data.events;
        _this.setData({
          alleventsNode: alleventsNode
        });
        if (alleventsNode && alleventsNode.length > 0) {
          let tasks = alleventsNode.map(item => { return eventDB.doc(item).get() });
          Promise.all(tasks).then(res => {
            let eventsNameList = res.map(item => { return item.data.name });
            console.log(eventsNameList);
            _this.setData({
              eventsNameList: eventsNameList
            })
          })
        }
      })
    } else {
      // console.log("直接添加任务");
      this.setData({
        directly: true
      })
      //获取该用户参与的所有项目
      userDB.doc(app.globalData.openid).get()
      .then(res => {
        // console.log(res.data.projects);
        this.setData({
          _AllProjectsId: res.data.projects
        })
        this.getProjectsInfo(_this.data._AllProjectsId)
      })
    }
  }, 
  /**
   * 查询用户项目的信息
   */
  getProjectsInfo: function (projectsId) {
    let _this = this
    let tasks = []
    for (let i = 0; i < projectsId.length; i++) {
      const promise = projectDB.doc(projectsId[i]).get()
      tasks.push(promise)
    }
    Promise.all(tasks).then(res => {
      // console.log(res)
      let projectsInfo = res.map(item => { return item.data })
      _this.setData({
        selectedProject: projectsInfo
      })
      // console.log(_this.data.selectedProject)
    }).catch(res => {
      // console.log(res)
    })
  },

  selectedProject: function () {
    wx.navigateTo({
      url: '../wproList/wproList?selectTap=0'
    })
  },

  changeStartDateTime(e) {
    console.log("changeStartDateTime: ", e.detail.value)
    let _this = this;
    let startTime = _this.getTime(_this.data.dateTimeArray, _this.data.startDateTime);
    let startTimestamp = new Date(startTime).valueOf();
    if (startTimestamp > this.data.end) {
      this.setData({
        endTime: "请设置结束时间",
        end: null,
        startTime: startTime,
        start: startTimestamp
      })
    } else {
      this.setData({
        startTime: startTime,
        start: startTimestamp
      });
    } 
  },
  changeStartDateTimeColumn(e) {
    // console.log("changeStartDateTimeColumn: ", e)
    var arr = this.data.startDateTime, dateArr = this.data.dateTimeArray;

    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    this.setData({
      // startDateTime: arr,
      dateTimeArray: dateArr
    })
  },

  /**
   * 
   */
  changeEndDateTime(e) {
    let _this = this
    console.log("changeEndDateTime: ", e.detail.value, _this.data.endDateTime)
    let endTime = _this.getTime(_this.data.dateTimeArray, e.detail.value);
    console.log(endTime)
    let endTimestamp = new Date(endTime).valueOf();
    if (endTimestamp < this.data.start) {
      wx.showToast({
        title: ' 设置时间无效！',
        icon: "none",
      })
      if (_this.data.oldEndDateTime) {
        console.log(_this.data.endDateTime, _this.data.oldEndDateTime)
        _this.setData({
          endDateTime: _this.data.oldEndDateTime.split(",").map(item => { return Number(item) })
        })
        console.log(_this.data.oldEndDateTime.split(",").map(item => { return Number(item) }), _this.data.endDateTime)
      }
    } else {
      this.setData({
        endTime: endTime,
        end: endTimestamp
      });
    }
  },

  changeEndDateTimeColumn(e) {
    // console.log("changeDateTimeColumn: ", e)
    var arr = this.data.endDateTime, dateArr = this.data.dateTimeArray;
    arr[e.detail.column] = e.detail.value;
    this.setData({
      oldEndDateTime: arr.toString()
    })
    console.log("ols: ", this.data.oldEndDateTime)
    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    this.setData({
      // endDateTime: arr,
      dateTimeArray: dateArr
    })
  },
  updateProjectFields(membersId, eventId, proId) {
    console.log("---------------------------updateProjectFields------------------------")
    const events = wx.cloud.callFunction({
      name: 'projectUpdate',
      data: {
        addEvent: true,
        proId: proId,
        eventId: eventId
      }
    });
    console.log("events: ", events)
    this.data.taskPromise = this.data.taskPromise.concat(events);
    const members = membersId.map(item => {
      return wx.cloud.callFunction({
        name: 'projectUpdate',
        data: {
          addMembers: true,
          proId: proId,
          userId: item
        }
      })
    })
    console.log("members: ", members)
    this.data.taskPromise = this.data.taskPromise.concat(members);
    console.log(" this.data.taskPromise: ", this.data.taskPromise);
  },
  updateCompanyFields(membersId, eventId, companysId) {
    console.log("---------------------------updateCompanyFields------------------------")
    const events = companysId.map(companyId => {
      return wx.cloud.callFunction({
        name: 'companyUpdate',
        data: {
          addEvents: true,
          companyId: companyId,
          eventId: eventId
        }
      })
    });
    console.log("events: ", events)
    this.data.taskPromise = this.data.taskPromise.concat(events);
    const members = [];
    companysId.forEach(companyId => {
      membersId.map(item => {
        members.push(wx.cloud.callFunction({
          name: 'companyUpdate',
          data: {
            addMember: true,
            companyId: companyId,
            userId: item
          }
        }))
      })
    });
    console.log("members: ", members)
    this.data.taskPromise = this.data.taskPromise.concat(members);
    console.log(" this.data.taskPromise: ", this.data.taskPromise);
  },
  updateUserFields(membersId, eventId, proId, companysId) {
    const events = membersId.map(item => {
      return wx.cloud.callFunction({
        name: 'userUpdate',
        data: {
          addEvents: true,
          userId: item,
          eventId: eventId
        }
      })
    })
    console.log("events: ", events)
    this.data.taskPromise = this.data.taskPromise.concat(events);
    //projects
    const projects = membersId.map(item => {
      return wx.cloud.callFunction({
        name: 'userUpdate',
        data: {
          addProjects: true,
          userId: item,
          proId: proId
        }
      })
    });
    console.log("projects: ", projects);
    this.data.taskPromise = this.data.taskPromise.concat(projects);
    //companys
    const companys = []
    companysId.forEach(companysid => {
      membersId.map(memberid => {
        companys.push(wx.cloud.callFunction({
          name: 'userUpdate',
          data: {
            addCompany: true,
            userId: memberid,
            companyId: companysid
          }
        }));
      })
    })
    console.log("companys: ", companys)
    this.data.taskPromise = this.data.taskPromise.concat(companys);
    console.log(" this.data.taskPromise: ", this.data.taskPromise);
  },
  saveEvent: function() {
    let _this = this
    wx.showLoading({
      title: '创建中...',
    })
    wx.cloud.callFunction({
      name: "addDoc",
      data: {
        addEvent: true,
        data: {
          name: _this.data.eventName,//日程名称
          creator: app.globalData.openid,//创建者
          creationTime: new Date().valueOf(),//创建时间
          start: _this.data.start,//开始日期
          end: _this.data.end,//截至日期
          members: _this.data._MembersId,//日程成员
          proNode: [_this.data.projectInfo._id],//所属项目
          companys: _this.data.projectInfo.companys,//所属公司
          addPermission: Array.from(new Set(_this.data.projectInfo.addPermission).add(app.globalData.openid)),//添加内容权限
          deletePermission: Array.from(new Set(_this.data.projectInfo.deletePermission).add(app.globalData.openid)),//删除项目及其内容权限
          modifyPermission: Array.from(new Set(_this.data.projectInfo.modifyPermission).add(app.globalData.openid)),//修改内容权限
        }
      },
      success: res => {
        // console.log(res);
        //记录所创建任务的id
        const eventId = res.result._id;
        this.setData({eventId: eventId, taskPromise: []});
        //更新项目表：projects: members, events;
        _this.updateProjectFields(_this.data._MembersId, eventId, _this.data.projectInfo._id);
        //更新班级表：companys: members, events;
        _this.updateCompanyFields(_this.data._MembersId, eventId, _this.data.projectInfo.companys);
        //更新用户表：user： evnets, projects, companys
        _this.updateUserFields(_this.data._MembersId, eventId, _this.data.projectInfo._id, _this.data.projectInfo.companys)
        //执行所有任务
        Promise.all(_this.data.taskPromise).then(res => {
          wx.hideLoading()
          console.log(`${app.globalData.openid}在${new Date().toDateString()}创建日程`);
          wx.navigateBack({
            delay: 1
          })
        })
      },
      fail: res => {
        // console.log(res)
      }
    })
  },
  updateProjectEventsNode: function (eventId) {
    let _this = this
    const promise = wx.cloud.callFunction({
      name: 'projectUpdate',
      data: {
        addEvent: true,
        proId:_this.data.projectInfo._id,
        eventId: eventId
      }
    });
    this.data.addTasks.push(promise)
  },
  updateUsersEvent: function (membersId, eventId) {
    let _this = this
    for(let i = 0; i< membersId.length; i++) {
      const promise = wx.cloud.callFunction({
        name: 'userUpdate',
        data: {
          events: true,
          userId: membersId[i],
          eventId: eventId
        }
      })
      this.data.addTasks.push(promise)
    }
  },

  updateUsersProject: function (membersId) {
    let _this = this
    for (let i = 0; i < membersId.length; i++) {
      const promise = wx.cloud.callFunction({
        name: 'userUpdate',
        data: {
          projects: true,
          userId: membersId[i],
          proId: _this.data.projectInfo._id
        }
      })
      this.data.addTasks.push(promise)
    }
  },

  addFollower: function () {
    let _this = this;
    let membersIdJsonStr = JSON.stringify({ 'membersId': this.data._MembersId })
    // console.log("membersIdJsonStr: ", membersIdJsonStr)
    wx.navigateTo({
      url: '../waddFollower/waddFollower?membersIdJsonStr=' + membersIdJsonStr,
    })
  },
  onShow: function() {
    let _this = this
    //checkedMembersId是由addFollower界面传过来的参数：添加的成员的id
    if (this.data.checkedMembersId) {
      let _MembersId = this.data._MembersId.concat(this.data.checkedMembersId).filter((element, index, self) => {
        //indexOf只返回元素在数组中第一次出现的位置，如果与元素位置不一致，说明该元素在前面已经出现过，是重复元素
        return self.indexOf(element) == index;
      })
      this.setData({
        _MembersId: _MembersId
      })
      // console.log("合并之后：", this.data._MembersId);
      //获取参与者的全部信息
      util.getMembersInfo(_this, this.data._MembersId)
    }
    //如果是从主界面直接添加任务，接收到wproList的参数selectProject
    if (this.data.selectProject) {
      this.setData({
        projectInfo: this.data.selectProject
      })
      // console.log(this.data.projectInfo)
      //获取所有的日程信息;
      let alleventsNode = this.data.selectProject.events;
      _this.setData({
        alleventsNode: alleventsNode
      });
      if (alleventsNode && alleventsNode.length > 0) {
        let tasks = alleventsNode.map(item => { return eventDB.doc(item).get() });
        Promise.all(tasks).then(res => {
          let eventsNameList = res.map(item => { return item.data.name });
          console.log(eventsNameList);
          _this.setData({
            eventsNameList: eventsNameList
          })
        })
      }
    }
  },
  goBack: function() {
    wx.navigateBack({
      delay: 1
    })
  },
})