// pages/wfileList/wfileList.js
let app = getApp()
const util = require('../../util/wutils.js')
const images = require('../../util/images.js')
//获取数据库引用 
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
const eventDB = db.collection('events')
const fileDB = db.collection('files')
const folderDB = db.collection('folders')
Page({
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    navigatorH: app.globalData.navigatorH,//
    statusBarHeight: app.globalData.statusBarHeight,//状态栏的高度，单位px
    screenHeight: app.globalData.screenHeight,
    screenWidth: app.globalData.screenWidth,
    images: images,
    checkedLength: 0
  },

  onLoad: function (options) {
    let _this = this;
    console.log("options:", options);
    const proId = options.proId;
    this.setData({proId: proId});
    if (options.taskId) { this.setData({ taskId: options.taskId})};
    if (options.eventId) { this.setData({ eventId: options.eventId }) };

  },
  onShow(){
    console.log("--------------------------------------------------onshow-------------------------------------------------")
    let _this = this;
    if (app.globalData.checkedFileInfo || app.globalData.checkedFolderInfo) {
      //checkedFileInfo, checkedFolderInfo
      let checkedFileInfo = app.globalData.checkedFileInfo || [];//已经选中的文件
      let checkedFileLength = app.globalData.checkedFileInfo ? app.globalData.checkedFileInfo.length : 0
      let checkedFolderLength = app.globalData.checkedFolderInfo ? app.globalData.checkedFolderInfo.length : 0
      let checkedFolderInfo = app.globalData.checkedFolderInfo || [];//已经选中的文件夹
      this.setData({
        checkedLength: checkedFileLength + checkedFolderLength,
        preCheckedLength: checkedFileLength + checkedFolderLength, currentPageChecked: 0,
        checkedFileInfo: checkedFileInfo, precheckedFileInfo: checkedFileInfo,
        checkedFolderInfo: checkedFolderInfo, precheckedFolderInfo: checkedFolderInfo
      })
    }
    projectDB.doc(this.data.proId).get().then(res => {
      _this.setData({
        projectInfo: res.data,
        filesId: res.data.files,//直接子文件
        foldersId: res.data.folders//直接子文件夹
      });
      //获取文件信息
      if (res.data.files) {
        console.log("-----------------------------加载文件信息---------------------------------")
        const filesId = res.data.files;
        util.getFilesInfo(filesId).then(res => {
          let filesInfo = res.map(item => { return item.data });
          filesInfo.map(item => { return item.checked = false, 
          item.extension = item.name.split('.').pop(), 
          item.fname = item.name.split('.').slice(0,-1).join('.')});
          //查看app.globalData.checkedFileInfo里的信息
          app.globalData.checkedFileInfo ?
            filesInfo.map(item => {
              if (app.globalData.checkedFileInfo.filter(checkedItem => { return checkedItem._id === item._id }).length > 0) {
                return item.checked = true;
              } else {
                return item.checked = false
              }
            }) : filesInfo.map(item => { return item.checked = false })
          _this.setData({filesInfo: filesInfo,})
        })
      };
      if (res.data.folders) {
        console.log("-----------------------------加载文件夹信息---------------------------------")
        util.getFoldersInfo(res.data.folders).then(res => {
          let foldersInfo = res.map(item => { return item.data });
          foldersInfo.map(item => { return item.checked = false })
          //查看app.globalData.checkedFolderInfo
          app.globalData.checkedFolderInfo ?
            foldersInfo.map(item => {
              if (app.globalData.checkedFolderInfo.filter(checkedItem => { return checkedItem._id === item._id }).length > 0) {
                return item.checked = true;
              } else {
                return item.checked = false
              }
            }) : foldersInfo.map(item => { return item.checked = false })
          _this.setData({ foldersInfo: foldersInfo, })
        })
      }
    });
  },
  goBack(){wx.navigateBack()},
  updateCheckedItem(e){
    const dataset = e.currentTarget.dataset;
    let filesInfo = this.data.filesInfo || [];
    let foldersInfo = this.data.foldersInfo || [];
    if (dataset.fileid) {
      console.log("------------------------------------file tap---------------------------------")
      const fileId = dataset.fileid;
      filesInfo.filter(item => {return item._id === fileId}).map(item => {return item.checked = !item.checked});
      let length = filesInfo.concat(foldersInfo).filter(item => { return item.checked === true }).length;
      console.log("filesInfo length: ", length);
      let checkedFileInfo = filesInfo.filter(item => { return item.checked === true });
      app.globalData.checkedFileInfo = checkedFileInfo
      this.setData({ filesInfo: filesInfo, checkedLength: length, checkedFileInfo: checkedFileInfo})
    } else if (dataset.folderid) {
      console.log("------------------------------------folder tap---------------------------------")
      const folderId = dataset.folderid;
      foldersInfo.filter(item => { return item._id === folderId }).map(item => { return item.checked = !item.checked });
      let length = filesInfo.concat(foldersInfo).filter(item => { return item.checked === true }).length;
      console.log("foldersInfo length: ", length)
      let checkedFolderInfo = foldersInfo.filter(item => { return item.checked === true })
      app.globalData.checkedFolderInfo = checkedFolderInfo
      this.setData({ foldersInfo: foldersInfo, checkedLength: length, checkedFolderInfo: checkedFolderInfo})
    }
  },
  folderDetail(e){
    console.log("-------------------------------folder detail--------------------------");
    let checkedLength = this.data.checkedLength
    const folderId = e.currentTarget.dataset.folderid;
    let checkedFileInfo = this.data.checkedFileInfo || [];
    let checkedFolderInfo = this.data.checkedFolderInfo || [];
    if (this.data.taskId) {
      let taskId = this.data.taskId;
      wx.navigateTo({url:'../wfolderDetail/wfolderDetail?folderId='+folderId+'&addLink=0&checkedLength='+checkedLength+'&taskId='+taskId});
    }
    if (this.data.eventId) {
      let eventId = this.data.eventId;
      wx.navigateTo({url:'../wfolderDetail/wfolderDetail?folderId='+folderId+'&addLink=0&checkedLength='+checkedLength+'&eventId='+eventId});
    }
  },
  closeMask(){this.setData({display: false})},
  openMask() { if (this.data.checkedLength > 0) this.setData({ display: true })},
  showToast() {
    wx.showToast({
      title: '已选择该项',
      icon: 'none'
    })
  },
  confirmLink(){
    let _this = this;
    console.log("app.globalData.checkedFileInfo: ", app.globalData.checkedFileInfo)
    console.log("app.globalData.checkedFolderInfo: ", app.globalData.checkedFolderInfo)

    if (!app.globalData.checkedFileInfo && !app.globalData.checkedFolderInfo) {
      return;
    }
    wx.showLoading({
      title: '关联中...',
    })
    const checkedFilesId = app.globalData.checkedFileInfo ? app.globalData.checkedFileInfo.map(item => {return item._id}) : [];
    const checkFoldersId = app.globalData.checkedFolderInfo ? app.globalData.checkedFolderInfo.map(item => {return item._id}) : [];
    let checkFoldersSubFolderId = [];
    app.globalData.checkedFolderInfo ? app.globalData.checkedFolderInfo.map(item => { 
      checkFoldersSubFolderId = checkFoldersSubFolderId.concat(item.folders || []) }) : [];
    let checkFoldersSubFilesId = [];
    app.globalData.checkedFolderInfo ? app.globalData.checkedFolderInfo.map(item => { 
      checkFoldersSubFilesId = checkFoldersSubFilesId.concat(item.files || []) }) : [];
    console.log("checkFoldersSubFolderId: ", checkFoldersSubFolderId)
    console.log("checkFoldersSubFilesId: ", checkFoldersSubFilesId)
    if (this.data.taskId) {taskDB.doc(this.data.taskId).get().then(res => {
      let proNode = res.data.proNode;//所属项目
      let companys = res.data.companys; //所属班级
      _this.setData({tasksPromise: []});
      //更新任务表；tasks: files, folders
      _this.updateTaskFields(checkedFilesId, checkFoldersId, _this.data.taskId );
      if (checkedFilesId.length > 0) {
        //更新文件表；files: taskNode, proNode, companys
        _this.updateFileFields(checkedFilesId, _this.data.taskId, null, proNode, companys);
      }
      if (checkFoldersId.length > 0) {
        //更新文件夹表；folders: taskNode, proNode, companys
        _this.updateFolderFields(checkFoldersId, _this.data.taskId, null, proNode, companys, checkFoldersSubFolderId);
        _this.updateFileFields(checkFoldersSubFilesId, _this.data.taskId, null, proNode, companys);
      }
      //更细项目表；projects: allfiles, allfolders;
      _this.updateProjectFields(checkedFilesId, checkFoldersId, proNode);
      //更新班级表；companys: files, folders;
      _this.updateCompanyFields(checkedFilesId, checkFoldersId, companys);
      Promise.all(_this.data.tasksPromise).then(res => {
        console.log("关联成功", res);
        app.globalData.checkedFileInfo = [];
        app.globalData.checkedFolderInfo = [];
        wx.hideLoading()
        wx.redirectTo({
          url: '../waddLink/waddLink?taskId=' + _this.data.taskId + '&link=3',
        })
      })
    })}
    if (this.data.eventId) {
      eventDB.doc(this.data.eventId).get().then(res => {
        let proNode = res.data.proNode;//所属项目
        let companys = res.data.companys; //所属班级
        _this.setData({ tasksPromise: [] });
        //更新任务表；tasks: files, folders
        _this.updateEventFields(checkedFilesId, checkFoldersId, _this.data.eventId);
        if (checkedFilesId.length > 0) {
          //更新文件表；files: taskNode, proNode, companys
          _this.updateFileFields(checkedFilesId, null, _this.data.eventId, proNode, companys);
        }
        if (checkFoldersId.length > 0) {
          //更新文件夹表；folders: taskNode, proNode, companys，默认其子文件夹也是关联的文件夹
          _this.updateFolderFields(checkFoldersId, null, _this.data.eventId, proNode, companys, checkFoldersSubFolderId);
          //更新文件表；files: taskNode, proNode, companys
          _this.updateFileFields(checkFoldersSubFilesId, null, _this.data.eventId, proNode, companys);
        }
        //更细项目表；projects: allfiles, allfolders;
        _this.updateProjectFields(checkedFilesId, checkFoldersId, proNode);
        //更新班级表；companys: files, folders;
        _this.updateCompanyFields(checkedFilesId, checkFoldersId, companys);
        Promise.all(_this.data.tasksPromise).then(res => {
          console.log("关联成功", res);
          app.globalData.checkedFileInfo = [];
          app.globalData.checkedFolderInfo = [];
          wx.hideLoading()
          wx.redirectTo({ url: '../waddLink/waddLink?eventId=' + _this.data.eventId + '&link=3'})
        })
      })
    }
  },
  updateEventFields(filesId, foldersId, eventId) {
    console.log('-------------------------------updateEventFields--------------------------------------')
    const files = filesId.map(fileId => {
      return wx.cloud.callFunction({
        name: 'eventUpdate',
        data: {
          addFiles: true,
          eventId: eventId,
          fileId: fileId
        }
      })
    });
    console.log("files: ", files);
    this.data.tasksPromise = this.data.tasksPromise.concat(files);
    const folders = foldersId.map(folderId => {
      return wx.cloud.callFunction({
        name: 'eventUpdate',
        data: {
          addFolders: true,
          eventId: eventId,
          folderId: folderId
        }
      })
    });
    console.log("folders: ", folders);
    this.data.tasksPromise = this.data.tasksPromise.concat(folders);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  updateTaskFields(filesId, foldersId, taskId){
    console.log('-------------------------------updateTaskFields--------------------------------------')
    const files = filesId.map(fileId => {
      return wx.cloud.callFunction({
        name: 'taskUpdate',
        data: {
          addFiles: true,
          taskId: taskId,
          fileId: fileId
        }
      })
    });
    console.log("files: ", files);
    this.data.tasksPromise = this.data.tasksPromise.concat(files);
    const folders = foldersId.map(folderId => {
      return wx.cloud.callFunction({
        name: 'taskUpdate',
        data: {
          addFolders: true,
          taskId: taskId,
          folderId: folderId
        }
      })
    });
    console.log("folders: ", folders);
    this.data.tasksPromise = this.data.tasksPromise.concat(folders);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  updateFileFields(filesId, taskId, eventId, projectsId, companysId) {
    console.log('-------------------------------updateFileFields--------------------------------------')
    if (taskId) {
      const taskNode = [];
      filesId.map((fileId, index) => {
        taskNode.push(wx.cloud.callFunction({
          name: 'fileUpdate',
          data: {
            addTaskNode: true,
            fileId: fileId,
            taskId: taskId
          }
        }))
      });
      console.log("taskNode: ", taskNode);
      this.data.tasksPromise = this.data.tasksPromise.concat(taskNode);
    }
    if (eventId) {
      const eventNode = []
      filesId.map((fileId, index) => {
        eventNode.push(wx.cloud.callFunction({
          name: 'fileUpdate',
          data: {
            addEventNode: true,
            fileId: fileId,
            eventId: eventId
          }
        }));
      });
      console.log("eventNode: ", eventNode);
      this.data.tasksPromise = this.data.tasksPromise.concat(eventNode);
    }
    
    const proNode = [];
    projectsId.forEach(proId => {
      filesId.map(item => {
        proNode.push(wx.cloud.callFunction({
          name: 'fileUpdate',
          data: {
            addProNode: true,
            fileId: item,
            proId: proId
          }
        }))
      })
    });
    console.log("proNode: ", proNode);
    this.data.tasksPromise = this.data.tasksPromise.concat(proNode);
    const companys = [];
    companysId.forEach(companyId => {
      filesId.map(item => {
        companys.push(wx.cloud.callFunction({
          name: 'fileUpdate',
          data: {
            addCompanys: true,
            fileId: item,
            companyId: companyId
          }
        }))
      })
    });
    console.log("companys: ", companys);
    this.data.tasksPromise = this.data.tasksPromise.concat(companys);
    console.log(" this.data.tasksPromise : ", this.data.tasksPromise );
  },
  updateFolderFields(foldersId, taskId, eventId, projectsId, companysId, checkFoldersSubFolderId) {
    console.log('-------------------------------updateFolderFields--------------------------------------');
    //选中的文件夹及其全部的子文件夹，都要更新字段taskNode或eventNode
    let allFoldersId = foldersId.concat(checkFoldersSubFolderId);

    if (taskId) {
      const taskNode = [];
      allFoldersId.map((folderId, index) => {
        taskNode.push(wx.cloud.callFunction({
          name: 'folderUpdate',
          data: {
            addTaskNode: true,
            folderId: folderId,
            taskId: taskId
          }
        }))      
      });
      console.log("taskNode: ", taskNode);
      this.data.tasksPromise = this.data.tasksPromise.concat(taskNode);
    }
    if (eventId) {
      const eventNode = []
      allFoldersId.map((folderId, index) => {
        eventNode.push(wx.cloud.callFunction({
          name: 'folderUpdate',
          data: {
            addEventNode: true,
            folderId: folderId,
            eventId: eventId
          }
        }));
      });
      console.log("eventNode: ", eventNode);
      this.data.tasksPromise = this.data.tasksPromise.concat(eventNode);
    }
    const proNode = [];
    projectsId.forEach(proId => {
      allFoldersId.map(item => {
        proNode.push(wx.cloud.callFunction({
          name: 'folderUpdate',
          data: {
            addProNode: true,
            folderId: item,
            proId: proId
          }
        }))
      })
    });
    console.log("proNode: ", proNode);
    this.data.tasksPromise = this.data.tasksPromise.concat(proNode);
    const companys = [];
    companysId.forEach(companyId => {
      allFoldersId.map(item => {
        companys.push(wx.cloud.callFunction({
          name: 'folderUpdate',
          data: {
            addCompanys: true,
            folderId: item,
            companyId: companyId
          }
        }))
      })
    });
    console.log("companys: ", companys);
    this.data.tasksPromise = this.data.tasksPromise.concat(companys);
    console.log(" this.data.tasksPromise : ", this.data.tasksPromise);
  },
  updateProjectFields(filesId, foldersId, projectsId) {
    console.log('-------------------------------updateProjectFields--------------------------------------')
    const allfiles = [];
    projectsId.forEach(proId => {
      filesId.map(item => {
        allfiles.push(wx.cloud.callFunction({
          name: 'projectUpdate',
          data: {
            addAllFile: true,
            proId: proId,
            fileId: item
          }
        }));
      });
    });
    console.log("allfiles: ", allfiles);
    this.data.tasksPromise = this.data.tasksPromise.concat(allfiles);
    const allfolders = [];
    projectsId.forEach(proId => {
      foldersId.map(item => {
        allfolders.push(wx.cloud.callFunction({
          name: 'projectUpdate',
          data: {
            addAllFolder: true,
            proId: proId,
            folderId: item
          }
        }))
      })
    });
    console.log("allfolders: ", allfolders);
    this.data.tasksPromise = this.data.tasksPromise.concat(allfolders);
    console.log(" this.data.tasksPromise : ", this.data.tasksPromise);
  },
  updateCompanyFields(filesId, foldersId, companysId) {
    console.log('-------------------------------updateCompanyFields--------------------------------------')
    const allfiles = [];
    companysId.forEach(companyId => {
      filesId.map(item => {
        allfiles.push(wx.cloud.callFunction({
          name: 'companyUpdate',
          data: {
            addFiles: true,
            companyId: companyId,
            fileId: item
          }
        }));
      });
    });
    console.log("allfiles: ", allfiles);
    this.data.tasksPromise = this.data.tasksPromise.concat(allfiles);
    const allfolders = [];
    companysId.forEach(companyId => {
      foldersId.map(item => {
        allfolders.push(wx.cloud.callFunction({
          name: 'companyUpdate',
          data: {
            addFolders: true,
            companyId: companyId,
            folderId: item
          }
        }))
      })
    });
    console.log("allfolders: ", allfolders);
    this.data.tasksPromise = this.data.tasksPromise.concat(allfolders);
    console.log(" this.data.tasksPromise : ", this.data.tasksPromise);
  },

})