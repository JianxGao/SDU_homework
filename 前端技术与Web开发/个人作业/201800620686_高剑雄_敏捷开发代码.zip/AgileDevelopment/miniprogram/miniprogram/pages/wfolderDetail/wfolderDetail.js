// pages/wfolderDetail/wfolderDetail.js
const app = getApp()
const util = require('../../util/wutils.js');

const images = require('../../util/images.js')
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const taskDB = db.collection('tasks')
const projectDB = db.collection('projects')
const fileDB = db.collection('files')
const folderDB = db.collection('folders')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    screenHeight: app.globalData.screenHeight,
    navigatorH: app.globalData.navigatorH,
    statusBarHeight: app.globalData.statusBarHeight,
    isLogin: app.globalData.login,
    images: images,
    disable: true,
    // checkedLength: 0
  }, 

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("options: ", options)
    let folderId = options.folderId;
    this.setData({folderId: folderId});
    if (options.addLink) {
      this.setData({ addLink: true});
      if (options.taskId) { this.setData({ taskId: options.taskId})}
      if (options.eventId) { this.setData({ eventId: options.eventId }) }
    }
    if (options.view) { this.setData({ view: true})}
  },

  onShow: function () {
    console.log("------------------------------------------onshow---------------------------------------")
    let _this = this;
    if (this.data.addLink) {
      //checkedFileInfo, checkedFolderInfo
      let checkedFileInfo = app.globalData.checkedFileInfo || [];//已经选中的文件
      let checkedFileLength = app.globalData.checkedFileInfo ? app.globalData.checkedFileInfo.length : 0
      let checkedFolderLength = app.globalData.checkedFolderInfo ? app.globalData.checkedFolderInfo.length : 0
      let checkedFolderInfo = app.globalData.checkedFolderInfo || [];//已经选中的文件夹
      this.setData({
        checkedLength: checkedFileLength + checkedFolderLength,
        preCheckedLength: checkedFileLength + checkedFolderLength, currentPageChecked: 0,
        checkedFileInfo: checkedFileInfo, precheckedFileInfo: checkedFileInfo,
        checkedFolderInfo: checkedFolderInfo, precheckedFolderInfo: checkedFolderInfo
      })
    }
    folderDB.doc(this.data.folderId).get().then(res => {
      console.log(res.data)
      _this.setData({
        folderInfo: res.data,
        proNode: res.data.proNode,
        layer: res.data.layer,
        savePath: app.globalData.openid + '/' + this.data.folderId + '/'
      });
      if (res.data.subfiles && res.data.subfiles.length > 0) {
        _this.setData({
          filesId: res.data.subfiles,
        })
        let promiseTasks = res.data.subfiles.map(item => { return fileDB.doc(item).get() });
        Promise.all(promiseTasks).then(res => {
          console.log(res);
          let filesInfo = res.map(item => { return item.data });
          filesInfo.map(item => { return item.isRotate = false});
          //查看app.globalData.checkedFileInfo里的信息
          app.globalData.checkedFileInfo ? 
            filesInfo.map(item => {
              if (app.globalData.checkedFileInfo.filter(checkedItem => { return checkedItem._id === item._id }).length > 0) {
                return item.checked = true;
              } else {
                return item.checked = false
              }
            }) : filesInfo.map(item => { return item.checked = false })
          _this.setData({filesInfo: filesInfo})
        })
      } else {
      }
      if (res.data.subfolders && res.data.subfolders.length > 0) {
        _this.setData({
          foldersId: res.data.subfolders,
        })
        let promiseTasks = res.data.subfolders.map(item => { return folderDB.doc(item).get() });
        Promise.all(promiseTasks).then(res => {
          console.log(res);
          let foldersInfo = res.map(item => { return item.data });
          let foldersNameList = foldersInfo.map(item => {return item.name});
          foldersInfo.map(item => { return item.isRotate = false})
          //查看app.globalData.checkedFolderInfo
          app.globalData.checkedFolderInfo ?
            foldersInfo.map(item => {
              if (app.globalData.checkedFolderInfo.filter(checkedItem => { return checkedItem._id === item._id }).length > 0) {
                return item.checked = true;
              } else {
                return item.checked = false
              }
            }) : foldersInfo.map(item => { return item.checked = false })
          _this.setData({foldersInfo: foldersInfo,foldersNameList: foldersNameList})
        })
      } else {
      }
    })

  },

  inputFolderName: function (e) {
    let value = e.detail.value;
    console.log(value)
    let foldersNameList = this.data.foldersNameList
    if (this.data.foldersNameList) {
      if (foldersNameList.indexOf(value) === -1 && value.length > 0) {
        this.setData({
          folderName: value,
          disable: false
        })
      } else if (value.length === 0) {
        wx.showToast({
          title: '文件夹名不能为空。',
          icon: 'none'
        });
        this.setData({
          disable: true
        })
      } else {
        wx.showToast({
          title: '该文件夹已存在，请更换名称。',
          icon: 'none'
        });
        this.setData({
          disable: true
        })
      }
    } else {
      if (value.length === 0) {
        wx.showToast({
          title: '文件夹名不能为空。',
          icon: 'none'
        });
        this.setData({
          disable: true
        });
        return
      }
      this.setData({
        folderName: value,
        disable: false
      })
    }
  },
  updateCProjectFields(folderId, proNode) {
    console.log("------------------------------updateProjectFields-----------------------------")
    const allfolders = proNode.map(proId => {
      return wx.cloud.callFunction({
        name: 'projectUpdate',
        data: {
          addAllFolder: true,
          proId: proId,
          folderId: folderId
        }
      });
    })
    console.log("allfolders: ", allfolders);
    this.data.tasksPromise = this.data.tasksPromise.concat(allfolders);
    console.log("tasksPromise： ", this.data.tasksPromise);
  },
  updateUserFields(folderId) {
    console.log("------------------------------updateUserFields-----------------------------")
    const folders = wx.cloud.callFunction({
      name: 'userUpdate',
      data: {
        addFolder: true,
        userId: app.globalData.openid,
        folderId: folderId
      }
    });
    console.log("folders: ", folders);
    this.data.tasksPromise.push(folders);
    console.log("tasksPromise： ", this.data.tasksPromise);
  },
  updateCompanysFields(folderId, companysId) {
    console.log("------------------------------updateCompanysFields-----------------------------")
    const files = companysId.map(companyId => {
      return wx.cloud.callFunction({
        name: 'companyUpdate',
        data: {
          addFolders: true,
          companyId: companyId,
          folderId: folderId
        }
      });
    })
    console.log("files: ", files);
    this.data.tasksPromise = this.data.tasksPromise.concat(files);
    console.log("tasksPromise: ", this.data.tasksPromise)
  },
  updateCFolderFields(foldersId, parentFolderId, folderId) {
    console.log("------------------------------updateFolderFields-----------------------------")
    console.log("foldersId: ", foldersId, ",parentFolderId: ", parentFolderId)
    const subfolders = wx.cloud.callFunction({
      name: 'folderUpdate',
      data: {
        addSubFolders: true,
        folderId: parentFolderId,
        subFolderId: folderId
      }
    });
    console.log("subfolders: ", subfolders);
    this.data.tasksPromise.push(subfolders);
    const folders = foldersId.map(item => {
      return wx.cloud.callFunction({
        name: 'folderUpdate',
        data: {
          addFolders: true,
          folderId: item,
          subFolderId: folderId
        }
      })
    });
    console.log("folders: ", folders);
    this.data.tasksPromise = this.data.tasksPromise.concat(folders);
    console.log("tasksPromise: ", this.data.tasksPromise)
  },
  createFolder: function (e) {
    let _this = this;
    let proNode = _this.data.folderInfo.proNode;//所属项目
    let folderNode = _this.data.folderInfo._id;//所属文件夹，直接
    let allfolderNode = _this.data.folderInfo.allfolderNode ? _this.data.folderInfo.allfolderNode.concat(_this.data.folderInfo._id)
      : [_this.data.folderInfo._id] //所属文件夹，全部
    wx.showLoading({
      title: '创建中...',
    })
    wx.cloud.callFunction({
      name: 'addDoc',
      data: {
        addFolder: true,
        data: {
          name: _this.data.folderName,//文件夹名称
          creator: app.globalData.openid,//创建者
          creationTime: new Date().valueOf(),//创建时间
          proNode: proNode,//所属项目
          companys: _this.data.folderInfo.companys,//所属班级
          members: _this.data.folderInfo.members,//项目成员
          layer: _this.data.layer + 1,
          folderNode: folderNode,//父文件夹，直接
          allfolderNode: allfolderNode,//所属文件夹，全部
          addPermission: Array.from(new Set(_this.data.folderInfo.addPermission).add(app.globalData.openid)),//添加内容权限
          deletePermission: Array.from(new Set(_this.data.folderInfo.deletePermission).add(app.globalData.openid)),//删除项目及其内容权限
          modifyPermission: Array.from(new Set(_this.data.folderInfo.modifyPermission).add(app.globalData.openid)),//修改内容权限
        }
      }
    }).then(res => {
      console.log(res);
      //记录所创建文件的id
      const folderId = res.result._id;
      _this.setData({ folderId: folderId, tasksPromise: [] });
      //更新项目表；projects: folders, allfolders;
      _this.updateCProjectFields(folderId, proNode);
      //更新用户表；user: folders
      _this.updateUserFields(folderId);
      //更新班级表；companys: folders
      _this.updateCompanysFields(folderId, _this.data.folderInfo.companys);
      if (allfolderNode.length > 0 && folderNode) {
        //更新文件夹表；folders：subfolders, folders
        _this.updateCFolderFields(allfolderNode, folderNode, folderId)
      }
      Promise.all(_this.data.tasksPromise).then(res => {
        util.getFoldersInfo([folderId].concat(_this.data.foldersId || [])).then(res => {
          let foldersInfo = res.map(item => { return item.data });
          foldersInfo.map(item => { return item.isRotate = false })
          _this.setData({
            foldersInfo: foldersInfo,
          });
          wx.hideLoading()
          _this.setData({
            createFolder: false
          })
        })
      })
    })
  },
  closeMask: function () {
    this.setData({
      createFolder: false
    })
  },
  folderDetail: function (e) {
    if (this.data.editingFile) {
      return;
    }
    if(this.data.addLink) {
      let checkedLength = this.data.checkedLength
      const folderId = e.currentTarget.dataset.folderid
      // const taskId = this.data.taskId
      // wx.navigateTo({
      //   url: '../wfolderDetail/wfolderDetail?folderId=' + folderId + '&addLink=0&checkedLength=' + checkedLength + '&taskId=' + taskId,
      // });
      if (this.data.taskId) {
        let taskId = this.data.taskId;
        wx.navigateTo({ url: '../wfolderDetail/wfolderDetail?folderId=' + folderId + '&addLink=0&checkedLength=' + checkedLength + '&taskId=' + taskId });
      }
      if (this.data.eventId) {
        let eventId = this.data.eventId;
        wx.navigateTo({ url: '../wfolderDetail/wfolderDetail?folderId=' + folderId + '&addLink=0&checkedLength=' + checkedLength + '&eventId=' + eventId });
      }
      return;
    }
    const folderId = e.currentTarget.dataset.folderid
    wx.navigateTo({
      url: '../wfolderDetail/wfolderDetail?folderId=' + folderId,
    })
  },
  addFolder: function () {
    this.setData({
      createFolder: true
    })
  },
  rotateBtn: function (e) {
    console.log("旋转按钮");
    const dataset = e.currentTarget.dataset;
    console.log(dataset)
    let filesInfo = this.data.filesInfo || []
    let foldersInfo = this.data.foldersInfo || []
    if (dataset.fileid) {
      const fileid = dataset.fileid
      const index = filesInfo.indexOf(filesInfo.filter(item => { return item._id === fileid })[0]);
      console.log(index);
      filesInfo[index].isRotate = !filesInfo[index].isRotate;
      filesInfo.filter(item => { return item._id != fileid }).map(item => { return item.isRotate = false })
      foldersInfo.map(item => { return item.isRotate = false })
    } else if (dataset.folderid) {
      const folderid = dataset.folderid
      const index = foldersInfo.indexOf(foldersInfo.filter(item => { return item._id === folderid })[0]);
      console.log(index);
      foldersInfo[index].isRotate = !foldersInfo[index].isRotate;
      foldersInfo.filter(item => { return item._id != folderid }).map(item => { return item.isRotate = false })
      filesInfo.map(item => { return item.isRotate = false })
    }
    this.setData({
      filesInfo: filesInfo,
      foldersInfo: foldersInfo,
    })
  },
  // edit event
  leaveEditFile: function () {
    console.log("退出编辑文件状态");
    let filesInfo = this.data.filesInfo || []
    let foldersInfo = this.data.foldersInfo || []
    filesInfo.map(item => { return item.isRotate = false })
    foldersInfo.map(item => { return item.isRotate = false })
    this.setData({
      editingFile: false,
      filesInfo: filesInfo,
      foldersInfo: foldersInfo
    });
  },
  enterEditFile: function () {
    console.log("进入编辑文件状态");
    this.setData({
      editingFile: true
    })
  },
  delfolder: function(e) {
    console.log("删除文件夹：", e);
    wx.showLoading({
      title: '删除中...',
    })
    let _this = this;
    const folderId = e.currentTarget.dataset.folderid;
    let tasks = [];
    folderDB.doc(folderId).get().then(res => {
      let layer = res.data.layer;
      let creator = res.data.creator;
      let proId = res.data.proNode;
      let parentFolderId = res.data.parentNode[layer-1];
      console.log("父文件夹节点：", parentFolderId)
      util.deleteFolderOperation(folderId, creator, proId, layer, parentFolderId, _this);
    })
  },
  /**
  * 上传文件
  */
  uploadFile: function () {
    let _this = this;
    
    wx.chooseMessageFile({
      count: 1,
      type: 'all',
      success(res) {
        console.log("chooseMessageFile:", res)
        const tempFilePath = res.tempFiles[0].path
        const tempFileName = res.tempFiles[0].name
        const setTempFileName = new Date().valueOf() + res.tempFiles[0].name
        console.log('choose: ', res, tempFileName)
        wx.showLoading({
          title: '加载中...',
          icon: 'none'
        })
        _this.setData({
          size: util.getFileSize(res.tempFiles[0].size)
        })
        const savePath = _this.data.savePath;
        console.log("save path: ", savePath)
        wx.cloud.uploadFile({
          cloudPath: savePath + setTempFileName,
          filePath: tempFilePath,
          success: res => {
            console.log("getFileDownloadUrl..........................................")
            _this.getFileDownloadUrl(res.fileID, tempFileName)
          },
          fail: res => {
            wx.showToast({
              title: '失败',
              icon: 'warn',
              duration: 2000
            })
          }
        })
      },
      fail: res => {
        console.log(res)
      }
    })
  },
  /**
   * 获取文件的下载链接
   */
  getFileDownloadUrl: function (fileID, tempFileName) {
    console.log("获取文件的下载链接", fileID, tempFileName)
    let _this = this;
    let proNode = _this.data.folderInfo.proNode;//所属项目
    let companysId = _this.data.folderInfo.companys;//所属班级
    let membersId = _this.data.folderInfo.members;
    let folderNode = _this.data.folderInfo._id;//所属文件夹，直接
    let allfolderNode = _this.data.folderInfo.allfolderNode ? _this.data.folderInfo.allfolderNode.concat(_this.data.folderInfo._id)
      : [_this.data.folderInfo._id] //所属文件夹，全部
    let layer = _this.data.layer + 1;
    // let taskNode = _this.data.folderInfo.taskNode;//关联的任务
    //addPermission, deletePermission, modifyPermission
    let addPermission = _this.data.folderInfo.addPermission;
    let deletePermission = _this.data.folderInfo.deletePermission;
    let modifyPermission = _this.data.folderInfo.modifyPermission;

    wx.showLoading({
      title: '上传中...',
    })
    console.log("dddd:", fileID, tempFileName, layer)
    //fileID, tempFileName, _this, layer, folderNode, allFolderNode,membersId, proNode, companysId
    util.getDownloadUrl(fileID, tempFileName, _this, layer, 
      folderNode, allfolderNode, membersId, proNode, companysId, null, null,
      addPermission, deletePermission, modifyPermission);
  },
  fileDetail: function (e) {
    if (this.data.editingFile) {
      return;
    }
    console.log(e)
    const fileId = e.currentTarget.dataset.fileid;
    wx.navigateTo({
      url: '../wfileDetail/wfileDetail?fileId=' + fileId,
    })
  },

  updateDFileField(fileId, filePath, projectsId, foldersId) {
    console.log("-------------------------------updateDFFilesFields-----------------------------");
    if (filePath) {
      //删除没有关联的文件
      const deleteunlinkfiles = wx.cloud.deleteFile({
        fileList: [filePath]
      });
      this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(deleteunlinkfiles);
      console.log("deleteunlinkfiles: ", deleteunlinkfiles);
      //删除记录
      let removeFiles = wx.cloud.callFunction({
        name: 'fileUpdate',
        data: {
          removeFile: true,
          fileId: fileId,
        }
      });
      this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(removeFiles);
      console.log("removeFiles: ", removeFiles);
      console.log("  this.data.tasksDFilePromise ", this.data.tasksDFilePromise)
      return;
    }
    //对关联的文件linkFiles，移除本项目节点
    let proNode = projectsId.map(item => {
      return wx.cloud.callFunction({
        name: 'fileUpdate',
        data: {
          removeProNode: true,
          fileId: fileId,
          proId: item
        }
      });
    })
    this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(proNode);
    console.log("proNode: ", proNode);
    let folderNode = foldersId.map(item => {
      return wx.cloud.callFunction({
        name: 'fileUpdate',
        data: {
          removeFolderNode: true,
          fileId: fileId,
          folderId: item
        }
      })
    });
    this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(folderNode);
    console.log("folderNode: ", folderNode);
    console.log("this.data.tasksDFilePromise ", this.data.tasksDFilePromise)
  },
  updateDProjectsFiels(fileId, projectsId) {
    console.log("-------------------------------------updateDProjectsFiels-----------------------------------")
    const files = projectsId.map(proId => {
      return wx.cloud.callFunction({
        name: 'projectUpdate',
        data: {
          removeFile: true,
          proId: proId,
          fileId: fileId
        }
      });
    })
    console.log("files: ", files);
    this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(files);
    console.log("this.data.tasksDFilePromise: ", this.data.tasksDFilePromise);
  },
  updateDUserFields(fileId, membersId) {
    console.log("-------------------------------------updateDUserFields-----------------------------------")
    const files = membersId.map(item => {
      return wx.cloud.callFunction({
        name: 'userUpdate',
        data: {
          removeFile: true,
          userId: item,
          fileId: fileId
        }
      })
    });
    console.log("files: ", files);
    this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(files);
    console.log("this.data.tasksDFilePromise: ", this.data.tasksDFilePromise);
  },
  updateDComanyFields(fileId, companysId) {
    console.log("----------------------------------updateDComanyFields--------------------------------------------");
    const files = companysId.map(item => {
      return wx.cloud.callFunction({
        name: 'companyUpdate',
        data: {
          removeFiles: true,
          companyId: item,
          fileId: fileId
        }
      })
    });
    console.log("files: ", files);
    this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(files);
    console.log("this.data.tasksDFilePromise: ", this.data.tasksDFilePromise);
  },
  updateDTaskEventFields(fileId, tasksId, eventsId) {
    console.log("-------------------------------updateDTaskEventFields--------------------------------------");
    const tasksprivateFiles = tasksId.map(item => {
      return wx.cloud.callFunction({
        name: 'taskUpdate',
        data: {
          addPrivateFiles: true,
          taskId: item,
          fileId: fileId
        }
      })
    });
    console.log("tasksprivateFiles: ", tasksprivateFiles);
    this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(tasksprivateFiles);
    const eventprivateFiles = eventsId.map(item => {
      return wx.cloud.callFunction({
        name: 'eventUpdate',
        data: {
          addPrivateFiles: true,
          eventId: item,
          fileId: fileId
        }
      })
    });
    console.log("eventprivateFiles: ", eventprivateFiles);
    this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(eventprivateFiles);
    console.log("this.data.tasksDFilePromise: ", this.data.tasksDFilePromise);
  },
  updateDFolderFields(fileId, foldersId) {
    console.log("-----------------------------updateDFolderFields---------------------------------")
    let files = foldersId.map(item => {
      return wx.cloud.callFunction({
        name: 'folderUpdate',
        data: {
          removeFile: true,
          folderId: item,
          fileId: fileId
        }
      })
    });
    console.log("files: ", files);
    this.data.tasksDFilePromise = this.data.tasksDFilePromise.concat(files);
    console.log("this.data.tasksDFilePromise: ", this.data.tasksDFilePromise);
  },
  delfile: function (e) {
    console.log("删除文件：", e);
    wx.showLoading({
      title: '删除中...',
    })
    let _this = this;
    const fileId = e.currentTarget.dataset.fileid;
    fileDB.doc(fileId).get().then(res => {
      let fileIDpath = res.data.fileID;
      let creatorId = res.data.creator;
      let layer = res.data.layer;
      let projectsId = res.data.proNode;//所属项目
      let companysId = res.data.companys;//所属班级
      let tasksId = res.data.taskNode || [];//所属任务
      let eventsId = res.data.eventNode || []; //所属日程
      let membersId = res.data.members;//成员
      let parentFolders = res.data.allFolderNode || [];//全部父文件夹 
      _this.setData({ tasksDFilePromise: [] });
      
      if (tasksId.length === 0 && eventsId.length === 0) {
        //更新files：根据是否有关联判断是否删除记录
        _this.updateDFileField(fileId, fileIDpath, projectsId, parentFolders);
        //更新projects：files
        _this.updateDProjectsFiels(fileId, projectsId);
        //更新user：files
        _this.updateDUserFields(fileId, membersId);
        //更新companys：files
        _this.updateDComanyFields(fileId, companysId);
        //更新folders：files，subfiles
        _this.updateDFolderFields(fileId, parentFolders)
      } else {
        //更新files：关联文件只更新proNode节点
        _this.updateDFileField(fileId, null, projectsId, parentFolders);
        //更新projects
        _this.updateDProjectsFiels(fileId, projectsId);
        //更新folders：files，subfiles
        _this.updateDFolderFields(fileId, parentFolders)
      }
      Promise.all(_this.data.tasksDFilePromise).then(res => {
        console.log("删除成功....");
        let filesInfo = _this.data.filesInfo.filter(item => { return item._id != fileId });
          console.log(_this.data.filesInfo, filesInfo)
          _this.setData({
            filesInfo: filesInfo,
            filesId: filesInfo.map(item => { return item._id })
          })
          wx.hideLoading();
        })
    })
  },
  updateCheckedItem(e) {
    const dataset = e.currentTarget.dataset;
    let filesInfo = this.data.filesInfo || [];
    let foldersInfo = this.data.foldersInfo || [];
    let preCheckedLength = this.data.preCheckedLength;
    if (dataset.fileid) {
      console.log("------------------------------------file tap---------------------------------")
      const fileId = dataset.fileid;
      //该界面的文件
      if (filesInfo.filter(item => { return item._id === fileId }).length > 0) {
        filesInfo.filter(item => { return item._id === fileId }).map(item => { return item.checked = !item.checked });//更新该界面的文件
        let length = filesInfo.concat(foldersInfo).filter(item => { return item.checked === true }).length;//更新该界面选中文件的个数
        let currentCheckedFileInfo = filesInfo.filter(item => { return item.checked === true });//更新该界面选中的文件信息
        let checkedFileInfo = this.data.precheckedFileInfo.concat(currentCheckedFileInfo)//
        console.log("currentCheckedFileInfo: ", currentCheckedFileInfo)
        console.log("pre checkedFileInfo: ", this.data.precheckedFileInfo)
        console.log("checkedFileInfo: ", checkedFileInfo);
        app.globalData.checkedFileInfo = checkedFileInfo;//添加或删除
        console.log(" 该界面的文件 app.globalData.checkedFileInfo: ", app.globalData.checkedFileInfo)
        this.setData({ filesInfo: filesInfo, currentPageChecked: length, checkedFileInfo: checkedFileInfo })
      } else {
        app.globalData.checkedFileInfo = app.globalData.checkedFileInfo.filter(item => {return item._id != fileId});//删除
        this.setData({ checkedFileInfo: app.globalData.checkedFileInfo, precheckedFileInfo: app.globalData.checkedFileInfo});
        console.log(" 其他 app.globalData.checkedFileInfo: ", app.globalData.checkedFileInfo)
      }
    } else if (dataset.folderid) {
      console.log("------------------------------------folder tap---------------------------------")
      const folderId = dataset.folderid;
      if (foldersInfo.filter(item => { return item._id === folderId }).length > 0) {
        foldersInfo.filter(item => { return item._id === folderId }).map(item => { return item.checked = !item.checked });
        let length = filesInfo.concat(foldersInfo).filter(item => { return item.checked === true }).length;
        let currentCheckedFolderInfo = foldersInfo.filter(item => { return item.checked === true });
        let checkedFolderInfo = this.data.precheckedFolderInfo.concat(currentCheckedFolderInfo);
        console.log("currentCheckedFolderInfo: ", currentCheckedFolderInfo)
        console.log("pre checkedFolderInfo: ", this.data.precheckedFolderInfo)
        console.log("checkedFolderInfo: ", checkedFolderInfo);
        app.globalData.checkedFolderInfo = checkedFolderInfo;//添加或删除
        console.log(" 该界面的文件 app.globalData.checkedFolderInfo: ", app.globalData.checkedFolderInfo)
        this.setData({ foldersInfo: foldersInfo, currentPageChecked: length, checkedFolderInfo: checkedFolderInfo })
      } else {
        app.globalData.checkedFolderInfo = app.globalData.checkedFolderInfo.filter(item => { return item._id != folderId });//删除
        this.setData({ checkedFolderInfo: app.globalData.checkedFolderInfo, precheckedFolderInfo: app.globalData.checkedFolderInfo });
        console.log(" 其他 app.globalData.checkedFolderInfo: ", app.globalData.checkedFileInfo)
      }
    }
    let checkedFileLength = app.globalData.checkedFileInfo ? app.globalData.checkedFileInfo.length : 0
    let checkedFolderLength = app.globalData.checkedFolderInfo ? app.globalData.checkedFolderInfo.length : 0
    console.log("apapp.globalData.checkedFileInfo.length: ", checkedFileLength);
    console.log("apapp.globalData.checkedFolderInfo.length: ", checkedFolderLength);
    this.setData({ checkedLength: checkedFileLength + checkedFolderLength})
  },
  closeMask() { this.setData({ display: false }) },
  openMask() { if (this.data.checkedLength > 0) this.setData({ display: true }) },
  goBack() {
    wx.navigateBack({
      delta: 1 
    })
  },
  confirmLink() {
    let _this = this;
    console.log("app.globalData.checkedFileInfo: ", app.globalData.checkedFileInfo)
    console.log("app.globalData.checkedFolderInfo: ", app.globalData.checkedFolderInfo)

    if (!app.globalData.checkedFileInfo && !app.globalData.checkedFolderInfo) {
      return;
    }
    wx.showLoading({
      title: '关联中...',
    })
    const checkedFilesId = app.globalData.checkedFileInfo ? app.globalData.checkedFileInfo.map(item => { return item._id }) : [];
    const checkFoldersId = app.globalData.checkedFolderInfo ? app.globalData.checkedFolderInfo.map(item => { return item._id }) : [];
    let checkFoldersSubFolderId = [];
    app.globalData.checkedFolderInfo ? app.globalData.checkedFolderInfo.map(item => {
      checkFoldersSubFolderId = checkFoldersSubFolderId.concat(item.folders || [])
    }) : [];
    let checkFoldersSubFilesId = [];
    app.globalData.checkedFolderInfo ? app.globalData.checkedFolderInfo.map(item => {
      checkFoldersSubFilesId = checkFoldersSubFilesId.concat(item.files || [])
    }) : [];
    console.log("checkFoldersSubFolderId: ", checkFoldersSubFolderId)
    console.log("checkFoldersSubFilesId: ", checkFoldersSubFilesId)
    if (this.data.taskId) {
      taskDB.doc(this.data.taskId).get().then(res => {
        let proNode = res.data.proNode;//所属项目
        let companys = res.data.companys; //所属班级
        _this.setData({ tasksPromise: [] });
        //更新任务表；tasks: files, folders
        _this.updateTaskFields(checkedFilesId, checkFoldersId, _this.data.taskId);
        if (checkedFilesId.length > 0) {
          //更新文件表；files: taskNode, proNode, companys
          _this.updateFileFields(checkedFilesId, _this.data.taskId, null, proNode, companys);
        }
        if (checkFoldersId.length > 0) {
          //更新文件夹表；folders: taskNode, proNode, companys
          _this.updateFolderFields(checkFoldersId, _this.data.taskId, null, proNode, companys, checkFoldersSubFolderId);
          _this.updateFileFields(checkFoldersSubFilesId, _this.data.taskId, null, proNode, companys);
        }
        //更细项目表；projects: allfiles, allfolders;
        _this.updateProjectFields(checkedFilesId, checkFoldersId, proNode);
        //更新班级表；companys: files, folders;
        _this.updateCompanyFields(checkedFilesId, checkFoldersId, companys);
        Promise.all(_this.data.tasksPromise).then(res => {
          console.log("关联成功", res);
          app.globalData.checkedFileInfo = [];
          app.globalData.checkedFolderInfo = [];
          wx.hideLoading()
          wx.redirectTo({
            url: '../waddLink/waddLink?taskId=' + _this.data.taskId + '&link=3',
          })
        })
      })
    }
    if (this.data.eventId) {
      eventDB.doc(this.data.eventId).get().then(res => {
        let proNode = res.data.proNode;//所属项目
        let companys = res.data.companys; //所属班级
        _this.setData({ tasksPromise: [] });
        //更新日程表；events: files, folders
        _this.updateEventFields(checkedFilesId, checkFoldersId, _this.data.eventId);
        if (checkedFilesId.length > 0) {
          //更新文件表；files: taskNode, proNode, companys
          _this.updateFileFields(checkedFilesId, null, _this.data.eventId, proNode, companys);
        }
        if (checkFoldersId.length > 0) {
          //更新文件夹表；folders: taskNode, proNode, companys
          _this.updateFolderFields(checkFoldersId, null, _this.data.eventId, proNode, companys, checkFoldersSubFolderId);
          _this.updateFileFields(checkFoldersSubFilesId, null, _this.data.eventId, proNode, companys);
        }
        //更细项目表；projects: allfiles, allfolders;
        _this.updateProjectFields(checkedFilesId, checkFoldersId, proNode);
        //更新班级表；companys: files, folders;
        _this.updateCompanyFields(checkedFilesId, checkFoldersId, companys);
        Promise.all(_this.data.tasksPromise).then(res => {
          console.log("关联成功", res);
          app.globalData.checkedFileInfo = [];
          app.globalData.checkedFolderInfo = [];
          wx.hideLoading()
          wx.redirectTo({ url: '../waddLink/waddLink?eventId=' + _this.data.eventId + '&link=3' })
        })
      })
    }
  },
  updateEventFields(filesId, foldersId, eventId) {
    console.log('-------------------------------updateTaskFields--------------------------------------')
    const files = filesId.map(fileId => {
      return wx.cloud.callFunction({
        name: 'eventUpdate',
        data: {
          addFiles: true,
          eventId: eventId,
          fileId: fileId
        }
      })
    });
    console.log("files: ", files);
    this.data.tasksPromise = this.data.tasksPromise.concat(files);
    const folders = foldersId.map(folderId => {
      return wx.cloud.callFunction({
        name: 'eventUpdate',
        data: {
          addFolders: true,
          eventId: eventId,
          folderId: folderId
        }
      })
    });
    console.log("folders: ", folders);
    this.data.tasksPromise = this.data.tasksPromise.concat(folders);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  updateTaskFields(filesId, foldersId, taskId) {
    console.log('-------------------------------updateTaskFields--------------------------------------')
    const files = filesId.map(fileId => {
      return wx.cloud.callFunction({
        name: 'taskUpdate',
        data: {
          addFiles: true,
          taskId: taskId,
          fileId: fileId
        }
      })
    });
    console.log("files: ", files);
    this.data.tasksPromise = this.data.tasksPromise.concat(files);
    const folders = foldersId.map(folderId => {
      return wx.cloud.callFunction({
        name: 'taskUpdate',
        data: {
          addFolders: true,
          taskId: taskId,
          folderId: folderId
        }
      })
    });
    console.log("folders: ", folders);
    this.data.tasksPromise = this.data.tasksPromise.concat(folders);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  updateFileFields(filesId, taskId, eventId, projectsId, companysId) {
    console.log('-------------------------------updateFileFields--------------------------------------')
    if (taskId) {
      const taskNode = [];
      filesId.map((fileId, index) => {
        taskNode.push(wx.cloud.callFunction({
          name: 'fileUpdate',
          data: {
            addTaskNode: true,
            fileId: fileId,
            taskId: taskId
          }
        }))
        //子文件
        let subfiles = checkFoldersSubFilesId[index];//该id对应文件夹的子文件夹
        subfiles.map(subfileId => {
          taskNode.push(wx.cloud.callFunction({
            name: 'folderUpdate',
            data: {
              addTaskNode: true,
              fileId: subfileId,
              taskId: taskId
            }
          }))
        })
      });
      console.log("taskNode: ", taskNode);
      this.data.tasksPromise = this.data.tasksPromise.concat(taskNode);
    }
    if (eventId) {
      const eventNode = []
      filesId.map((fileId, index) => {
        eventNode.push(wx.cloud.callFunction({
          name: 'fileUpdate',
          data: {
            addEventNode: true,
            fileId: fileId,
            eventId: eventId
          }
        }));
      });
      console.log("eventNode: ", eventNode);
      this.data.tasksPromise = this.data.tasksPromise.concat(eventNode);
    }
    const proNode = [];
    projectsId.forEach(proId => {
      filesId.map(item => {
        proNode.push(wx.cloud.callFunction({
          name: 'fileUpdate',
          data: {
            addProNode: true,
            fileId: item,
            proId: proId
          }
        }))
      })
    });
    console.log("proNode: ", proNode);
    this.data.tasksPromise = this.data.tasksPromise.concat(proNode);
    const companys = [];
    companysId.forEach(companyId => {
      filesId.map(item => {
        companys.push(wx.cloud.callFunction({
          name: 'fileUpdate',
          data: {
            addCompanys: true,
            fileId: item,
            companyId: companyId
          }
        }))
      })
    });
    console.log("companys: ", companys);
    this.data.tasksPromise = this.data.tasksPromise.concat(companys);
    console.log(" this.data.tasksPromise : ", this.data.tasksPromise);
  },
  updateFolderFields(foldersId, taskId, eventId, projectsId, companysId, checkFoldersSubFolderId) {
    console.log('-------------------------------updateFolderFields--------------------------------------')
    //选中的文件夹及其全部的子文件夹，都要更新字段taskNode或eventNode
    let allFoldersId = foldersId.concat(checkFoldersSubFolderId);
    if (taskId) {
      const taskNode = [];
      allFoldersId.map((folderId, index) => {
        taskNode.push(wx.cloud.callFunction({
          name: 'folderUpdate',
          data: {
            addTaskNode: true,
            folderId: folderId,
            taskId: taskId
          }
        }))
      });
      console.log("taskNode: ", taskNode);
      this.data.tasksPromise = this.data.tasksPromise.concat(taskNode);
    }
    if (eventId) {
      const eventNode = []
      allFoldersId.map((folderId, index) => {
        eventNode.push(wx.cloud.callFunction({
          name: 'folderUpdate',
          data: {
            addEventNode: true,
            folderId: folderId,
            eventId: eventId
          }
        }));
      });
      console.log("eventNode: ", eventNode);
      this.data.tasksPromise = this.data.tasksPromise.concat(eventNode);
    }
    const proNode = [];
    projectsId.forEach(proId => {
      allFoldersId.map(item => {
        proNode.push(wx.cloud.callFunction({
          name: 'folderUpdate',
          data: {
            addProNode: true,
            folderId: item,
            proId: proId
          }
        }))
      })
    });
    console.log("proNode: ", proNode);
    this.data.tasksPromise = this.data.tasksPromise.concat(proNode);
    const companys = [];
    companysId.forEach(companyId => {
      allFoldersId.map(item => {
        companys.push(wx.cloud.callFunction({
          name: 'folderUpdate',
          data: {
            addCompanys: true,
            foldersId: item,
            companyId: companyId
          }
        }))
      })
    });
    console.log("companys: ", companys);
    this.data.tasksPromise = this.data.tasksPromise.concat(companys);
    console.log(" this.data.tasksPromise : ", this.data.tasksPromise);
  },
  updateProjectFields(filesId, foldersId, projectsId) {
    console.log('-------------------------------updateProjectFields--------------------------------------')
    const allfiles = [];
    projectsId.forEach(proId => {
      filesId.map(item => {
        allfiles.push(wx.cloud.callFunction({
          name: 'projectUpdate',
          data: {
            addAllFile: true,
            proId: proId,
            fileId: item
          }
        }));
      });
    });
    console.log("allfiles: ", allfiles);
    this.data.tasksPromise = this.data.tasksPromise.concat(allfiles);
    const allfolders = [];
    projectsId.forEach(proId => {
      foldersId.map(item => {
        allfolders.push(wx.cloud.callFunction({
          name: 'projectUpdate',
          data: {
            addAllFolder: true,
            proId: proId,
            folderId: item
          }
        }))
      })
    });
    console.log("allfolders: ", allfolders);
    this.data.tasksPromise = this.data.tasksPromise.concat(allfolders);
    console.log(" this.data.tasksPromise : ", this.data.tasksPromise);
  },
  updateCompanyFields(filesId, foldersId, companysId) {
    console.log('-------------------------------updateCompanyFields--------------------------------------')
    const allfiles = [];
    companysId.forEach(companyId => {
      filesId.map(item => {
        allfiles.push(wx.cloud.callFunction({
          name: 'companyUpdate',
          data: {
            addFiles: true,
            companyId: companyId,
            fileId: item
          }
        }));
      });
    });
    console.log("allfiles: ", allfiles);
    this.data.tasksPromise = this.data.tasksPromise.concat(allfiles);
    const allfolders = [];
    companysId.forEach(companyId => {
      foldersId.map(item => {
        allfolders.push(wx.cloud.callFunction({
          name: 'companyUpdate',
          data: {
            addFolders: true,
            companyId: companyId,
            folderId: item
          }
        }))
      })
    });
    console.log("allfolders: ", allfolders);
    this.data.tasksPromise = this.data.tasksPromise.concat(allfolders);
    console.log(" this.data.tasksPromise : ", this.data.tasksPromise);
  },
})