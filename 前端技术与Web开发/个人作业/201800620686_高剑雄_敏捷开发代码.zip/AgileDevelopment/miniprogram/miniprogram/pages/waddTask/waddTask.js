// pages/waddTask/waddTask.js
let app = getApp()
const util = require('../../util/wutils.js');
const wclass = require('../../util/wclass.js')
var dateTimePicker = require('../../util/dateTimePicker.js');
const images = require('../../util/images.js')
//获取数据库引用 
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
Page({ 
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    taskname: null,
    user: null,
    start: null,
    end: null,
    projectInfo: null,
    selectedProject: null,
    images: images,
    currentCompany: app.globalData.currentCompany,
    //picker
    //设置时间相关
    dateTimeArray: null,
    // dateTime: null,
    endDateTime: null,
    startDateTime: null,
    startYear: 2019,
    endYear: 2050,
    display: false,
    disabled: true,
  },
 
  inputTask: function(e) {
    const alltasksNameList = this.data.alltasksNameList;
    var value = e.detail.value;
    //
    if (!this.data.projectInfo) {
      wx.showToast({
        title: '请先选择一个项目。',
        icon: 'none'
      })
      return;
    } else {
      if (this.data.alltasksNameList) {
        if (alltasksNameList.indexOf(value) === -1 && value.length > 0) {
          this.setData({
            taskname: value,
            disabled: false
          })
        } else if (value.length === 0) {
          wx.showToast({
            title: '任务标题不能为空。',
            icon: 'none'
          });
          this.setData({
            disabled: true
          })
        } else {
          wx.showToast({
            title: '该任务已存在，请更换任务名称。',
            icon: 'none'
          });
          this.setData({
            disabled: true
          })
        }
      } else {
        this.setData({
          taskname: value,
          disabled: false
        })
      }
    }
  },

  /**
   * 查询用户项目的信息
   */
  getProjectsInfo: function (projectsId) {
    let _this = this
    let tasks = []
    for (let i = 0; i < projectsId.length; i++) {
      const promise = projectDB.doc(projectsId[i]).get()
      tasks.push(promise)
    }
    Promise.all(tasks).then(res => {
      // console.log(res)
      let projectsInfo = res.map(item => { return item.data })
      _this.setData({
        selectedProject: projectsInfo
      })
      // console.log(_this.data.selectedProject)
    }).catch(res => {
      // console.log(res)
    })
  },
  onLoad: function (options) {
    let _this = this
    // 获取完整的年月日 时分，以及默认显示的数组
    var obj = dateTimePicker.dateTimePicker(this.data.startYear, this.data.endYear);
    var dateArr = obj.dateTimeArray;
    var startarr = obj.dateTime;
    console.log(startarr);
    var endarr = startarr.map(item => {if(startarr.indexOf(item) === 3) {return item + 1} return item});
    console.log(startarr.map(item => { if (startarr.indexOf(item) === 3) { return item + 1 } return item }))
    console.log(endarr)
    this.setData({
      startDateTime: startarr,
      endDateTime: endarr,
      dateTimeArray: dateArr
    })
    // 获取当前时间
    this.setData({
      startTime: _this.getTime(dateArr, startarr),
      start: new Date(_this.getTime(dateArr, startarr)).valueOf(),
      endTime: _this.getTime(dateArr, endarr),
      end: new Date(_this.getTime(dateArr, endarr)).valueOf(),
    });
    //查询user
    userDB.doc(app.globalData.openid).get({
      success: function (res) {
        let user = res.data;
        //初始的执行者信息
        _this.getExecutorInfo(user._id);
        _this.setData({
          user: user,
          //默认的执行者
          executor: user._id,
          //默认的参与者（user）
          _MembersId: [user._id],
        })
        util.getMembersInfo(_this, _this.data._MembersId)
        // console.log(_this.data.membersId)
      }
    })
    console.log(options)
    if (options.proId) {
      this.setData({
        label: options.label
      })
      //查询project
      projectDB.doc(options.proId).get({
        success: function (res) {
          wclass.getProjectsTasksName([options.proId], _this);
          /*
          // console.log(res.data);
          //全部任务节点
          let tasksNodeObj = res.data.tasksnode;
          let alltasksNode = tasksNodeObj[0].concat(tasksNodeObj[1]).concat(tasksNodeObj[2])
          _this.setData({
            alltasksNode: alltasksNode
          });
          if (alltasksNode && alltasksNode.length > 0) {
            let tasks = alltasksNode.map(item => { return taskDB.doc(item).get() });
            Promise.all(tasks).then(res => {
              let tasksNameList = res.map(item => {return item.data.name});
              console.log(tasksNameList);
              _this.setData({
                tasksNameList: tasksNameList
              })
            })
          }*/
          let projectInfo = res.data;
          _this.setData({
            projectInfo: projectInfo
          });
        }
      })
    } else {
      // console.log("直接添加任务");
      this.setData({
        directly: true
      })
      //获取该用户参与的所有项目
      userDB.doc(app.globalData.openid).get()
        .then(res => {
          // console.log(res.data.projects);
          this.setData({
            _AllProjectsId: res.data.projects
          })
          this.getProjectsInfo(_this.data._AllProjectsId)
        })
    }
  },

  /**
    * 
    */
  changeStartDateTime(e) { 
    console.log("changeStartDateTime: ", e.detail.value)
    let _this = this;
    let startTime = _this.getTime(_this.data.dateTimeArray, _this.data.startDateTime);
    let startTimestamp = new Date(startTime).valueOf();
    if (startTimestamp > this.data.end) {
      this.setData({
        endTime: "请设置结束时间",
        end: null,
        startTime: startTime,
        start: startTimestamp
      })
    } else {
      this.setData({
        startTime: startTime,
        start: startTimestamp
      });
    }    
  },
  changeStartDateTimeColumn(e) {
    // console.log("changeStartDateTimeColumn: ", e)
    let _this = this
    var arr = this.data.startDateTime, dateArr = this.data.dateTimeArray;
    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    this.setData({
      // startDateTime: arr,
      dateTimeArray: dateArr
    })
  },
  /**
   * 
   */ 
  changeEndDateTime(e) {
    let _this = this
    console.log("changeEndDateTime: ", e.detail.value, _this.data.endDateTime)
    let endTime = _this.getTime(_this.data.dateTimeArray, e.detail.value);
    console.log(endTime, )
    let endTimestamp = new Date(endTime).valueOf();
    if (endTimestamp < this.data.start) {
      wx.showToast({
        title: ' 设置时间无效！',
        icon: "none",
      })
      if (_this.data.oldEndDateTime) {
        console.log(_this.data.endDateTime, _this.data.oldEndDateTime)
        _this.setData({
          endDateTime: _this.data.oldEndDateTime.split(",").map(item => { return Number(item) })
        })
        console.log(_this.data.oldEndDateTime.split(",").map(item => { return Number(item) }), _this.data.endDateTime)
      }
    } else {
      this.setData({
        endTime: endTime,
        end: endTimestamp
      });
    }
  },
  changeEndDateTimeColumn(e) {
    let _this = this
    console.log("changeDateTimeColumn: ", e)
    var arr = this.data.endDateTime, dateArr = this.data.dateTimeArray;
    this.setData({
      oldEndDateTime: arr.toString()
    })
    console.log("ols: ", this.data.oldEndDateTime)
    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    this.setData({
      // endDateTime: arr,
      dateTimeArray: dateArr
    })
   
  },
  getTime: function (dateArr, arr) {
    var _year = dateArr[0][arr[0]];
    var _month = dateArr[1][arr[1]];
    var _day = dateArr[2][arr[2]];
    var _hour = dateArr[3][arr[3]];
    var _minute = dateArr[4][arr[4]];
    return `${_year}-${_month}-${_day} ${_hour}:${_minute}`
  },
  getExecutorInfo: function (executorId) {
    // console.log(executorId)
    let _this = this;
    if (executorId) {
      userDB.doc(executorId).get().then(res => {
        // console.log("detail 执行者：", res.data)
        _this.setData({
          executorInfo: res.data
        })
      }).catch(res => {
        console.log(res)
      })
    } else {
      _this.setData({
        executorInfo: null
      })
    }
  },

  getMembersId : function (newmembersId) {
    let _this = this;
    // console.log(_this.data._MembersId)
    let _MembersIdSet = new Set(_this.data._MembersId);
    for (let i=0; i<newmembersId.length; i++) {
      _MembersIdSet.add(newmembersId[i]);
      // console.log(`添加第${i}个成员的id：`, newmembersId[i])
      _this.setData({
        _MembersId: Array.from(_MembersIdSet)
      })
    }
  },
  onShow: function() {
    // console.log("项目信息：", this.data.projectInfo)
    let _this = this
    //获取执行者的信息 
    this.getExecutorInfo(this.data.executor)
    //根据新添加的执行者讨论是否需要添加成员
    if (this.data.executor && this.data.executor != app.globalData.openid) {
      util.getMembersInfo(_this, [app.globalData.openid, this.data.executor])
      this.getMembersId([app.globalData.openid, this.data.executor])
      // console.log("成员的全部id：", this.data._MembersId)
    }
    //checkedMembersId是由addFollower界面传过来的参数：添加的成员的id
    if (this.data.checkedMembersId) {
      let _MembersId = this.data._MembersId.concat(this.data.checkedMembersId).filter((element, index, self) => {
        //indexOf只返回元素在数组中第一次出现的位置，如果与元素位置不一致，说明该元素在前面已经出现过，是重复元素
        return self.indexOf(element) == index; 
      })
      this.setData({
        _MembersId: _MembersId
      })
      // console.log("合并之后：", this.data._MembersId);
      //获取参与者的全部信息
      util.getMembersInfo(_this, this.data._MembersId)
    }
    //如果是从主界面直接添加任务，接收到wproList的参数selectProject
    if (this.data.selectProject) {
      this.setData({
        projectInfo: this.data.selectProject
      })
      console.log(this.data.projectInfo);
      //全部任务节点
      wclass.getProjectsTasksName([this.data.selectProject._id], _this);
    };
  },

  goBack: function () {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 更新项目表中的tasksnode字段 _this.data.projectInfo.tasksnode
   * 
   */
  updateProjectFields: function (tasksnode, proId, taskId, membersId) {
    console.log("-------------------updateProjectFields---------------------")
    let _this = this;
    const tasksnodetask = wx.cloud.callFunction({
      name: 'projectUpdate',
      data: {
        proId: _this.data.projectInfo._id,
        data: {
          tasksnode: tasksnode
        }
      }
    })
    console.log("tasksnode: ", tasksnodetask)
    this.data.tasksPromise.push(tasksnodetask);
    const allTasksNode = wx.cloud.callFunction({
      name: 'projectUpdate',
      data: {
        addAllTask: true,
        proId: proId,
        taskId: taskId
      }
    });
    console.log("allTasksNode: ", allTasksNode)
    this.data.tasksPromise.push(allTasksNode);
    const members = membersId.map(item => {
      return wx.cloud.callFunction({
        name: 'projectUpdate',
        data: {
          addMembers: true,
          proId: proId,
          userId: item
        }
      });
    })
    console.log("members: ", members)
    this.data.tasksPromise = this.data.tasksPromise.concat(members);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  /**
   * 更新用户表，tasks, projects, companys
   */
  updateUserFields(membersId, taskId, proId, companysId){
    console.log("-------------------updateUserFields------------------")
    //user: tasks
    const tasks = membersId.map(item => {
      return wx.cloud.callFunction({
        name: 'userUpdate',
        data: {
          addTasks: true,
          userId: item,
          taskId: taskId
        }
      })
    });
    console.log("tasks: ", tasks)
    this.data.tasksPromise.push(tasks)
    //projects
    const projects = membersId.map(item => {
      return wx.cloud.callFunction({
        name: 'userUpdate',
        data: {
          addProjects: true,
          userId: item,
          proId: proId
        }
      })
    });
    console.log("projects: ", projects)
    this.data.tasksPromise.push(projects);
    const companys =[]
    companysId.forEach(companysid => {
      membersId.map(memberid => {
        companys.push(wx.cloud.callFunction({
          name: 'userUpdate',
          data: {
            addCompany: true,
            userId: memberid,
            companyId: companysid
          }
        }));
      })
    })
    console.log("companys: ", companys)
    this.data.tasksPromise = this.data.tasksPromise.concat(companys);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  /**
   * 更新公司表，members, tasks
   */
  updateCompanysFields(companysId, membersId, taskId){
    console.log("-------------------updateCompanysFields------------------")
    const tasks = companysId.map(item => {
      return wx.cloud.callFunction({
        name: 'companyUpdate',
        data: {
          addTasks: true,
          companyId: item,
          taskId: taskId
        }
      })
    });
    console.log("tasks: ", tasks)
    this.data.tasksPromise = this.data.tasksPromise.concat(tasks);

    let members = [];
    companysId.forEach(companyid => {
      membersId.map(item => {
        members.push(wx.cloud.callFunction({
          name: 'companyUpdate',
          data: {
            addMember: true,
            companyId: companyid,
            userId: item
          }
        }))
      })
    });
    console.log("members: ", members)
    this.data.tasksPromise = this.data.tasksPromise.concat(members);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  saveTask: function() {
    let _this = this;
    //如果是直接添加任务，检查是否选中项目
    if (this.data.directly) {
      if (!_this.data.selectProject || !_this.data.label) {
        wx.showToast({
          title: '请选择所属阶段。',
          icon: 'none'
        })
        return;
      } 
    }
    wx.showLoading({
      title: '创建中...',
    })
    this.setData({
      saving: true
    })
    wx.cloud.callFunction({
      name: "addDoc",
      data: {
        addTask: true,
        data: _this.data.executor ? {
          name: _this.data.taskname,//任务名称
          creator: app.globalData.openid,//创建者
          creationTime: new Date().valueOf(),//创建时间
          executor: _this.data.executor,//首次添加任务时的执行者
          members: _this.data._MembersId,//任务成员
          start: _this.data.start ? new Date(_this.data.start).valueOf() : null,//开始时间
          end: _this.data.end ? new Date(_this.data.end).valueOf() : null,//结束时间
          label: _this.data.label,//默认分组
          addPermission: Array.from(new Set(_this.data.projectInfo.addPermission).add(app.globalData.openid)),//添加内容权限
          deletePermission: Array.from(new Set(_this.data.projectInfo.deletePermission).add(app.globalData.openid)),//删除项目及其内容权限
          modifyPermission: Array.from(new Set(_this.data.projectInfo.modifyPermission).add(app.globalData.openid)),//修改内容权限
          finished: false,//是否完成
          layer: 0,//层级
          proNode: [_this.data.projectInfo._id],//所属项目
          companys: _this.data.projectInfo.companys//所属公司
        } : {
            name: _this.data.taskname,//任务名称
            creator: app.globalData.openid,//创建者
            creationTime: new Date().valueOf(),//创建时间
            // executor: _this.data.executor,//首次添加任务时的执行者
            members: _this.data._MembersId,//任务成员
            start: _this.data.start ? new Date(_this.data.start).valueOf() : null,//开始时间
            end: _this.data.end ? new Date(_this.data.end).valueOf() : null,//结束时间
            label: _this.data.label,//默认分组
            addPermission: Array.from(new Set(_this.data.projectInfo.addPermission).add(app.globalData.openid)),//添加内容权限
            deletePermission: Array.from(new Set(_this.data.projectInfo.deletePermission).add(app.globalData.openid)),//删除项目及其内容权限
            modifyPermission: Array.from(new Set(_this.data.projectInfo.modifyPermission).add(app.globalData.openid)),//修改内容权限
            finished: false,//是否完成
            layer: 0,//层级
            proNode: [_this.data.projectInfo._id],//所属项目
            companys: _this.data.projectInfo.companys//所属公司
          }    
      },
      success: res => {
        console.log("创建成功：", res)
        //记录所创建任务的id     
        const taskId = res.result._id
        this.setData({
          taskId: taskId,
          tasksPromise: []//记录所有需要更新的操作
        })
        //更新总项目中的任务节点,projects: tasksnode
        //存在任务节点
        if (_this.data.projectInfo.tasksnode) {
          let tasksnode = _this.data.projectInfo.tasksnode;
          if (_this.data.label === '待处理') {
            _this.data.projectInfo.tasksnode[0].push(taskId)
          } else if (_this.data.label === '进行中') {
            _this.data.projectInfo.tasksnode[1].push(taskId)
          } else if (_this.data.label === '已完成') {
            _this.data.projectInfo.tasksnode[2].push(taskId)
          }
        }
        //更新总项目中的任务节点,projects: tasksnode，alltasksnode，members
        _this.updateProjectFields(_this.data.projectInfo.tasksnode, _this.data.projectInfo._id, taskId, _this.data._MembersId);
        //更新所有相关成员的用户表，user: tasks, projects, companys
        _this.updateUserFields(_this.data._MembersId, taskId, _this.data.projectInfo._id, _this.data.projectInfo.companys);
        //更新公司表，companys: members, tasks
        _this.updateCompanysFields(_this.data.projectInfo.companys, _this.data._MembersId, taskId);
        console.log(_this.data.tasksPromise.length);
        Promise.all(_this.data.tasksPromise).then(res => {
          console.log("miao创建了任务");
          wx.hideLoading();
          this.setData({
            saving: false
          })
          //弹窗提示添加子任务
          _this.setData({
            display: true
          })
        })
      },
      fail: res => {
        console.log(res)
      }
    })
  },
  addexecutor: function () {
    let _this = this;
    wx.navigateTo({
      url: '../waddExecutor/waddExecutor?executorId=' + _this.data.executor,
    })
  },

  addFollower: function () {
    let _this = this;
    let membersIdJsonStr = JSON.stringify({ 'membersId': this.data._MembersId})
    // console.log("membersIdJsonStr: ", membersIdJsonStr)
    wx.navigateTo({
      url: '../waddFollower/waddFollower?membersIdJsonStr=' + membersIdJsonStr,
    })
  },

  selectedProject: function () {
    wx.navigateTo({
      url: '../wproList/wproList?selectTap=0'
    })
  },

  selectedStage: function() {
    let _this = this;
    let stageList = ["待处理", "进行中", "已完成"]
    wx.showActionSheet({
      itemList: stageList,
      success: res => {
        const index = res.tapIndex
        _this.setData({
          label: stageList[index]
        })
      },
      fail: res => {
        console.log(res)
      }
    })
  },
  createSubtask: function() {
    let _this = this
    wx.redirectTo({
      url: `../waddSubTask/waddSubTask?taskId=${_this.data.taskId}&layer=0`,
    })
    this.setData({
      display: false
    })
  },
  closeMask: function() {
    let _this = this;
    wx.redirectTo({
      url: '../wtaskDetail/wtaskDetail?taskId=' + _this.data.taskId,
    })
  }
})