// pages/wdownload/wdownload.js
const app = getApp()
Page({

  /**
   * Page initial data
   */
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    downloadUrl: ''
  },

  copyLink: function (e) {
    var that = this;
    wx.setClipboardData({
      //去找上面的数据
      data: that.data.downloadUrl,
      success: function (res) {
        wx.showToast({
          title: '复制成功',
        });
      }
    });
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {
    this.setData({
      downloadUrl: options.url
    })
  },
  goBack: function() {
    wx.navigateBack({
      delta: 1,
    })
  },
  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})