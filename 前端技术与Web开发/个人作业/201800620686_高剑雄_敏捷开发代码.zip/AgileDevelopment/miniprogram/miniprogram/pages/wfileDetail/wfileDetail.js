// pages/wfileDetail/wfileDetail.js
const app = getApp()
const util = require('../../util/wutils.js')
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
const fileDB = db.collection('files')
Page({
 
  /**
   * Page initial data
   */
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    members: ''
  },
  goBack: function() {
    wx.navigateBack({
      delta:1
    })
  },

  downloadFile: function() {
    wx.navigateTo({
      url: '../wdownload/wdownload?url=' + this.data.fileInfo.dowloadUrl,
    })
  },
  previewFile: function() {
    //存储位置
    let downloadUrl = this.data.fileInfo.fileID;
    this.setData({
      downloadUrl: downloadUrl
    })
    wx.cloud.downloadFile({
      fileID: this.data.fileInfo.fileID,
      success: res => {
        // console.log(res)
        const filePath = res.tempFilePath
        wx.openDocument({
          filePath: filePath,
          success: res => {
            // console.log("打开文件成功", res)
          },
          fail: res => {
            console.log(res)
          }
        })
      }
    })
  },
  /**
   * 获取成员的信息
   */
  getMembersInfo: function (membersId) {
    let _this = this;
    let membersInfo = [];
    for (let i = 0; i < membersId.length; i++) {
      userDB.doc(membersId[i]).get().then(res => {
        // console.log(`第${i}个成员：`, res.data)
        membersInfo.push(res.data);
        _this.setData({
          membersInfo: membersInfo,
        })
      })
    }
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {
    // console.log(options)
    let _this = this
    const fileId = options.fileId;
    fileDB.doc(fileId).get({
      success: res => {
        console.log(res.data)
        _this.setData({
          fileInfo: res.data
        })
        //查询成员信息
        const proNode = res.data.proNode;
        const membersTask = [];
        proNode.forEach(proId => {
          membersTask.push(projectDB.doc(proId).get());
        });
        Promise.all(membersTask).then(res => {
          let projectsInfo = res.map(item => {return item.data});
          console.log("projectsInfo: ", projectsInfo);
          let projectName ='#' + projectsInfo.map(item => {return item.name}).join('#');
          _this.setData({ projectName: projectName})
          let allmembersId = [];
          projectsInfo.map(item => { allmembersId = allmembersId.concat(item.members) });
          console.log("allmembersId: ", allmembersId);
          if (allmembersId.length > 0) {
            _this.getMembersInfo(allmembersId)
          }
        })
      },
      fail: res => {
        console.log(res)
      }
    })
  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },
  addFollower: function () {
    let proId = this.data.fileInfo.proNode
    wx.navigateTo({
      url: '../waddFollower/waddFollower?proId=' + proId,
    })
  }
})