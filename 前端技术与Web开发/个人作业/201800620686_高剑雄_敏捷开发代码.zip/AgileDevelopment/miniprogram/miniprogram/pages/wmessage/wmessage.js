// pages/wreceive/wreceive.js
const app = getApp();
const images = require('../../util/images.js')
//获取数据库引用 
const db = wx.cloud.database();
const userDB = db.collection('user');
const chatGroupDB = db.collection('chatGroups');

Page({
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    screenHeight: app.globalData.screenHeight,
    screenWidth: app.globalData.screenWidth,
    navigatorH: app.globalData.navigatorH,//
    statusBarHeight: app.globalData.statusBarHeight,//状态栏的高度，单位px
    isLogin: app.globalData.login,
    images: images,
    content: '',
  },

  onLoad: function (options) {
    let _this = this;
    userDB.doc(app.globalData.openid).get().then(res => {
      let friends = res.data.friends;
      let queryFriends = friends.map(item => {return userDB.doc(item).get()});
      Promise.all(queryFriends).then(res => {
        let allFriendsInfo = res.map(item => {return item.data});
        _this.setData({ allFriendsInfo: allFriendsInfo})
      })
    })
  },
  onShow: function() {
    let _this = this;
    this.setData({ displaySearch: false});
    userDB.doc(app.globalData.openid).get().then(res => {
      let chatGroups = res.data.chatGroups || [];
      let queryChatGroups = chatGroups.map(item => {return chatGroupDB.doc(item).get()});
      Promise.all(queryChatGroups).then(res => {
        let chatGroupsInfo = res.map(item => {return item.data});
        let length =  1;
        chatGroupsInfo.map(groupInfo => {
          if (groupInfo.message) {
            console.log("groupInfo.message.slice(-1): ", groupInfo.message.slice(-1)[0])
            groupInfo.lastMessage = groupInfo.message.slice(-1)[0].content
            groupInfo.lastSendTime = groupInfo.message.slice(-1)[0].sendTime
          }
          if (groupInfo.members.length === 2) {
            groupInfo.members.filter(item => { return item != app.globalData.openid }).map(item => {
              userDB.doc(item).get().then(res => {
                groupInfo.fName = res.data.name;
                groupInfo.avatarUrl = res.data.userHeader;
                console.log("groupInfo: ", groupInfo)
                _this.setData({ chatGroupsInfo: chatGroupsInfo, });
              });
            })
          } else {
            let fName = '';
            groupInfo.members.filter(item => { return item != app.globalData.openid }).map(item => {
              userDB.doc(item).get().then(res => {
                fName = fName + '、' + res.data.name;
                groupInfo.fName = fName.slice(1,)
                console.log(groupInfo.fName, res.data.name);
                groupInfo.avatarUrl = "cloud://mapp-5f3o8.6d61-mapp-5f3o8-1259747852/class.png";
                console.log("groupInfo: ", groupInfo)
                _this.setData({ chatGroupsInfo: chatGroupsInfo, });
              })
            })
          }
        })
      })
    })
  },
  goBack: function() {
    wx.navigateBack({
      delta: 1
    })
  },
  openSearch: function () {
    this.setData({displaySearch: true});
    this.setData({ searchUsersInfo: this.data.allFriendsInfo })
    wx.hideTabBar({});
  },
  closeSearch: function () {
    this.setData({
      displaySearch: false
    })
    wx.showTabBar({})
  },
  inputSearch: function (e) {
    let value = e.detail.value;
    this.setData({searchContent: value});
    var regStr = `.*${value}`
    var reg = RegExp(`${regStr}`);
    //查询的名字
    let allFriendsInfo = this.data.allFriendsInfo;
    let res = allFriendsInfo.filter(item => {
      let friendName = item.name;
      if (reg.test(friendName)) {return item}
    });
    console.log(res);
    if (value.length > 0) {this.setData({searchUsersInfo: res})} 
    else {this.setData({searchUsersInfo: allFriendsInfo})}
  },
  goChat(e) {
    let _this = this;
    const chatgroupId = e.currentTarget.dataset.chatgroupid;
    wx.navigateTo({ url: '../wchatDetail/wchatDetail?chatgroupId=' + chatgroupId });
  },
  createChat(e) {
    let _this = this;
    const userId = e.currentTarget.dataset.id;
    const data = {members: [app.globalData.openid, userId], creationTime: new Date().valueOf()};
    //判断是否有聊天
    chatGroupDB.where({ members: [app.globalData.openid, userId]}).get().then(res => {
      if (res.data.length === 1) {
        console.log("存在聊天，");
        const chatgroupId = res.data[0]._id;
        wx.navigateTo({ url: '../wchatDetail/wchatDetail?chatgroupId=' + chatgroupId });
      } else if (res.data.length === 0){
        //建立一个聊天
        wx.cloud.callFunction({ name: 'addDoc', data: { addChatGroup: true, data: data } })
          .then(res => {
            const chatgroupId = res.result._id;//创建聊天的id
            const tasksPromise = data.members.map(item => { return wx.cloud.callFunction({ 
              name: 'userUpdate', data: { addChatGroups: true, userId: item, chatgroupId: chatgroupId} 
            })})
            Promise.all(tasksPromise).then(res => {
              console.log("创建成功");
              wx.navigateTo({ url: '../wchatDetail/wchatDetail?chatgroupId=' + chatgroupId });
            })
          })
      }
    })
  },

  leaveEdit: function () {
    console.log("退出编辑状态");
    this.data.chatGroupsInfo.map(item => { return item.isRotate = false });
    this.setData({ chatGroupsInfo: this.data.chatGroupsInfo })
    this.setData({ editing: false })
  },
  enterEdit: function () {
    console.log("进入编辑状态");
    this.setData({ editing: true })
  },
  rotateBtn: function (e) {
    console.log("旋转按钮");
    const dataset = e.currentTarget.dataset;
    console.log(dataset)
    let chatGroupsInfo = this.data.chatGroupsInfo || [];
    if (dataset.chatgroupid) {
      const chatgroupId = dataset.chatgroupid
      const index = chatGroupsInfo.indexOf(chatGroupsInfo.filter(item => { return item._id === chatgroupId })[0]);
      console.log(index);
      chatGroupsInfo[index].isRotate = !chatGroupsInfo[index].isRotate;
      chatGroupsInfo.filter(item => { return item._id != chatgroupId }).map(item => { return item.isRotate = false })
      this.setData({ chatGroupsInfo: chatGroupsInfo, })
    }
  },
  delchat(e){
    const chatgroupid = e.currentTarget.dataset.chatgroupid;
    wx.cloud.callFunction({
      name: 'userUpdate', data: { removeChatGroups: true, userId: app.globalData.openid, chatgroupId: chatgroupid}
    }).then(res => {
      console.log("移除成功", res);
      this.data.chatGroupsInfo = this.data.chatGroupsInfo.filter(item => { return item._id != chatgroupid});
      this.setData({ chatGroupsInfo: this.data.chatGroupsInfo })
    })
  },
  createChatGroup(){
    console.log("-----------------------createChatGroup---------------------------");
    wx.navigateTo({ url: '../waddMem/waddMem?createChatGroup=0',})
  }
})