// pages/wlinkman/wlinkman.js
const app = getApp();
const images = require("../../util/images.js")
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const taskDB = db.collection('tasks')
const companyDB = db.collection("companys")
const projectDB = db.collection('projects')
Page({
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    navigatorH: app.globalData.navigatorH,//
    screenWidth: app.globalData.screenWidth,
    statusBarHeight: app.globalData.statusBarHeight,//状态栏的高度，单位px
    isLogin: app.globalData.login,
    images: images
  },
  onLoad: function (options) {
    let _this = this;
    this.setData({isLogin: app.globalData.login});
    if (options.companyId) {this.setData({ companyId: options.companyId, viewMember: true});}
    if (options.projectId) { this.setData({ projectId: options.projectId, viewMember: true }); }
  },
  onShow(){
    let _this = this;
    if (this.data.companyId) {
      companyDB.doc(this.data.companyId).get().then(res => {
        let administrator = res.data.addPermission.concat(res.data.deletePermission).concat(res.data.modifyPermission);
        _this.setData({ friends: res.data.members || [], creator: res.data.creator, administrator: administrator }); 
        let friends = this.data.friends;
        let tasks = friends.map(item => { return userDB.doc(item).get() });
        Promise.all(tasks).then(res => {
          console.log("res.data:", res);
          let friendsInfo = res.map(item => { return item.data });
          friendsInfo.map(item => { 
            if (administrator.indexOf(item._id) != -1 && item._id != _this.data.creator) {item.isAdmin=true} 
            else {item.isAdmin = false}  
          })
          _this.setData({ friendsInfo: friendsInfo, title: '班级成员'});
        })
      })
    } else if (this.data.projectId){
      projectDB.doc(this.data.projectId).get().then(res => {
        let administrator = res.data.addPermission.concat(res.data.deletePermission).concat(res.data.modifyPermission);
        _this.setData({ friends: res.data.members || [], creator: res.data.creator, administrator: administrator }); 
        let friends = this.data.friends;
        let tasks = friends.map(item => { return userDB.doc(item).get() });
        Promise.all(tasks).then(res => {
          console.log("res.data:", res);
          let friendsInfo = res.map(item => { return item.data });
          friendsInfo.map(item => {
            if (administrator.indexOf(item._id) != -1 && item._id != _this.data.creator) { item.isAdmin = true }
            else { item.isAdmin = false }
          })
          _this.setData({ friendsInfo: friendsInfo, title: '项目成员' });
        })
      })
    } else {
      userDB.doc(app.globalData.openid).get().then(res => {
        _this.setData({ friends: res.data.friends || [] });
        if (res.data.friends && res.data.friends.length > 0) {
          let friends = res.data.friends;
          let tasks = friends.map(item => { return userDB.doc(item).get() });
          Promise.all(tasks).then(res => {
            console.log("res.data:", res);
            let friendsInfo = res.map(item => { return item.data });
            _this.setData({ friendsInfo: friendsInfo });
          })
        }
      })
    }
  },
  goBack: function() {
    wx.navigateBack({
      delta: 1
    })
  },
  toProfile: function(e) {
    const userId = e.currentTarget.dataset.id;
    if (this.data.companyId) {
      wx.navigateTo({ url: '../wprofile/wprofile?userId=' + userId + '&companyId=' + this.data.companyId,});
      return;
    }
    if (this.data.projectId) {
      wx.navigateTo({ url: '../wprofile/wprofile?userId=' + userId + '&projectId=' + this.data.projectId, });
      return;
    }
    wx.navigateTo({url: '../wprofile/wprofile?userId=' + userId,});
  },
  addFriend: function() {
    let membersId = this.data.friends.concat([app.globalData.openid]) || [app.globalData.openid];
    let membersIdJsonStr = JSON.stringify({ 'membersId': membersId })
    wx.navigateTo({
      url: '../waddMem/waddMem?membersIdJsonStr=' + membersIdJsonStr + '&addFriends=0',
    })
  },
  leaveEdit: function () {
    console.log("退出编辑状态");
    this.data.friendsInfo.map(item => { return item.isRotate = false });
    this.setData({ friendsInfo: this.data.friendsInfo })
    this.setData({ editing: false })
  },
  enterEdit: function () {
    console.log("进入编辑状态");
    this.setData({editing: true})
  },
  rotateBtn: function (e) {
    console.log("旋转按钮");
    const dataset = e.currentTarget.dataset;
    console.log(dataset)
    let friendsInfo = this.data.friendsInfo || [];
    if (dataset.userid) {
      const userId = dataset.userid
      const index = friendsInfo.indexOf(friendsInfo.filter(item => { return item._id === userId })[0]);
      console.log(index);
      friendsInfo[index].isRotate = !friendsInfo[index].isRotate;
      friendsInfo.filter(item => { return item._id != userId }).map(item => { return item.isRotate = false })
      this.setData({friendsInfo: friendsInfo,})
    }
  },
  delfriend(e){
    let _this = this;
    const userId = e.currentTarget.dataset.userid;
    console.log("userId: ", userId)
    const friends = wx.cloud.callFunction({
      name: 'userUpdate', data: { removeFriends: true, userId: app.globalData.openid, friendId: userId}
    });
    const self = wx.cloud.callFunction({
      name: 'userUpdate', data: { removeFriends: true, userId: userId, friendId: app.globalData.openid }
    });
    Promise.all([friends, self]).then(res => {
      console.log("移除成功...");
      _this.data.friendsInfo = _this.data.friendsInfo.filter(item => {return item._id != userId});
      console.log("_this.data.friendsInfo: ", _this.data.friendsInfo)
      _this.setData({ friendsInfo: _this.data.friendsInfo})
    })
  }
})