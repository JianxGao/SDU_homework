// pages/wregister/wregister.js
let app = getApp();
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
let name = null;
let phone = null;
let password = null;
let mail = null;
let arr = [
  { value: name, right: false },
  { value: phone, right: false },
  { value: password, right: false },
  { value: mail, right: false }
]
Page({
  
  /**
   * Page initial data
   */
  data: {
    status: false,
    capsuleInfo: app.globalData.capsuleInfo,
    clickable: false,
    arr: arr,
    screenHeight: app.globalData.screenHeight,//屏幕高度，单位px
    navigatorH: app.globalData.navigatorH,//
    statusBarHeight: app.globalData.statusBarHeight,//状态栏的高度，单位px
  },
  inputName: function(event) {
    name = event.detail.value;
    if (name.length > 0) {
      arr[0].right = true
    }
    this.check()
  },
  //手机号
  inputPhone: function(event) {
    this.setData({
      inputPhone: true
    })
    phone = event.detail.value
    var reg = /^(((1[34578][0-9]{1})|(15[0-9]{1}))+\d{8})$/;
    var reg1 = /^\d{11,11}$/;
    if (reg1.test(phone)) {
      arr[1].right = true
    } else {
      arr[1].right = false
    }
    this.check()
  },
  //密码
  inputPassword: function (event) {
    this.setData({
      inputPassword: true
    })
    password = event.detail.value;
    var reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$/;
    if (reg.test(password)) {
      console.log("密码由数字和字母组成");
      arr[2].right = true
    } else {
      console.log("密码不是由数字和字母组成");
      arr[2].right = false
    }
    this.check()
  },
  //mail
  inputmail: function (event) {
    this.setData({
      inputmail: true
    })
    var reg = /^([a-zA-Z0-9]+[_|_|.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|_|.]?)*[a-zA-Z0-9]+\.(?:com|cn)$/;
    // var reg1 = /^\w + ([-+.]\w +)  *@\w + ([-.]\w +)*\.\w + ([-.]\w +)* $/;
    mail = event.detail.value
    if (reg.test(mail)) {
      arr[3].right = true
    } else {
      arr[3].right = false
    }
    this.check()
  },
  check: function() {
    let _this = this;
    _this.setData({
      arr: arr
    })
    if (arr.filter(item => { return item.right === false }).length === 0) {
      _this.setData({
        clickable: true
      })
    } else {
      _this.setData({
        clickable: false
      })
    }
  },
  wechatLog: function(e) {
    console.log(e)
    let _this = this;
    let _id = app.globalData.openid;
    let userData = JSON.parse(e.detail.rawData);
    this.setData({
      userHeader: userData.avatarUrl
    });
    wx.cloud.callFunction({
      name: "addDoc",
      data: {
        addUser: true,
        userId: _id,
        data: {
          name: name,
          password: password,
          phone: phone,
          mail: mail,
          projects: [],
          tasksExecutor: [],
          tasksFollower: [],
          userHeader: _this.data.userHeader
        }
      },
      success: res => {
        // console.log(res)
        this.setData({
          status: true
        })
      },
      fail: res => {
        console.log(res)
      }
    })
  },

  bindRegiste: function() {
    let _this = this;
    userDB.where({
      _openid: app.globalData.openid
    }).get({
      success: res => {
        let userinfo = res.data;
        if (userinfo && userinfo.length > 0) {
          let user = userinfo[0];
          if ( user && user.name) {
            wx.showModal({
              title: '提示',
              content: '您已注册，请返回登录',
              success: res => {
                if (res.confirm) {
                  wx.redirectTo({
                    url: '../wlog/wlog',
                  })
                }
              }
            })
          }
        } else {
          _this.wechatLog()
        }
      }
    })
  },

  saveuserinfo() {
    let _this = this;
    let _id = app.globalData.openid;
    console.log(_this.data.userHeader)
    
  },
  backLogin: function() {
    wx.redirectTo({
      url: '../wlog/wlog',
    })
  },
  goBack() {
    wx.navigateBack({
      delay: 1
    })
  }
})