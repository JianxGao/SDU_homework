// pages/wtaskDetail/wtaskDetail.js
const app = getApp()
var dateTimePicker = require('../../util/dateTimePicker.js');
const util = require('../../util/wutils.js');
const wclass = require('../../util/wclass.js')
const images = require('../../util/images.js')
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
const fileDB = db.collection('files');
const folderDB = db.collection('folders');
const companyDB = db.collection('companys');

Page({
  data: {
    screenHeight: app.globalData.screenHeight,
    capsuleInfo: app.globalData.capsuleInfo,
    labels: ['待处理', '进行中', '已完成'],
    loading: true,
    //picker
    //设置时间相关
    dateTimeArray: null,
    // dateTime: null,
    endDateTime: null,
    startDateTime: null,
    startYear: 2019,
    endYear: 2050,
    images: images
  },
  onLoad: function (options) {
    console.log("options: ", options)
    let _this = this;
    this.setData({taskId: options.taskId});
    if (options.proId) { this.setData({ proId: options.proId})}
    if (options.layer) {
      this.setData({ layer: options.layer });
    }
    //查询用户的收藏任务列表
    userDB.doc(app.globalData.openid).get().then(res => {
      let favoritesTaskNode = res.data.tags;
      //查看该任务是否被收藏;
      console.log(" 查看该任务是否被收藏", favoritesTaskNode ? favoritesTaskNode.indexOf(_this.data.taskId) : '')
      if (favoritesTaskNode && favoritesTaskNode.indexOf(options.taskId) != -1) {
        _this.setData({
          isFavorites: true
        });
      }
    })
  },
  /**
   * 输入框聚焦时
   */
  focusInput: function(e) {
    this.setData({
      isFocus: true
    })
  },
  tasksNameInput: function(e) {
    // console.log(e.detail.value);
    const alltasksNameList = this.data.alltasksNameList;
    var value = e.detail.value;
    var oldName = this.data.taskInfo.name
    if (value != oldName) {
      if (alltasksNameList.indexOf(value) === -1 && value.length > 0) {
        this.setData({
          newtaskName: value,
          isChanged: true,
        })
      } else if (value.length === 0) {
        wx.showToast({
          title: '任务标题不能为空。',
          icon: 'none'
        });
        this.setData({
          isChanged: false
        })
      } else {
        wx.showToast({
          title: '该任务已存在，请更换任务名称。',
          icon: 'none'
        });
        this.setData({
          isChanged: false
        })
      }
    } else {
      this.setData({
        isChanged: false
      })
    }
  },
  /**
   * 更新数据库中任务的名字
   */
  saveTaskName: function(e) {
    let _this = this;
    wx.cloud.callFunction({
      name: 'taskUpdate',
      data: {
        updateName: true,
        taskId: _this.data.taskInfo._id,
        name: _this.data.newtaskName
      }
    }).then(res => {
      console.log("修改了任务内容！")
      //显示导航
      _this.setData({
        isFocus: false
      })
    }).catch(res => {
      console.log(res)
    })
  },
  /**
   * 取消保存，显示导航
   */
  cancelSave: function() {
    // console.log("点击取消")
    this.setData({
      isFocus: false,
      "taskInfo.name": this.data.taskInfo.name
    })
  },
  getTaskNodeName: function(taskNode){
    let _this = this
    taskDB.doc(taskNode).get().then(res => {
      // console.log(res.data)
      _this.setData({
        parentTaskInfo: res.data
      })      
    }) 
  },
 
  onShow: function () {
    let _this = this;
    this.setData({
      loading: true
    })
    //重新查询 update
    taskDB.doc(this.data.taskId).get({
      success: function (res) {
        console.log("信息：", res.data)
        const taskInfo = res.data;
        let resultObj = util.getInitStartEndDetail(taskInfo, _this.data.startYear, _this.data.endYear);
        console.log("resultObj: ", resultObj)
        _this.setData({
          startDateTime: resultObj.startDateTime,
          endDateTime: resultObj.endDateTime,
          startdateTimeArray: resultObj.startdateTimeArray,
          enddateTimeArray: resultObj.enddateTimeArray
        })
        // // 获取当前时间 
        _this.setData({
          startTime: _this.getTime(_this.data.startdateTimeArray, _this.data.startDateTime),
          start: new Date(_this.getTime(_this.data.startdateTimeArray, _this.data.startDateTime)).valueOf(),
          endTime: resultObj.end ? _this.getTime(_this.data.enddateTimeArray, _this.data.endDateTime) : null,
          end: resultObj.end ? new Date(_this.getTime(_this.data.enddateTimeArray, _this.data.endDateTime)).valueOf():null,
        });
        if (taskInfo.taskNode) {
          _this.setData({
            hasParentTask: true
          })
          _this.getTaskNodeName(taskInfo.taskNode);
        }
        console.log("taskInfo.subtasksNode:", taskInfo.subtasksNode)
        if (taskInfo.subtasksNode) {
          let querytasks = taskInfo.subtasksNode.map(item => { return taskDB.doc(item).get() });
          Promise.all(querytasks).then(res => {
            console.log("子任务信息：", res)
            let subtasksInfo = util.sortArray(res);
            _this.setData({
              subtasksInfo: subtasksInfo
            })
          })
        }
        //获取执行者的信息
        _this.getExecutorInfo(taskInfo.executor);
        //获取成员信息
        console.log("获取成员信息", taskInfo.members)
        if (taskInfo.members) {
          util.getMembersInfo(_this, taskInfo.members);
        }
        if (taskInfo.start) {
          taskInfo.start = util.formatDate(taskInfo.start)
        }
        if (taskInfo.end) {
          taskInfo.end = util.formatDate(taskInfo.end)
        }
        _this.setData({
          taskInfo: taskInfo,
          proNode: taskInfo.proNode,
          loading: false
        })
        //获取所属项目中的所有任务的名称
        wclass.getProjectsTasksName(_this.data.proNode, _this);
        console.log(_this.data.loading);
      },
    })
  },

  changeStartDateTime(e) {
    console.log("changeStartDateTime: ", e.detail.value);
    let _this = this;
    let startTime = _this.getTime(_this.data.startdateTimeArray, _this.data.startDateTime);
    let startTimestamp = new Date(startTime).valueOf();
    if (startTimestamp > this.data.end) {
      this.setData({
        endTime: "请设置结束时间",
        end: null,
        startTime: startTime,
        start: startTimestamp
      });
      //修改结束时间
      wx.cloud.callFunction({
        name: "taskUpdate",
        data: {
          updateEnd: true,
          taskId: _this.data.taskId,
          end: _this.data.end
        }
      }).then(res => {
        console.log("结束时间更改成功：", _this.data.endDateTime, _this.data.start, res)
      }).catch(res => {
        console.log(_this.data.endDateTime, _this.data.start, res)
      })
    } else {
      this.setData({
        startTime: startTime,
        start: startTimestamp
      }); 
    }
    //修改开始时间
    wx.cloud.callFunction({
      name: "taskUpdate",
      data: {
        updateStart: true,
        taskId: _this.data.taskId,
        start: _this.data.start
      }
    }).then(res => {
      console.log("开始时间更改成功：", _this.data.startTime, _this.data.start, res)
    }).catch(res => {
      console.log(_this.data.startTime, _this.data.start, res)
    })
   
  },
  changeEndDateTime(e) {
    let _this = this
    console.log("changeEndDateTime: ", e.detail.value, _this.data.endDateTime)
    let endTime = _this.getTime(_this.data.enddateTimeArray, e.detail.value);
    console.log(endTime)
    let endTimestamp = new Date(endTime).valueOf();
    if (endTimestamp < this.data.start) {
      wx.showToast({
        title: ' 设置时间无效！',
        icon: "none",
      })
      if (_this.data.oldEndDateTime) {
        console.log(_this.data.endDateTime, _this.data.oldEndDateTime)
        _this.setData({
          endDateTime: _this.data.oldEndDateTime.split(",").map(item => { return Number(item) })
        })
        console.log(_this.data.oldEndDateTime.split(",").map(item => { return Number(item) }), _this.data.endDateTime)
      }
    } else {
      wx.cloud.callFunction({
        name: "taskUpdate",
        data: {
          updateEnd: true,
          taskId: _this.data.taskId,
          end: endTimestamp
        }
      }).then(res => {
        console.log("结束时间更改成功：", _this.data.endDateTime, _this.data.start, res);
        _this.setData({
          endTime: endTime,
          end: endTimestamp
        });
      }).catch(res => {
        console.log(_this.data.endDateTime, _this.data.start, res)
      })
    }
  },
  /**
    * 
    */
  changeStartDateTimeColumn(e) {
    let _this = this;
    // console.log("changeStartDateTimeColumn: ", e)
    var arr = this.data.startDateTime, dateArr = this.data.startdateTimeArray;

    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    this.setData({
      // startDateTime: arr,
      startdateTimeArray: dateArr
    })
    
  },
  changeEndDateTimeColumn(e) {
    let _this = this;
    // console.log("changeDateTimeColumn: ", e)
    var arr = this.data.endDateTime, dateArr = this.data.enddateTimeArray;
    arr[e.detail.column] = e.detail.value;
    this.setData({
      oldEndDateTime: arr.toString()
    })
    console.log("ols: ", this.data.oldEndDateTime)
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);
    this.setData({
      // endDateTime: arr,
      enddateTimeArray: dateArr
    })
  },
  getExecutorInfo: function(executorId) {
    // console.log(executorId)
    let _this = this;
    if (executorId) {
      userDB.doc(executorId).get().then(res => {
        // console.log("detail 执行者：", res.data)
        _this.setData({
          executorInfo: res.data
        })
      }).catch(res => {
        // console.log(res)
      })
    } else {
      _this.setData({
        executorInfo: null
      })
    }
  },

  goBack: function() {
    if (Number(this.data.layer) >= 1) {
      wx.redirectTo({
        url: '../wtaskDetail/wtaskDetail?taskId=' + this.data.parentTaskInfo._id + '&layer=' + (this.data.taskInfo.layer - 1),
      });
      return;
    } else if (Number(this.data.layer) === 0) {
      wx.navigateBack({ delta: 1 });
      return;
    }
    console.log("直接返回。")
    wx.navigateBack({ delta: 1})
  },

  selectLabel: function() {
    // console.log("选择一个任务列表")
    let _this = this
    const index = this.data.labels.indexOf(this.data.taskInfo.label);
    wx.navigateTo({
      url: '../wtaskList/wtaskList?checkedIndex=' + index + '&taskId=' + _this.data.taskId + '&proId=' + _this.data.proId,
    })
  },
 
  addexecutor: function() {
    let _this = this;
    this.setData({
      oldExecutor: _this.data.taskId.executor
    })
    wx.navigateTo({
      url: '../waddExecutor/waddExecutor?taskId=' + _this.data.taskId,
    })
  },

  addFollower: function() {
    console.log("点击addFollower");
    let _this = this;
    wx.navigateTo({
      url: '../waddFollower/waddFollower?taskId=' + _this.data.taskId,
      success: res => {
        console.log(res)
      },
      fail: res => {
        console.log(res)
      }
    })
  },
  goParentTask: function() {
    // console.log("parent node: ", this.data.parentTaskInfo._id)
    wx.navigateTo({
      url: `../wtaskDetail/wtaskDetail?taskId=${this.data.parentTaskInfo._id}`,
    })
  },
  updateTaksStatu: function() {
    let taskInfo = this.data.taskInfo
    //更新tasksInfo 
    util.updateTaksStatu(this.data.taskId, [taskInfo]).then(res => {
      console.log(res)
    })
    this.setData({
      taskInfo: taskInfo
    })
  },

  updatesubTaksStatu: function(e) {
    let _this = this
    let subTasksInfo = _this.data.subtasksInfo
    const subtaskId = e.currentTarget.dataset.subtaskid;
    console.log("subtask id: ", subtaskId, subTasksInfo, this.data.subtasksInfo);
    let status;
    let task = _this.data.subtasksInfo.filter(item => { return item._id === subtaskId });
    console.log("task: ", task);
    status = !task[0].finished;
    console.log("status: ", status)
    _this.data.subtasksInfo.filter(item => { return item._id === subtaskId }).map(item => {
      return item.finished = !item.finished;
    })
    console.log("_this.data.subtasksInfo: ", _this.data.subtasksInfo);
    _this.setData({
      subtasksInfo: _this.data.subtasksInfo
    })
    wx.cloud.callFunction({
      name: 'taskUpdate',
      data: {
        updateFinished: true,
        taskId: subtaskId,
        finished: status
      }
    })
  },

  createSubTask: function () {
    let _this = this
    // console.log("创建子任务")
    wx.navigateTo({
      url: `../waddSubTask/waddSubTask?proId=${_this.data.proId}&taskId=${_this.data.taskId}`,
    })
  },

  getTime: function (dateArr, arr) {
    var _year = dateArr[0][arr[0]];
    var _month = dateArr[1][arr[1]];
    var _day = dateArr[2][arr[2]];
    var _hour = dateArr[3][arr[3]];
    var _minute = dateArr[4][arr[4]];
    console.log(`${_year}-${_month}-${_day} ${_hour}:${_minute}`)
    return `${_year}-${_month}-${_day} ${_hour}:${_minute}`
  },
  add2Favorites: function() {
    console.log("添加到收藏夹");
    let _this = this;
    this.setData({
      isFavorites: !this.data.isFavorites,
    });
    if (this.data.isFavorites) {
      //将该任务的id添加至成员表的tag字段中;
      wx.cloud.callFunction({
        name: 'userUpdate',
        data: {
          addTag: true,
          userId: app.globalData.openid,
          taskId: _this.data.taskInfo._id
        }
      }).then(res => {
        console.log(res);
        wx.showToast({
          title: '添加收藏成功',
          icon: 'none'
        })
      })
    } else {
      //将该任务的id添加至成员表的tag字段中;
      wx.cloud.callFunction({
        name: 'userUpdate',
        data: {
          removeTag: true,
          userId: app.globalData.openid,
          taskId: _this.data.taskInfo._id
        }
      }).then(res => {
        console.log(res);
        wx.showToast({
          title: '取消收藏',
          icon: 'none'
        })
      })
    }
  },
  subTaskDetail: function(e) {
    const subtaskid = e.currentTarget.dataset.subtaskid;
    wx.navigateTo({
      url: '../wtaskDetail/wtaskDetail?taskId=' + subtaskid,
    })
  },
  addLink: function() {
    let _this = this;
    wx.navigateTo({
      url: '../waddLink/waddLink?taskId=' + _this.data.taskInfo._id,
    })
  },
  delTask() {
    let administrator = this.data.taskInfo.addPermission.concat(this.data.taskInfo.deletePermission).concat(this.data.taskInfo.modifyPermission);
    if (administrator.indexOf(app.globalData.openid) === -1) {
      wx.showToast({ title: '对不起，您没有删除权限。', icon: 'none' });
      return;
    }
    console.log("删除。。。。。。。。");
    wx.showLoading({
      title: '删除中...',
    })
    let _this = this
    let taskId = this.data.taskId;
    let layer = this.data.taskInfo.layer;//层级
    console.log("layer: ", layer)
    let projectsId = this.data.taskInfo.proNode;//所属项目
    console.log("projectsId: ", projectsId)
    let companysId = this.data.taskInfo.companys;//所属班级
    console.log("companysId: ", companysId)
    let foldersId = this.data.taskInfo.folders ? this.data.taskInfo.folders : [];//所关联的文件夹
    console.log("foldersId: ", foldersId)
    let privateFilesId = this.data.taskInfo.privatefiles || [];//私有文件
    console.log("privateFilesId: ", privateFilesId)
    let files = this.data.taskInfo.files || []; 
    let filesId = files.filter(item => {return privateFilesId.indexOf(item) === -1});//其他关联文件
    console.log("filesId: ", filesId)
    let membersId = this.data.taskInfo.members;//任务成员
    console.log("membersId: ", membersId)
    let parentTasksId = this.data.taskInfo.alltaskNode || [];//父任务
    console.log("parentTasksId: ", parentTasksId)
    let allsubtasksId = this.data.taskInfo.allsubtasks || [];//所有的子任务
    console.log("allsubtasksId: ", allsubtasksId)
    //查询子任务的关联文件
    let querysubtasks = allsubtasksId.map(item => { return taskDB.doc(item).get() });
    let subtasksPrivateFiles = [];
    let subtasksfolders = [];
    let subtasksFiles = []
    Promise.all(querysubtasks).then(res => {
      let privateFilesResult = res.map(item => { return item.data.privatefiles || [] });
      privateFilesResult.forEach(item => { subtasksPrivateFiles = subtasksPrivateFiles.concat(item) });
      let foldersResult = res.map(item => { return item.data.folders || [] });
      foldersResult.forEach(item => { subtasksfolders = subtasksfolders.concat(item) });
      let filesResult = res.map(item => { return item.data.files || [] });
      filesResult.forEach(item => { subtasksFiles = subtasksFiles.concat(item) });
      subtasksFiles = subtasksFiles.filter(item => { return subtasksPrivateFiles.indexOf(item) === -1 });
      privateFilesId = privateFilesId.concat(subtasksPrivateFiles || []);
      console.log("privateFilesId: ", privateFilesId)
      filesId = filesId.concat(subtasksFiles || [])
      console.log("filesId: ", filesId)
      foldersId = foldersId.concat(subtasksfolders || [])
      console.log("foldersId: ", foldersId)
      let queryFilesPathTask = privateFilesId.map(item => { return fileDB.doc(item).get() });
      Promise.all(queryFilesPathTask).then(res => {
        _this.setData({tasksPromise: []});
        let privateFilesIdPath = res.map(item => { return item.data.fileID });
        console.log("privateFilesIdPath: ", privateFilesIdPath)
        //更新task
        _this.updateTaskFields(taskId, allsubtasksId, parentTasksId);
        //更新projects：allTasksNode
        _this.updateProjectFields(taskId, allsubtasksId, projectsId);
        //更新companys：tasks
        _this.updateCompanyFields(taskId, allsubtasksId, companysId);
        //更新files：taskNode
        _this.updateFileFields(privateFilesId, privateFilesIdPath, filesId, taskId, allsubtasksId);
        _this.updateFolderFields(foldersId, taskId, allsubtasksId);
        //更新user：tasks
        _this.updateUserFields(membersId, taskId, allsubtasksId);
        Promise.all(_this.data.tasksPromise).then(res => {
          wx.hideLoading()
          wx.navigateBack()
        })
      })
    })
  },
  updateTaskFields(taskId, subtasksId, parentTasksId) {
    console.log("-------------------------------------updateTaskFields-----------------------------------")
    //删除本任务记录及其子任务记录
    console.log("[taskId].concat(subtasksId || []): ", [taskId].concat(subtasksId || []));
    let tasksId = [taskId].concat(subtasksId || [])
    console.log("tasksId: ", tasksId)
    let removeTasks = tasksId.map(item => {
      return wx.cloud.callFunction({
        name: 'taskUpdate',
        data: {
          removeTask: true,
          taskId: item
        }
      })
    });
    this.data.tasksPromise = this.data.tasksPromise.concat(removeTasks);
    console.log("removeTasks: ", removeTasks);
    //移除父任务中的该任务及其子任务的节点
    if (parentTasksId) {
      let subtasksNode = [];
      console.log("[taskId].concat(subtasksId || []): ", [taskId].concat(subtasksId || []));
      let tasksId = [taskId].concat(subtasksId || [])
      console.log("tasksId: ", tasksId)
      tasksId.forEach(item => {
        parentTasksId.map(parentTask => {
          subtasksNode.push(wx.cloud.callFunction({
            name: 'taskUpdate',
            data: {
              removeSubtask: true,
              taskId: parentTask,
              subtaskId: item
            }
          }))
        })
      });
      this.data.tasksPromise = this.data.tasksPromise.concat(subtasksNode);
      console.log("subtasksNode: ", subtasksNode);
    }
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  updateProjectFields(taskId, subtasksId, projectsId) {
    console.log("-------------------------------------updateProjectFields-----------------------------------");
    //移除所属项目中的该任务及其子任务的节点
    console.log("[taskId].concat(subtasksId || []): ", [taskId].concat(subtasksId || []));
    let allTasksNode = []
    let tasksId = [taskId].concat(subtasksId || [])
    console.log("tasksId: ", tasksId)
    tasksId.forEach(item => {
      projectsId.map(proId => {
        allTasksNode.push(wx.cloud.callFunction({
          name: 'projectUpdate',
          data: {
            removeAllTasksNode: true,
            proId: proId,
            taskId: item
          }
        }))
      })
    });
    this.data.tasksPromise = this.data.tasksPromise.concat(allTasksNode);
    console.log("allTasksNode: ", allTasksNode);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  updateCompanyFields(taskId, subtasksId, companysId) {
    console.log("-------------------------------------updateCompanyFields-----------------------------------");
    //移除所属项目中的该任务及其子任务的节点
    let tasks = [];
    let tasksId = [taskId].concat(subtasksId || [])
    console.log("tasksId: ", tasksId)
    tasksId.forEach(item => {
      companysId.map(companyId => {
        tasks.push(wx.cloud.callFunction({
          name: 'companyUpdate',
          data: {
            removeTasks: true,
            companyId: companyId,
            taskId: item
          }
        }))
      })
    });
    this.data.tasksPromise = this.data.tasksPromise.concat(tasks);
    console.log("tasks: ", tasks);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  updateFileFields(privateFilesId, privateFilesIdPath, filesId, taskId, subtasksId) {
    console.log('-----------------------------------updateFileFields----------------------------------------')
    //删除私有文件
    const removePrivateFiles = privateFilesId.map(item => {
      return wx.cloud.callFunction({
        name: 'fileUpdate',
        data: {
          removeFile: true,
          fileId: item
        }
      });
    });
    console.log("removePrivateFiles: ", removePrivateFiles);
    this.data.tasksPromise = this.data.tasksPromise.concat(removePrivateFiles);
    const deletePrivateFiles = wx.cloud.deleteFile({
      fileList: privateFilesIdPath
    });
    this.data.tasksPromise.push(deletePrivateFiles);
    //taskNode
    const taskNode = [];
    let tasksId = [taskId].concat(subtasksId || [])
    console.log("tasksId: ", tasksId)
    tasksId.forEach(item => {
      filesId.map(fileId => {
        taskNode.push(wx.cloud.callFunction({
          name: 'fileUpdate',
          data: {
            removeTaskNode: true,
            fileId: fileId,
            taskId: item
          }
        }))
      })
    })
    console.log("taskNode: ", taskNode);
    this.data.tasksPromise = this.data.tasksPromise.concat(taskNode);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  updateFolderFields(foldersId, taskId, subtasksId) {
    console.log('-----------------------------------updateFolderFields----------------------------------------')
    const taskNode = []
    let tasksId = [taskId].concat(subtasksId || [])
    console.log("tasksId: ", tasksId)
    tasksId.forEach(item => {
      foldersId.map(folderId => {
        taskNode.push(wx.cloud.callFunction({
          name: 'folderUpdate',
          data: {
            removeTaskNode: true,
            folderId: folderId,
            taskId: item
          }
        }))
      })
    })
    
    console.log("taskNode: ", taskNode);
    this.data.tasksPromise = this.data.tasksPromise.concat(taskNode);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  updateUserFields(membersId, taskId, subtasksId) {
    console.log("-----------------------------------------updateUserFields------------------------------------");
    const tasks = []
    const tags = []
    let tasksId = [taskId].concat(subtasksId || [])
    console.log("tasksId: ", tasksId)
    tasksId.forEach(item => {
      membersId.map(memberId => {
        console.log("item, memberId: ", item, memberId)
        tasks.push(wx.cloud.callFunction({
          name: 'userUpdate',
          data: {
            removeTasks: true,
            userId: memberId,
            taskId: item
          }
        }))
        tags.push(wx.cloud.callFunction({
          name: 'userUpdate',
          data: {
            removeTag: true,
            userId: memberId,
            taskId: item
          }
        }))
      });
    })
    console.log("tasks: ", tasks);
    console.log("tags: ", tags);
    this.data.tasksPromise = this.data.tasksPromise.concat(tasks);
    this.data.tasksPromise = this.data.tasksPromise.concat(tags);
    console.log("this.data.tasksPromise: ", this.data.tasksPromise)
  },
  showAction(){
    let _this = this;
    wx.showActionSheet({
      itemList: ['确定删除', '取消'],
      success(res) {
        console.log(res.tapIndex);
        if (res.tapIndex === 0) {
          _this.delTask()
        } else {
          
        }
      },
      fail(res) {
        console.log(res.errMsg)
      }
    })
  }
})