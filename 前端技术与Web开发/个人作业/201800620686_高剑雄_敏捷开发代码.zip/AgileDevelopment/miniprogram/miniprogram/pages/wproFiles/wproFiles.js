// pages/wproFiles/wproFiles.js
const app = getApp()
const util = require('../../util/wutils.js')
const images = require('../../util/images.js')

//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const folderDB = db.collection("folders")
const taskDB = db.collection('tasks')
const projectDB = db.collection('projects')
const fileDB = db.collection('files')
const eventDB = db.collection("events")
Page({
  data: {
    images: images,
    screenWidth: app.globalData.screenWidth,
    capsuleInfo: app.globalData.capsuleInfo,

  },
  onLoad: function (options) {
    let _this = this
    _this.setData({ proId: options.proId})
    projectDB.doc(options.proId).get().then(res => {
      _this.setData({projectInfo: res.data,filesId: res.data.files || [],//直接子文件
        foldersId: res.data.folders || [],//直接子文件夹
        tasksId: res.data.allTasksNode || [],//全部任务
        eventsId: res.data.events||[]
        });
      
      //获取文件信息
      if (_this.data.filesId) {
        console.log("-----------------------------加载文件信息---------------------------------")
        const filesId = _this.data.filesId;
        util.getFilesInfo(filesId).then(res => {
          let filesInfo = res.map(item => { return item.data });
          filesInfo.map(item => {
            return item.extension = item.name.split('.').pop(), item.fname = item.name.split('.').slice(0, -1).join('.')
          });
          _this.setData({ filesInfo: filesInfo, })
        })
      };
      if (_this.data.foldersId) {
        console.log("-----------------------------加载文件夹信息---------------------------------")
        let queryFolders = _this.data.foldersId.map(item => { return folderDB.doc(item).get() });
        Promise.all(queryFolders).then(res => {
          let foldersInfo = res.map(item => { return item.data });
          _this.setData({ foldersInfo: foldersInfo})
        })
      };
      //获取任务信息
      if (_this.data.tasksId) {
        let queryTasks = _this.data.tasksId.map(item => {return taskDB.doc(item).get()});
        Promise.all(queryTasks).then(res => {
          let tasksInfo = res.map(item => {return item.data});
          _this.setData({ tasksInfo: tasksInfo })
        })
      }
      //获取日程信息
      if (_this.data.eventsId) {
        let queryEvents = _this.data.eventsId.map(item => { return eventDB.doc(item).get() });
        Promise.all(queryEvents).then(res => {
          let eventsInfo = res.map(item => { return item.data });
          _this.setData({ eventsInfo: eventsInfo })
        })
      }
    });
  },

  /**
  * 进入文件详情页
  */
  fileDetail: function (e) {
    // console.log(e)
    const fileId = e.currentTarget.dataset.fileid;
    wx.navigateTo({
      url: '../wfileDetail/wfileDetail?fileId=' + fileId,
    })
  },
  goBack: function () {
    wx.navigateBack({
      delta: 1
    })
  },
  folderDetail(e) {
    const folderId = e.currentTarget.dataset.folderid;
    wx.navigateTo({ url: '../wfolderDetail/wfolderDetail?folderId=' + folderId + '&view=0'})
  },
  taskEventFile(e) {
    const dataset = e.currentTarget.dataset;
    if (dataset.eventid) {
      wx.navigateTo({ url: '../waddLink/waddLink?eventId=' + dataset.eventid + '&view=0' })
    }
    if (dataset.taskid) {
      wx.navigateTo({ url: '../waddLink/waddLink?taskId=' + dataset.taskid + '&view=0' })
    }
  }
})