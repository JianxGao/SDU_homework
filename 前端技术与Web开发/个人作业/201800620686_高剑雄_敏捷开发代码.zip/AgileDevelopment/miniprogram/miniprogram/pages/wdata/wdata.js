// pages/wdata/wdata.js
const app = getApp()
const util = require('../../util/wutils.js')
const images = require('../../util/images.js')
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const taskDB = db.collection('tasks')
const projectDB = db.collection('projects')
const fileDB = db.collection('files')
Page({
 
  data: {
    tabIndex: 0,
    tabs: ['工程文档', '笔记/课件', '全部'],
    capsuleInfo: app.globalData.capsuleInfo,
    images: images,
    navigatorH: app.globalData.navigatorH,//
    statusBarHeight: app.globalData.statusBarHeight,//状态栏的高度，单位px
    isLogin: app.globalData.login
  },

  tabclick: function(e) {
    // console.log(e.detail.index);
    this.setData({
      tabIndex: e.detail.index
    }) 
  },

  goBack() {wx.navigateBack({delta: 1})},
  onLoad: function (options) {
    let _this = this
    this.setData({
      isLogin: app.globalData.login
    })
    if (app.globalData.login) {
      // 获取该用户所在的项目
      userDB.doc(app.globalData.openid).get().then(res => {
        console.log(res.data);
        if (res.data.projects) {
          const prosId = res.data.projects;
          util.getProjectsInfo(prosId)
          .then(res => {
            let projectsInfo = res.map(item => { return item.data });
            _this.setData({ projectsInfo: projectsInfo,})
            console.log("projectsInfo: ", projectsInfo)
          })
        }
      })
    }
  },
  proFiles: function(e) {
    const proId = e.currentTarget.dataset.proid
    wx.navigateTo({
      url: '../wproFiles/wproFiles?proId=' + proId,
    })
  },
  
})