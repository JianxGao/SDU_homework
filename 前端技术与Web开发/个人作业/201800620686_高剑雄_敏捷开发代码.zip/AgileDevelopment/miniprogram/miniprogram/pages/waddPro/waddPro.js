// pages/waddPro/waddPro.js
let app = getApp()
//获取数据库引用
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const companyDB = db.collection('companys')
Page({ 
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    project: null,
    brief: null,
    saving: false
  },
  goBack: function() {wx.navigateBack()}, 

  inputProject: function(e) {
    this.setData({
      project: e.detail.value
    })
  },
  inputBrief: function(e) {
    this.setData({
      brief: e.detail.value
    })
  },
  
  submit: function() {
    const _this = this
    wx.showLoading({
      title: '创建中...',
    });
    wx.cloud.callFunction({
      name: "addDoc",
      data: {
        addProject: true,
        data: {
          name: _this.data.project,//项目名
          brief: _this.data.brief,//项目简介
          creator: app.globalData.openid,//创建者，此用户本身
          creationTime: new Date().toLocaleString(),//创建时间
          members: [app.globalData.openid],//默认成员包括该用户本身
          tasksnode: {0:[],1:[],2:[]},//任务节点，由于任务的种类不止一种，因此记为对象
          companys: [_this.data.currentCompany],//所属班级
          addPermission: Array.from(new Set(_this.data.companyInfo.addPermission).add(app.globalData.openid)),//添加内容权限
          deletePermission: Array.from(new Set(_this.data.companyInfo.deletePermission).add(app.globalData.openid)),//删除项目及其内容权限
          modifyPermission: Array.from(new Set(_this.data.companyInfo.modifyPermission).add(app.globalData.openid))//修改内容权限
        }
      },
      success: res => {
        console.log("miao创建了任务")
        const proId = res.result._id
        //将该项目的id添加到该用户的字段中
        const promise = wx.cloud.callFunction({
          name: "userUpdate",
          data: {
            addProjects: true,
            userId: app.globalData.openid,
            proId: proId,
          }
        })
        //将该项目的id添加到该公司的字段中
        const promise1 = wx.cloud.callFunction({
          name: 'companyUpdate',
          data: {
            addProjects: true,
            companyId: app.globalData.currentCompany,
            proId: proId
          }
        });
        //
        Promise.all([promise, promise1]).then(res => {
          console.log("添加成功", app.globalData.currentCompany);
          wx.navigateTo({
            url: '../wproDetail/wproDetail?proId=' + proId + '&add=0'
          });
          _this.setData({
            saving: false
          })
        })
      },
    })
  },

  onLoad: function (options) {
    let _this = this
    console.log(options);
    //查询该用户的项目信息
    userDB.doc(app.globalData.openid).get().then(res => {
      // console.log('res: ', res.data)
      if (!app.globalData.currentCompany) {
        console.log("设置初始值")
        app.globalData.currentCompany = res.data.companys[0];
      }
      _this.setData({
        currentCompany: app.globalData.currentCompany
      });
      companyDB.doc(app.globalData.currentCompany).get().then(res => {
        _this.setData({companyInfo: res.data})
      })
    })
  },
})