const {appID, appsecret} = require("./config.js")
export class Wechat {
  constructor() {
  }
  fetch(opts) {
    return new Promise((resolve, reject) => {
      wx.request({
        url: opts.url || '',
        method: opts.method || 'GET',
        data: opts.data || '',
        header: opts.header || { 'content-type': 'application/json' },
        dataType: opts.dataType || 'json',
        success: res => {
          resolve(res)
        },
        fail: res => {
          reject(res);
        }
      })
    })
  }
  /**
   * 用来获取access token
   * access_token: "27_W3XgOAAAxlVcVL07s1LG-MrVONnwZ0cVpPdx_vi_UlGKmBpWFpsCE_ELLZALdXn167MRg2bv7dcjCW8-ESuXNPNyNjHBbAcdr0UbfpMIqL1Mjf0Aa5XlEZXuwisIALhAIANFQ"
expires_in: 7200
   */
  getAccessToken () {
    const url = `https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${appID}&secret=${appsecret}`
    return new Promise((resolve, reject) => {
      this.fetch({ method: 'GET', url: url, header: { 'content-type': 'application/json' } })
        .then(res => {
          console.log(res);
          //设置过期时间
          const access_token = res.data;
          access_token.expires_in = Date.now() + (access_token.expires_in - 300) * 1000;
          //将promise对象状态改为成功的状态
          resolve(access_token);
        })
        .catch(res => { 
          console.log(res);
          reject('getAccessToken方法错误', res)
        })
    })
  }

  /**
   * 用来保存access token
   */
  saveAccessToken(accessToken) {
    accessToken = JSON.stringify(accessToken)
    let fsm = wx.getFileSystemManager();
    return new Promise ((resolve, reject) => {
      fsm.writeFile({
        filePath: wx.env.USER_DATA_PATH + '/accessToken.txt',
        data: accessToken,
        encoding: 'utf8',
        success: res => {
          console.info(res);
          resolve()
        },
        fail: res => {
          console.info(res);
          reject("saveAccessToken错误", res)
        }
      })
    })
  }
  /**
   * 读取access token
   */
  readAccessToken() {
    let fsm = wx.getFileSystemManager();
    return new Promise((resolve, reject) => {
      fsm.readFile({
        filePath: wx.env.USER_DATA_PATH + '/accessToken.txt',
        encoding: 'utf8',
        success: res => {
          console.log(res.data);
          const data = JSON.parse(res.data)
          resolve(data)
        },
        fail: res => {
          reject("readAccessToken失败", res)
        }
      })
    })
  }

  /**
   * 是否有效
   */
  isValidAccessToken(data) {
    console.log(typeof (data), data)
    if (data && data.access_token && !data.expires_in) {
      return false;
    }
    return data.expires_in > Date.now();
  }

  /**
   * 
   */
  fetchAccessToken() {
    if (this.access_token && this.expires_in && this.isValidAccessToken(this)) {
      return Promise.resolve({
        access_token: this.access_token,
        expires_in: this.expires_in
      })
    }
    return this.readAccessToken()
      .then(async res => {
        console.log(res);
        if (this.isValidAccessToken(res)) {
          // resolve(res)
          return Promise.resolve(res);
        } else {
          const res = await this.getAccessToken();
          await this.saveAccessToken(res)
          // resolve(res);
          return Promise.resolve(res);
        }
      })
      .catch(async err => {
        console.log(err);
        const res = await this.getAccessToken();
        await this.saveAccessToken(res)
        // resolve(res);
        return Promise.resolve(res);
      })
      .then(res => {
        this.access_token = res.access_token;
        this.expires_in = res.expires_in;
        return Promise.resolve(res);
      })
  }

  /**
   * 询问用户
   */
  reuqestSubscribMessage(){
    return new Promise((resolve, reject) => {
      wx.requestSubscribeMessage({
        tmplIds: ['k0Fyyhv3eVsmVftmXcU4DyMrtULBW-4CNg64d_9PncI'],
        success: res => {
          console.log(res);
          resolve(res);
        },
        fail: res => {
          console.log(res)
        }
      })
    })
  }

  /**
   * 用来发送消息
   */
  requestSendTemplete(touser, sender, sendTime) {
    return this.fetchAccessToken()
      .then(res => {
        let access_token = res.access_token;
        let url = `https://api.weixin.qq.com/cgi-bin/message/subscribe/send?access_token=${access_token}`;
        let params = {
          touser: touser,
          template_id: 'k0Fyyhv3eVsmVftmXcU4DyMrtULBW-4CNg64d_9PncI',
          page: 'pages/wproDetail/wproDetail',
          data: {
            "name1": { "value": sender },
            "date2": { "value": sendTime },
            "thing3": { "value": "您有一条新消息请查阅！" },
          }
        };
        this.fetch({ method: "POST", url: url, data: params })
          .then(res => {
            console.log(res)
            return Promise.resolve(res);
          })
          .catch(res => {
            console.log(res);
          })
      })
  }

}


