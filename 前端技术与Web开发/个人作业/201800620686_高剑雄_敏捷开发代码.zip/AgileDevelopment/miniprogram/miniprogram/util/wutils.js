const app = getApp()
const db = wx.cloud.database();
const userDB = db.collection('user') 
const companyDB = db.collection('companys')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
const eventDB = db.collection('events')
const fileDB = db.collection('files');
const folderDB = db.collection('folders')
var dateTimePicker = require('./dateTimePicker.js');
const { Wechat } = require('./accessToken.js');
const w = new Wechat();
/**
 * 网络请求 
 */ 
function fetch(opts) {
  return new Promise((resolve, reject) => {
    wx.request({
      url: opts.url || '',
      method: opts.method || 'GET',
      data: opts.data || '',
      header: opts.header || { 'content-type': 'application/json' },
      dataType: opts.dataType || 'json',
      success: res => {
        resolve(res)
      },
      fail: res => {
        reject(res);
      }
    })
  })
}

function fetchDownloadUrl(fileID, access_token) {
  // access_token = ''
  console.log(access_token)
  const url = `https://api.weixin.qq.com/tcb/batchdownloadfile?access_token=${access_token}`;
  var params = { "env": "mapp-5f3o8", "file_list": [{ "fileid": fileID, "max_age": 7200 }] }
  let opts = {method: 'POST',url: url,header: { 'content-type': 'application/json' },data: params}
  return new Promise((resolve, reject) => {
    fetch(opts)
    .then(res => {
      console.log(res);
      resolve(res)
    })
    .catch(res => {
      console.log(res);
      reject('fetchDownloadUrl错误', res)
    })
  })
}

function saveFileToDB(fileID, tempFileName, _this, layer, 
    folderNode, allFolderNode,membersId, proNode, companysId, taskId, eventId,
    addPermission, deletePermission, modifyPermission) {
  console.log('')
  w.fetchAccessToken()
  .then(res => {
    console.log(res)
    let access_token = res.access_token;
    fetchDownloadUrl(fileID, access_token)
    .then(res => {
      console.log(res);
      const downloadUrl = res.data.file_list[0].download_url;
      console.log("获取到的下载链接：", downloadUrl);
      _this.setData({
        downloadUrl: downloadUrl
      });
      let data = {
        name: tempFileName,//文件名称
        creator: app.globalData.openid,//上传者
        creationTime: new Date().valueOf(),//上传时间
        fileID: fileID,//存储位置
        size: _this.data.size,//文件大小
        dowloadUrl: downloadUrl,//下载地址
        proNode: proNode,//所属项目
        layer: layer,//层级0,....
        folderNode: folderNode,//所属文件夹，直接，一个字符串
        allFolderNode: allFolderNode,//所有所属文件夹
        members: membersId,//项目成员
        companys: companysId,//所属公司
        taskNode: taskId ? [taskId] : [],//所属任务
        eventNode: eventId? [eventId] : [],//所属日程
        addPermission: Array.from(new Set(addPermission).add(app.globalData.openid)),//添加内容权限
        deletePermission: Array.from(new Set(deletePermission).add(app.globalData.openid)),//删除项目及其内容权限
        modifyPermission: Array.from(new Set(modifyPermission).add(app.globalData.openid)),//修改内容权限
      };
      saveFile2DB(data).then(res => {
        console.log("保存到数据库成功", res);
        const fileId = res.result._id;
        _this.setData({tasksPromise: []})
        // updateFilesField(fileId, proId, layer,_this);
        //更新项目表，projects: files, allfiles
        updateProjectFields(fileId, proNode,layer, _this.data.tasksPromise);
        //更新班级表，companys：files
        updateCompanysFields(fileId, companysId, _this.data.tasksPromise);
        //更新用户表，user: files
        updateUserFields(fileId, _this.data.tasksPromise);
        if (folderNode && allFolderNode.length > 0) {
          //更新文件夹表
          updateFolderFields(allFolderNode, folderNode, fileId, _this.data.tasksPromise)
        }
        //更新任务表，tasks: files
        if (taskId) {
          updateTaskFields(fileId, taskId, _this.data.tasksPromise)
        }
        //更新日程表，events: files
        if (eventId) {
          updateEventFields(fileId, eventId, _this.data.tasksPromise)
        }
        Promise.all(_this.data.tasksPromise).then(res => {
          console.log("上传成功");
          getFilesInfo([fileId].concat(_this.data.filesId || [])).then(res => {
            let filesInfo = res.map(item => { return item.data });
            filesInfo.map(item => { return item.isRotate = false })
            _this.setData({
              filesInfo: filesInfo,
              filesId: filesInfo.map(item => { return item._id })
            });
            wx.hideLoading()
          })
        })
      }) 
    })
  })
}
function updateProjectFields(fileId, proNode, layer, tasksPromise){
  console.log("------------------------------updateProjectFields-----------------------------")
  if (layer === 0) {
    const files = proNode.map(proId => {
      return wx.cloud.callFunction({
        name: 'projectUpdate',
        data: {
          addFile: true,
          proId: proId,
          fileId: fileId
        }
      });
    })
    console.log("files: ", files);
    tasksPromise.push(files);
  }
  const allfiles = proNode.map(proId => {
    return wx.cloud.callFunction({
      name: 'projectUpdate',
      data: {
        addAllFile: true,
        proId: proId,
        fileId: fileId
      }
    });
  })
  console.log("allfiles: ", allfiles);
  tasksPromise.push(allfiles);
  console.log("tasksPromise： ", tasksPromise);
}
function updateUserFields(fileId, tasksPromise) {
  console.log("------------------------------updateUserFields-----------------------------")
  const files = wx.cloud.callFunction({
    name: 'userUpdate',
    data: {
      addFile: true,
      userId: app.globalData.openid,
      fileId: fileId
    }
  });
  console.log("files: ", files);
  tasksPromise.push(files);
}
function updateCompanysFields(fileId, companysId, tasksPromise) {
  console.log("------------------------------updateCompanysFields-----------------------------")
  const files = companysId.map(companyId => {
    return wx.cloud.callFunction({
      name: 'companyUpdate',
      data: {
        addFiles: true,
        companyId: companyId,
        fileId: fileId
      }
    });
  })
  console.log("files: ", files);
  tasksPromise = tasksPromise.concat(files);
  console.log("tasksPromise: ", tasksPromise)
}
function updateFolderFields(foldersId,parentFolderId, fileId, tasksPromise) {
  console.log("------------------------------updateFolderFields-----------------------------")
  const subfiles = wx.cloud.callFunction({
    name: 'folderUpdate',
    data: {
      addSubFiles: true,
      folderId: parentFolderId,
      fileId: fileId
    }
  });
  console.log("subfiles: ", subfiles);
  tasksPromise.push(subfiles);
  const files = foldersId.map(folderId => {
    return wx.cloud.callFunction({
      name: 'folderUpdate',
      data: {
        addFiles: true,
        folderId: folderId,
        fileId: fileId
      }
    })
  });
  console.log("files: ", files);
  tasksPromise = tasksPromise.concat(files);
  console.log("tasksPromise: ", tasksPromise)
}
function updateTaskFields(fileId, taskId, tasksPromise) {
  console.log("------------------------------updateTaskFields-----------------------------")
  const files = wx.cloud.callFunction({
    name: 'taskUpdate',
    data: {
      addFiles: true,
      taskId: taskId,
      fileId: fileId
    }
  })
  console.log("files: ", files);
  tasksPromise.push(files);
  const privatefiles = wx.cloud.callFunction({
    name: 'taskUpdate',
    data: {
      addPrivateFiles: true,
      taskId: taskId,
      fileId: fileId
    }
  })
  console.log("privatefiles: ", privatefiles);
  tasksPromise.push(privatefiles);
  console.log("tasksPromise： ", tasksPromise);
}
function updateEventFields(fileId, eventId, tasksPromise) {
  console.log("------------------------------updateEventFields-----------------------------")
  const files = wx.cloud.callFunction({
    name: 'eventUpdate',
    data: {
      addFiles: true,
      eventId: eventId,
      fileId: fileId
    }
  })
  console.log("files: ", files);
  tasksPromise.push(files);
  const privatefiles = wx.cloud.callFunction({
    name: 'eventUpdate',
    data: {
      addPrivateFiles: true,
      eventId: eventId,
      fileId: fileId
    }
  })
  console.log("privatefiles: ", privatefiles);
  tasksPromise.push(privatefiles);
  console.log("tasksPromise： ", tasksPromise);
}
/**
 * 保存文件到数据库
 */
function saveFile2DB(data) {
  console.log("保存文件到数据库。。。。。");
  return wx.cloud.callFunction({
    name: 'addDoc',
    data: {
      addFile: true,
      data: data
    }
  })
}

/**
 * 获取文件大小，wproDetail
 */
function getFileSize(fileByte) {
  var fileSizeByte = fileByte;
  var fileSizeMsg = '';
  if (fileSizeByte < 1048576) fileSizeMsg = (fileSizeByte / 1024).toFixed(2) + 'KB';
  else if (fileSizeByte == 1048576) fileSizeMsg = '1MB';
  else if (fileSizeByte > 1048576 && fileSizeByte < 1073741824) fileSizeMsg = (fileSizeByte/1024/1024).toFixed(2) + 'MB';
  else if (fileSizeByte > 1048576 && fileSizeByte == 1073741824) fileSizeMsg = "1GB";
  else if (fileSizeByte > 1073741824 && fileSizeByte < 1099511627776) fileSizeMsg = (fileSizeByte/1024/1024/1024).toFixed(2) + 'GB';
  else fileSizeMsg = '文件大小超过1TB';
  return fileSizeMsg
}

/**
 * 根据时间戳来获取年，月，日，时，分，周等信息
 * wproDetail/weventDetail/wschedule
 */
function getTimeInfo(time, start) {
  let _time = new Date(time);
  var _year = _time.getFullYear();
  var _month = _time.getMonth() + 1;
  _month = formatNumber(_month)
  var _day = _time.getDate();
  var _hour = _time.getHours();
  _hour = formatNumber(_hour)
  var _minute = _time.getMinutes();
  _minute = formatNumber(_minute)
  if (start) {
    var _weekday = _time.getDay();
    switch (_weekday) {
      case 0:
        _weekday = '周日';
        break;
      case 1:
        _weekday = '周一';
        break;
      case 2:
        _weekday = '周二';
        break;
      case 3:
        _weekday = '周三';
        break;
      case 4:
        _weekday = '周四';
        break;
      case 5:
        _weekday = '周五';
        break;

      case 6:
        _weekday = '周六';
        break;

    }
    return { year: _year, month: _month, day: _day, hour: _hour, minute: _minute, weekday: _weekday }
  } else {
    return { year: _year, month: _month, day: _day, hour: _hour, minute: _minute }
  }
}

/**
 * 获取日程信息
 * wproDetail / wschedule
 */
function getEventInfo(_this, eventsId) {
  if (eventsId.length === 0) {
    wx.hideLoading();
    _this.setData({ eventsInfoGroup: []})
    return;
  }
  // let _this = this;
  let tasks = [];
  for (let i = 0; i < eventsId.length; i++) {
    const promise = eventDB.doc(eventsId[i]).get()
    tasks.push(promise);
  }
  Promise.all(tasks).then(res => {
    // console.log(res);
    let eventsInfo = res.map(item => { return item.data });
    eventsInfo.map(item => {return item.loading = true});
    //查询出开始月份
    eventsInfo.map(item => {
      const start = getTimeInfo(item.start, true);
      item.startDate = `${start.year}-${start.month}`;
      item.startTime = `${start.year}-${start.month}-${start.day} ${start.hour}:${start.minute}`;
      item.start = start;
      const end = getTimeInfo(item.end);
      item.endTime = `${end.year}-${end.month}-${end.day} ${end.hour}:${end.minute}`;
      item.end = end;
      userDB.doc(item.creator).get().then(res => {
        item.userHeader = res.data.userHeader;
        console.log(item)
        item.loading = false;
        if (eventsInfo.filter(item => { return item.loading === true }).length === 0) {
          //根据开始日期分组
          // console.log("根据开始日期分组")
          let dateGroup = new Set(eventsInfo.map(item => { return item.startDate }));
          let eventsInfoGroup = [];
          let length = 0;
          dateGroup.forEach(ele => {
            let _group = eventsInfo.filter(item => { return item.startDate === ele })
            length += _group.length;
            console.log(ele, _group);
            _group.map(item => { return item.isRotate = false });
            console.log(ele, _group);
            // console.log("length: ", length)
            eventsInfoGroup.push({ date: ele, eventsInfo: _group })
          })
          
          while (length === eventsId.length) {
            eventsInfoGroup.sort((a, b) => new Date(a.date) - new Date(b.date));
            //获取top值;
            let titleHeight = 35;
            let labelHeight = 30;
            let top = 0;
            eventsInfoGroup.map((item, index) => {
              let itemNum = index - 1 >= 0 ? eventsInfoGroup[index - 1].eventsInfo.length : 0;
              let labelHeight = index - 1 >= 0 ? 30 : 0;
              console.log("日程数量:", index, itemNum);
              top += labelHeight + 100 * itemNum;
              console.log("top: ", top)
              return item.top = top;
            })
            console.log("eventsInfoGroup: ", eventsInfoGroup);
            _this.setData({
              eventsInfoGroup: eventsInfoGroup,
            })
            wx.hideLoading()
            console.log(true);
            return; 
          }
        }
        return item
      })
    });
  }).catch(res => {
    console.log(res)
  })
}

/**
 * 根据文件的id获取文件的信息
 * wproDetail / wdata
 */
function getFilesInfo(filesId) {
  let tasks = [];
  for (let i = 0; i < filesId.length; i++) {
    const promise = fileDB.doc(filesId[i]).get();
    tasks.push(promise);
  }
  return Promise.all(tasks)
}

/**
 * 根据文件的id获取文件夹的信息
 * wproDetail / wdata
 */
function getFoldersInfo(foldersId) {
  let tasks = [];
  for (let i = 0; i < foldersId.length; i++) {
    const promise = folderDB.doc(foldersId[i]).get();
    tasks.push(promise);
  }
  return Promise.all(tasks)
}


/**
 * 根据成员id数组获取成员的详细信息
 * wproDetail / wtaskDetail / waddFollower / waddEvent / waddTask / waddsubtask / wtaskDetail
 */
function getMembersInfo(_this, membersId) {
  // let _this = this
  let tasks = []
  //获取成员的具体信息
  for (let i = 0; i < membersId.length; i++) {
    const promise = userDB.doc(membersId[i]).get();
    tasks.push(promise)
  }
  Promise.all(tasks).then(res => {
    let _MembersInfo = res.map(item => { return item.data });
    _MembersInfo.map(item => {return item.checked=true});
    _this.setData({
      _MembersInfo: _MembersInfo
    })
  }).catch(res => {
    console.log(res)
  })
}
/**
   * 获取节点的信息
   *  返回Promise, wtasks， wbookmark
   */
function getTaskInfo(tasksNode) {
  let tasks = []
  for (let i = 0; i < tasksNode.length; i++) {
    const promise = taskDB.doc(tasksNode[i]).get()
    tasks.push(promise)
  }
  return Promise.all(tasks)
}
/**
 * 根据项目节点获取项目的信息
 * wproject
 */
function getProjectsInfo (projectsNode) {
  let tasks = [];
  for (let i = 0; i < projectsNode.length; i++) {
    const promise = projectDB.doc(projectsNode[i]).get();
    tasks.push(promise)
  }
  return Promise.all(tasks)
}

/**
 * 根据公司的id获取公司的信息
 * wcompany
 */
function getCompanysInfo (companysId) {
  let tasks = [];
  for (let i = 0; i < companysId.length; i++) {
    const promise = companyDB.doc(companysId[i]).get()
    tasks.push(promise)
  }
  return Promise.all(tasks)
}
/**
 * 获取公司，项目信息的键值对，自己参与的
 */
function getCompanyName2ProjectsInfo(companysId, projectsId, _this) {
  let c2pArray = [];
  let allprojectsInfo = [];
  getCompanysInfo(companysId).then(res => {
    let companyInfo = res.map(item => {return item.data}) //[{c1Info}, {c2Info},...]
    // let companyProjectsNode = companyInfo.map(item => { return item.projectsNode}); //[[nodes], [nodes], ]
    let companyProjecysInfo = companyInfo.map(item => {
      let companyName = item.name; //某一个班级的名称
      let companyId = item._id//某一个班级的id
      let companyCreationTime = new Date(item.creationTime).valueOf()//某一班级的创建时间;
      console.log("companyCreationTime: ", companyCreationTime);
      let companyProjectsNode = item.projectsNode //某一个班级的项目节点
      //该用户参与的班级的项目
      let userCompanyProjectsNode = companyProjectsNode.filter(item => { return projectsId.indexOf(item) != -1 });
      getProjectsInfo(userCompanyProjectsNode).then(projectsInfoObj => {
        let projectsInfo = projectsInfoObj.map(item => {return item.data});//某一班级下，该用户参与的项目信息
        projectsInfo.map(item => { return item.isTouchMove = false })
        console.log(projectsInfo)
        allprojectsInfo = allprojectsInfo.concat(projectsInfo);
        let sortProjectInfo = [];
        //筛选出截至时间不为null的值
        sortProjectInfo = projectsInfo.filter(item => {return item.end});
        //对筛选出来的截至时间不为null的值进行排序
        sortProjectInfo.sort((a, b) => a.end - b.end);
        //将时间为null的值放在最后
        sortProjectInfo = sortProjectInfo.concat(projectsInfo.filter(item => { return !item.end}))
        console.log(sortProjectInfo)
        c2pArray.push({
          name: companyName,
          _id: companyId,
          creationTime: companyCreationTime,
          projectsInfo: sortProjectInfo
        });
        //  eventsInfoGroup.sort((a, b) => new Date(a.date) - new Date(b.date))
        _this.setData({
          allprojectsInfo: allprojectsInfo
        });
        console.log(_this.data.allprojectsInfo.length, projectsId.length)
        while (_this.data.allprojectsInfo.length === projectsId.length) {
          _this.setData({
            loading: false
          })
          c2pArray.sort((a, b) => a.creationTime - b.creationTime)
          
          //获取top值;
          let searchBarHeight = 50;
          let actionBarHeight = 35; 
          let labelHeight = 30;
          let top = searchBarHeight + actionBarHeight;
          c2pArray.map((item, index) => {
            let itemNum = index - 1 >= 0 ? c2pArray[index - 1].projectsInfo.length : 0;
            let labelHeight = index - 1 >= 0 ? 30 : 0;
            console.log("项目数量:", index, itemNum);
            top += labelHeight  + 90 * itemNum;
            console.log("top: ", top)
            return item.top = top;
          })
          console.log("c2pArray: ", c2pArray);
          _this.setData({
            projectsInfoGroup: c2pArray,
          })
          console.log(true);
          return; 
        }
      })
    })
  })
}
/**
 * 根据公司id更新成员表的companys
 * membersId:需要更新的成员id
 * companyId：需要添加的公司id
 * tasksPromise： 存放promise任务的数组
 * waddFollower
 */
function updateCompanys(membersId, companyId, tasksPromise) {
  console.log(companyId)
  for (let i=0; i<membersId.length; i++) {
    let userId = membersId[i];
    for (let j = 0; j<companyId.length; j++) {
      const promise = wx.cloud.callFunction({
        name: 'userUpdate',
        data: {
          addCompany: true,
          userId: userId,
          companyId: companyId[j],
        }
      })
      console.log("updateCompanys:", companyId[j], promise)
      tasksPromise.push(promise)
    } 
  }
}
/**
 * 根据项目id更新项目表中的members
 * membersId:需要添加的成员id
 * companyId：需要更新的公司id
 * tasksPromise： 存放promise任务的数组
 * waddFollower
 */
function updateCompanysMembers(membersId, companyId, tasksPromise) {
  console.log(companyId)
  for (let i = 0; i < membersId.length; i++) {
    let userId = membersId[i]
    for (let j = 0; j<companyId.length;  j++) {
      const promise = wx.cloud.callFunction({
        name: 'companyUpdate',
        data: { 
          addMember: true,
          companyId: companyId[j],
          userId: userId
        }
      })
      console.log("updateCompanysMembers: ", companyId[j])
      tasksPromise.push(promise)
    }
  }
}
/**
 * 根据项目id更新项目表中的members
 * membersId: 需要添加的成员id
 * proId： 需要更新的项目id
 * tasksPromise： 存放promise任务的数组
 * waddTask / waddSubtask
 */
function updateProjectMembers(membersId, proId, tasksPromise) {
  // let _this = this;
  for (let i = 0; i < membersId.length; i++) {
    let userId = membersId[i];
    const promise = wx.cloud.callFunction({
      name: 'projectUpdate',
      data: {
        addMembers: true,
        proId: proId,
        userId: userId
      }
    })
    tasksPromise.push(promise)
  }
}
/**
 * 更新成员表中的tasksFollwer字段
 * membersId: 需要更新的成员
 * taskId： 需要添加的task id
 * tasksPromise：存放promise任务的数组
 * waddTask / waddSubtask
 */
function updateTasksFollower(membersId, taskId, tasksPromise) {
  for (let i = 0; i < membersId.length; i++) {
    let userId = membersId[i];
    // console.log(`正在更新第${i}个成员的信息`, userId)
    const promise = wx.cloud.callFunction({
      name: "userUpdate",
      data: {
        tasksFollower: true,
        userId: userId,
        taskId: taskId
      }
    })
    tasksPromise.push(promise)
  }
}
/**
 * 更新成员表中的tasksCreator字段
 * userId：需要更新的成员
 * taskId：需要在tasksCreator字段中添加的task id
 * tasksPromise：存放promise任务的数组
 * waddTask / waddSubtask
 */
function updateTasksCreator(userId, taskId, tasksPromise) {
  const promise = wx.cloud.callFunction({
    name: "userUpdate",
    data: {
      tasksCreator: true,
      userId: userId,
      taskId: taskId
    }
  })
  tasksPromise.push(promise)
}
/**
 * 更新执行者的成员信息;
 * executor: 需要更新的成员
 * taskId： 需要在字段tasksExcutor添加的task id
 * tasksPromise：存放promise任务的数组
 * waddTask / waddSubtask
 */
function updateTasksExecutor(executor, taskId, tasksPromise) {
  if (executor) {
    const promise = wx.cloud.callFunction({
      name: "userUpdate",
      data: {
        tasksExecutor: true,
        userId: executor,
        taskId: taskId
      }
    })
    tasksPromise.push(promise)
  }
}
/**
 * 更新成员表中的projects字段
 * membersId: 需要更新的成员
 * proId: 需要添加的项目id
 * tasksPromise：存放promise任务的数组
 * waddTask / waddSubtask
 */
function updateProjects(membersId, proId, tasksPromise) {
  // console.log("updating projects")
  for (let i = 0; i < membersId.length; i++) {
    let userId = membersId[i];
    const promise = wx.cloud.callFunction({
      name: "userUpdate",
      data: {
        projects: true,
        userId: userId,
        proId: proId
      }
    })
    tasksPromise.push(promise)
  }
}
/**
 * 为相应的任务更新成员信息； members
 * membersId：需要为任务添加的成员id
 * taskId： 需要更新的任务id
 * tasksPromise：存放promise任务的数组
 * waddFollower / waddSubtask
 */
function updateTaskMembers(membersId, taskId, tasksPromise) {
  for (let i = 0; i < membersId.length; i++) {
    let userId = membersId[i]
    const promise = wx.cloud.callFunction({
      name: 'taskUpdate',
      data: {
        members: true,
        taskId: taskId,
        userId: userId
      }
    })
    tasksPromise.push(promise)
  }
}
/**
 * 更新任务完成情况
 */
function updateTaksStatu(taskId, _TaskInfo) {
  let status;//当前任务的状态finished
  //更新tasksInfo 
  _TaskInfo
    .filter(item => { return item._id === taskId })
    .map(item => {
      console.log(item);
      item.finished = !item.finished;
      console.log(item)
      status = item.finished
      return item
    })
  // 更新task的finished字段
  console.log("status:", status, _TaskInfo)
  return wx.cloud.callFunction({
    name: 'taskUpdate',
    data: {
      updateFinished: true,
      taskId: taskId,
      finished: status
    }
  })
}
/**
 * 时间格式转换
 */
function formatDate(date) {
  date = new Date(date)
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var day = date.getDate();
  return [year, month, day].map(formatNumber).join('-')
}

function formatNumber(n) {
  n = n.toString();
  return n[1] ? n : '0' + n
}

/**
   * 对对象数组进行排序等处理
   */
function sortArray(array) {
  let _TaskInfo = array.map(item => { return item.data })
  _TaskInfo.filter(item => { return item.end !== null }).map(item => {
    return item.deadline = formatDate(item.end)
  })
  _TaskInfo.filter(item => { return item.end === null }).map(item => {
    return item.end = "2050-10-13"
  })
  //按截止时间排序
  _TaskInfo.sort((a, b) => new Date(a.end) - new Date(b.end))
  return _TaskInfo
}
function sortInfobyDeadline(_TaskInfo) {
  _TaskInfo.filter(item => { return item.end !== null }).map(item => {
    return item.deadline = formatDate(item.end)
  })
  _TaskInfo.filter(item => { return item.end === null }).map(item => {
    return item.end = "2050-10-13"
  })
  //按截止时间排序
  _TaskInfo.sort((a, b) => new Date(a.end) - new Date(b.end))
  return _TaskInfo
}

function getInitStartEndDetail (_InfoObj, startYear, endYear) {
  //开始时间{ year: _year, month: _month, day: _day, hour: _hour, minute: _minute }
  const startForm = _InfoObj.start ? getTimeInfo(_InfoObj.start) : null;
  const start = startForm ? `${startForm.year}-${startForm.month}-${startForm.day} ${startForm.hour}:${startForm.minute}` : null;
  console.log(startForm, start)
  //结束时间{ year: _year, month: _month, day: _day, hour: _hour, minute: _minute }
  const endForm = _InfoObj.end ? getTimeInfo(_InfoObj.end) : null;
  const end = endForm ? `${endForm.year}-${endForm.month}-${endForm.day} ${endForm.hour}:${endForm.minute}` : null;
  console.log(endForm, end)
  // 获取完整的年月日 时分，以及默认显示的数组 
  //开始时间
  var startobj = start ? dateTimePicker.dateTimePicker(startYear, endYear, start)
    : dateTimePicker.dateTimePicker(startYear, endYear);
  var startdateArr = startobj.dateTimeArray;
  console.log(startdateArr, startobj.dateTime)
  //截止时间， 若初始值为null，从当天开始获取
  var endobj = end ? dateTimePicker.dateTimePicker(startYear, endYear, end)
    : dateTimePicker.dateTimePicker(startYear, endYear);
  var enddateArr = endobj.dateTimeArray;
  console.log(enddateArr, endobj.dateTime);
  return {
    startDateTime: startobj.dateTime,
    endDateTime: endobj.dateTime,
    startdateTimeArray: startdateArr,
    enddateTimeArray: enddateArr,
    end: end,
    start: start,
    startForm: startForm,
    endForm: endForm
  }
}

function deletProject(queryProject) {
  let proId = queryProject._id
  let companyId = queryProject.company
  let projectMembers = queryProject.members;
  let tasks = []
  //删除该项目中的所有任务节点，任务表中
  taskDB.where({ proNode: proId}).get().then(res => {
    console.log(res.data);
    let alltasksNode = res.data.map(item => {return item._id});
    console.log("该项目的所有任务节点", alltasksNode);
    if (alltasksNode && alltasksNode.length > 0) {
      let removeTaskPromise = alltasksNode.map(taskid => {
        return wx.cloud.callFunction({
          name: 'taskUpdate',
          data: {
            removeTask: true,
            taskId: taskid
          }
        })
      });
      console.log(removeTaskPromise);
      tasks = tasks.concat(removeTaskPromise);
      console.log(tasks.length, tasks)
      let removeMembersTasksFollwerPromise = []
      projectMembers.map(membersid => {
        let memberidTasksPromise = alltasksNode.map(taskid => {
          return wx.cloud.callFunction({
            name: 'userUpdate',
            data: {
              deleteFollowerTaskNode: true,
              userId: membersid,
              taskId: taskid
            }
          })
        });
        console.log("removeMembersTasksFollwerPromise memberidTasksPromise:", memberidTasksPromise, memberidTasksPromise.length)
        removeMembersTasksFollwerPromise.concat(memberidTasksPromise);
      });
      tasks = tasks.concat(removeMembersTasksFollwerPromise);
      console.log(tasks.length, tasks)
      let removeMembersTasksExcutorPromise = []
      projectMembers.map(membersid => {
        let memberidTasksPromise = alltasksNode.map(taskid => {
          return wx.cloud.callFunction({
            name: 'userUpdate',
            data: {
              deleteExecutorTaskNode: true,
              userId: membersid,
              taskId: taskid
            }
          })
        });
        console.log("removeMembersTasksExcutorPromise memberidTasksPromise:", memberidTasksPromise.length)
        removeMembersTasksExcutorPromise.concat(memberidTasksPromise);
      });
      tasks = tasks.concat(removeMembersTasksExcutorPromise);
      let removeMembersTasksCreatorPromise = []
      projectMembers.map(membersid => {
        let memberidTasksPromise = alltasksNode.map(taskid => {
          return wx.cloud.callFunction({
            name: 'userUpdate',
            data: {
              deleteCreatorTaskNode: true,
              userId: membersid,
              taskId: taskid
            }
          })
        });
        console.log("removeMembersTasksCreatorPromise memberidTasksPromise:", memberidTasksPromise.length)
        removeMembersTasksCreatorPromise.concat(memberidTasksPromise);
      });
      tasks = tasks.concat(removeMembersTasksCreatorPromise);
      let removeMembersTagPromise = []
      projectMembers.map(membersid => {
        let memberidTasksPromise = alltasksNode.map(taskId => {
          return wx.cloud.callFunction({
            name: 'userUpdate',
            data: {
              deleteTags: true,
              userId: membersid,
              taskId: taskId
            }
          })
        });
        console.log("removeMembersTagPromise memberidTasksPromise:", memberidTasksPromise.length)
        removeMembersTagPromise.concat(memberidTasksPromise);
      });
      tasks = tasks.concat(removeMembersTagPromise);
    }
  })
  //删除该项目中的所有任务节点，任务表中
  eventDB.where({ proNode: proId }).get().then(res => {
    console.log(res.data);
    let alleventsNode = res.data.map(item => { return item._id });
    console.log("该项目的所有日程节点", alleventsNode);
    if (alleventsNode && alleventsNode.length > 0) {
      let removeEventPromise = alleventsNode.map(eventid => {
        return wx.cloud.callFunction({
          name: 'eventUpdate',
          data: {
            removeEvent: true,
            eventId: eventid
          }
        })
      });
      tasks = tasks.concat(removeEventPromise);
      let removeMembersEventPromise = []
      projectMembers.map(membersid => {
        let memberidTasksPromise = alleventsNode.map(eventid => {
          return wx.cloud.callFunction({
            name: 'userUpdate',
            data: {
              deleteEvents: true,
              userId: membersid,
              eventId: eventid
            }
          })
        });
        console.log("removeMembersEventPromise memberidTasksPromise:", memberidTasksPromise.length)
        removeMembersEventPromise.concat(memberidTasksPromise);
      });
      tasks = tasks.concat(removeMembersEventPromise);
    }
  })
  //删除该项目的所有文件节点，文件表中
  fileDB.where({ proNode: proId }).get().then(res => {
    console.log(res.data);
    let allfilesNode = res.data.map(item => { return item._id });
    console.log("该项目的所有文件节点", allfilesNode);
    if (allfilesNode && allfilesNode.length > 0) {
      let removeFilePromise = allfilesNode.map(fileid => {
        return wx.cloud.callFunction({
          name: 'addFile',
          data: {
            removeFile: true,
            fileId: fileid
          }
        })
      });
      tasks = tasks.concat(removeFilePromise);
      let removeMembersFilePromise = []
      projectMembers.map(membersid => {
        let memberidTasksPromise = allfilesNode.map(fileid => {
          return wx.cloud.callFunction({
            name: 'userUpdate',
            data: {
              removeFile: true,
              userId: membersid,
              fileId: fileid
            }
          })
        });
        console.log("removeMembersFilePromise memberidTasksPromise:", memberidTasksPromise.length)
        removeMembersFilePromise.concat(memberidTasksPromise);
      });
      tasks = tasks.concat(removeMembersFilePromise);
    }
    let allfilesFileId = res.data.map(item => { return item.fileID });
    console.log("该项目的所有文件fileId", allfilesFileId);
    if (allfilesFileId && allfilesFileId.length > 0) {
      const deleteFilePromise = wx.cloud.deleteFile({
          fileList: allfilesFileId
        })
      tasks = tasks.concat(deleteFilePromise);
    }
  })

  //删除该项目的所有文件节点，文件夹表中
  folderDB.where({ proNode: proId }).get().then(res => {
    console.log(res.data);
    let allfoldersNode = res.data.map(item => { return item._id });
    console.log("该项目的所有文件夹节点", allfoldersNode);
    if (allfoldersNode && allfoldersNode.length > 0) {
      let removeFilePromise = allfoldersNode.map(folderid => {
        return wx.cloud.callFunction({
          name: 'addFile',
          data: {
            removeFolder: true,
            folderId: folderid
          }
        })
      });
      tasks = tasks.concat(removeFilePromise);
      let removeMembersFolderPromise = []
      projectMembers.map(membersid => {
        let memberidTasksPromise = allfoldersNode.map(folderid => {
          return wx.cloud.callFunction({
            name: 'userUpdate',
            data: {
              deleteFolders: true,
              userId: membersid,
              folderId: folderid
            }
          })
        });
        console.log("removeMembersFolderPromise memberidTasksPromise:", memberidTasksPromise.length)
        removeMembersFolderPromise.concat(memberidTasksPromise);
      });
      tasks = tasks.concat(removeMembersFolderPromise);
    }
  })

  let removeMemberProjectsPromise = projectMembers.map(membersid => {
    return wx.cloud.callFunction({
      name: 'userUpdate',
      data: {
        deleteProjects: true,
        userId: membersid,
        proId: proId
      }
    })
  });
  tasks = tasks.concat(removeMemberProjectsPromise);
  //111
  const companyPromise = wx.cloud.callFunction({
    name: 'companyUpdate',
    data: {
      deleteProjects: true,
      companyId: companyId,
      proId: proId
    }
  });
  tasks = tasks.concat(companyPromise);
  console.log(companyPromise)
  //111
  const projectPromise = wx.cloud.callFunction({
    name: 'projectUpdate',
    data: {
      removeProject: true,
      proId: proId
    }
  });
  tasks = tasks.concat(projectPromise);

  console.log("全部长度：", tasks, tasks.length);
  return Promise.all(tasks)
}

function deleteFolderOperation(folderId, creator, proId, layer, parentFolderId, _this) {
  let _FolderTasks = [];
  let removeFolderSelf = wx.cloud.callFunction({
    name: 'addFile',
    data: {
      removeFolder: true,
      folderId: folderId
    }
  });
  _FolderTasks.push(removeFolderSelf);
  let removeCreatorFolderSelf = wx.cloud.callFunction({
    name: 'userUpdate',
    data: {
      deleteFolders: true,
      userId: creator,
      folderId: folderId
    }
  });
  _FolderTasks.push(removeCreatorFolderSelf);
  let removeProjectFolders = wx.cloud.callFunction({
    name: 'projectUpdate',
    data: {
      removeFolder: true,
      proId: proId,
      folderId: folderId
    }
  })
  _FolderTasks.push(removeProjectFolders);
  let queryFolder;
  let queryFile;
  if (layer === 0) {
    queryFolder = folderDB.where({ rootNode: folderId }).get();
    queryFile = fileDB.where({ rootNode: folderId }).get();
  } else {
    let obj = {};
    obj[layer] = folderId;
    console.log("查询条件：", obj)
    queryFolder = folderDB.where({parentNode: obj}).get();
    queryFile = fileDB.where({ parentNode: obj }).get();
  }
  Promise.all([queryFolder, queryFile]).then(res => {
    console.log(res);
    let allfoldersInfo = res[0].data;
    let allfilesInfo = res[1].data;
    if (allfoldersInfo.length > 0) {
      let allfoldersNode = allfoldersInfo.map(item => { return item._id });//_id
      let allfoldersCreator = allfoldersInfo.map(item => { return item.creator })//creator;
      let removeFolderPromise = allfoldersNode.map(folderid => {
        return wx.cloud.callFunction({
          name: 'addFile',
          data: {
            removeFolder: true,
            folderId: folderid
          }
        })
      });
      console.log(removeFolderPromise);
      _FolderTasks = _FolderTasks.concat(removeFolderPromise);
      let removeCreatorFolder = allfoldersInfo.map(item => {
        let folderid = item._id;
        let creatorid = item.creator;
        return wx.cloud.callFunction({
          name: 'userUpdate',
          data: {
            deleteFolders: true,
            userId: creatorid,
            folderId: folderid
          }
        })
      });
      console.log(removeCreatorFolder);
      _FolderTasks = _FolderTasks.concat(removeCreatorFolder);
    }
    if (allfilesInfo.length > 0) {
      let allfilesNode = allfilesInfo.map(item => { return item._id });//_id
      let allfilesCreator = allfilesInfo.map(item => { return item.creator })//creator;
      let removeFilePromise = allfilesNode.map(folderid => {
        return wx.cloud.callFunction({
          name: 'addFile',
          data: {
            removeFolder: true,
            folderId: folderid
          }
        })
      });
      console.log(removeFilePromise);
      _FolderTasks = _FolderTasks.concat(removeFilePromise);
      let removeCreatorFile = allfilesInfo.map(item => {
        let fileid = item._id;
        let creatorid = item.creator;
        return wx.cloud.callFunction({
          name: 'userUpdate',
          data: {
            deleteFolders: true,
            userId: creatorid,
            fileId: fileid
          }
        })
      });
      console.log(removeCreatorFile);
      _FolderTasks = _FolderTasks.concat(removeCreatorFile)
      let allfilesFileId = allfilesInfo.map(item => { return item.fileID });
      const deleteFilePromise = wx.cloud.deleteFile({
        fileList: allfilesFileId
      });
      _FileTasks = _FileTasks.concat(deleteFilePromise);
    }
    if (layer > 0) {
      //删除父文件夹下的该节点
      const promise = wx.cloud.callFunction({
        name: 'addFile',
        data: {
          removesubFolder: true,
          folderId: parentFolderId,
          subfolderId: folderId
        }
      })
      _FolderTasks.push(promise)
    }
    Promise.all(_FolderTasks).then(res => {
      console.log("文件夹删除：", res);
      wx.hideLoading();
      console.log("目前文件夹信息：", _this.data.foldersId)
      let foldersInfo = _this.data.foldersInfo.filter(item => { return item._id != folderId });
      console.log(_this.data.foldersInfo, foldersInfo)
      _this.setData({
        foldersInfo: foldersInfo,
        foldersId: foldersInfo.map(item => {return item._id})
      })
    })
  });
}
function deleteEventOperation(eventId, creator, members, proId) {
  let _Tasks = [];
  let removeEventSelf = wx.cloud.callFunction({
    name: 'eventUpdate',
    data: {
      removeEvent: true,
      eventId: eventId
    }
  });
  _Tasks.push(removeEventSelf);
  let removeMembersFolderSelf = members.map(memberid => {
    return wx.cloud.callFunction({
      name: 'userUpdate',
      data: {
        deleteEvents: true,
        userId: memberid,
        eventId: eventId
      }
    })
  });
  _Tasks = _Tasks.concat(removeMembersFolderSelf);
  let removeProjectEvents = wx.cloud.callFunction({
    name: 'projectUpdate',
    data: {
      removeEvent: true,
      proId: proId,
      eventId: eventId
    }
  });
  _Tasks = _Tasks.concat(removeProjectEvents);
  return Promise.all(_Tasks)
} 
/**
 * 删除文件操作
 *  删除files的一条记录
 *  删除存储空间中的该文件
 *  若该文件是存储在某一个自定义文件夹中（有folderNode节点）
 *    更新该folder的字段
 * 
 *  若该文件没有folderNode节点
 *    更新projects的字段
 *    更新上传者user的字段
 */
function deleteFileOperation(fileId, proId, creatorId, fileIDpath, folderNode) {
  let tasks = []
  //删除files表中的该doc
  const updatefiles = wx.cloud.callFunction({
    name: 'addFile',
    data: {
      removeFile: true,
      fileId: fileId
    }
  });
  tasks.push(updatefiles)
  console.log(tasks.length, tasks);
  //删除存储空间中的该文件
  const delfile = wx.cloud.deleteFile({
    fileList: [fileIDpath]
  })
  tasks.push(delfile)
  //若存在父文件夹节点；只需删除在父文件夹下的该文件节点
  if (folderNode) {
    const folderId = folderNode;
    const removesubfilepromise = wx.cloud.callFunction({
      name: 'addFile',
      data: {
        removesubFile: true,
        folderId: folderId,
        fileId: fileId
      }
    });
    tasks.push(removesubfilepromise)
  } else {
    const removeUserFiles = wx.cloud.callFunction({
      name: 'userUpdate',
      data: {
        deleteFiles: true,
        userId: creatorId,
        fileId: fileId
      }
    });
    tasks.push(removeUserFiles);
    const removeProjectFiles = wx.cloud.callFunction({
      name: 'projectUpdate',
      data: {
        deleteFile: true,
        proId: proId,
        fileId: fileId
      }
    });
    tasks.push(removeProjectFiles);
  }
  console.log(tasks.length, tasks);
  return Promise.all(tasks);
} 



module.exports = {
  fetch: fetch,
  getFileSize: getFileSize,
  getTimeInfo: getTimeInfo,
  getEventInfo: getEventInfo,
  getFilesInfo: getFilesInfo,
  getMembersInfo: getMembersInfo,
  getTaskInfo: getTaskInfo,
  getProjectsInfo: getProjectsInfo, 
  getCompanysInfo: getCompanysInfo,
  updateProjectMembers: updateProjectMembers,
  updateTasksFollower: updateTasksFollower,
  updateTasksCreator: updateTasksCreator,
  updateTasksExecutor: updateTasksExecutor,
  updateProjects: updateProjects,
  updateTaskMembers: updateTaskMembers,
  updateCompanys: updateCompanys,
  updateCompanysMembers: updateCompanysMembers,
  formatDate: formatDate,
  updateTaksStatu: updateTaksStatu,
  getCompanyName2ProjectsInfo: getCompanyName2ProjectsInfo,
  sortArray: sortArray,
  sortInfobyDeadline: sortInfobyDeadline,
  getInitStartEndDetail: getInitStartEndDetail,
  deletProject: deletProject,
  getFoldersInfo: getFoldersInfo,
  deleteFileOperation: deleteFileOperation,
  deleteFolderOperation: deleteFolderOperation,
  deleteEventOperation: deleteEventOperation,
  saveFile2DB: saveFile2DB,
  saveFileToDB: saveFileToDB,
  fetchDownloadUrl: fetchDownloadUrl
}
