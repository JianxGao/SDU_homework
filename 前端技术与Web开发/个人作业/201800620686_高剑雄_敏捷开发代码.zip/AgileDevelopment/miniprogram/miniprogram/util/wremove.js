//获取数据库引用
const app = getApp();
const db = wx.cloud.database();
const userDB = db.collection('user')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
const fileDB = db.collection('files')
const folderDB = db.collection('folders')
const companyDB = db.collection('companys')
const util = require('./wutils.js')
/**
 * 删除项目，remove project
 */
function _PupdateProjectField(proId, _PtasksPromise) {
  console.log("------------------------_PupdateProjectField--------------------------------")
  const removeProject = wx.cloud.callFunction({
    name: 'projectUpdate',data: { removeProject: true,proId: proId}
  });
  console.log("removeProject: ", removeProject);
  _PtasksPromise = _PtasksPromise.concat(removeProject);
  console.log("_PtasksPromise: ", _PtasksPromise)
}

function _PupdateTaskField(tasksId, _PtasksPromise) {
  console.log("------------------------_PupdateTaskField--------------------------------")
  const removeTasks = tasksId.map(taskId => {return wx.cloud.callFunction({
      name: 'taskUpdate', data: { removeTask: true, taskId: taskId }
  })})
  console.log("removeTasks: ", removeTasks);
  _PtasksPromise = _PtasksPromise.concat(removeTasks);
  console.log("_PtasksPromise: ", _PtasksPromise)
}

function _PupdateEventField(eventsId, _PtasksPromise) {
  console.log("------------------------_PupdateTaskField--------------------------------")
  const removeEvents = eventsId.map(eventId => {return wx.cloud.callFunction({
    name: 'eventUpdate', data: { removeEvent: true, eventId: eventId}
  })})
  console.log("removeEvents: ", removeEvents);
  _PtasksPromise = _PtasksPromise.concat(removeEvents);
  console.log("_PtasksPromise: ", _PtasksPromise)
}

function _PupdateFileField(unlinkfilesId, unlinkfilesPath, linkfilesId, proId, _PtasksPromise) {
  console.log("------------------------_PupdateFileField--------------------------------")
  //对于关联文件，更新其proNode节点
  const proNode = linkfilesId.map(fileId => {return wx.cloud.callFunction({
    name: 'fileUpdate', data: { removeProNode: true, fileId: fileId, proId: proId}
  })})
  console.log("proNode: ", proNode);
  _PtasksPromise = _PtasksPromise.concat(proNode);
  //对于非关联文件，删除记录并删除文件
  const removeFiles = unlinkfilesId.map(fileId => {return wx.cloud.callFunction({
    name: 'fileUpdate', data: { removeFile: true, fileId: fileId}
  })})
  console.log("removeFiles: ", removeFiles);
  _PtasksPromise = _PtasksPromise.concat(removeFiles);
  const deleteunlinkfiles = wx.cloud.deleteFile({
    fileList: unlinkfilesPath
  });
  console.log("deleteunlinkfiles: ", deleteunlinkfiles);
  _PtasksPromise = _PtasksPromise.concat(deleteunlinkfiles); 
  console.log("_PtasksPromise: ", _PtasksPromise)
}

function _PupdateFolderField(unlinkfoldersId, linkfoldersId, proId, _PtasksPromise) {
  console.log("------------------------_PupdateFolderField--------------------------------")
  //对于关联文件夹，更新其proNode节点
  const proNode = linkfoldersId.map(folderId => {return wx.cloud.callFunction({
    name: 'folderUpdate', data: { removeProNode: true, folderId: folderId, proId: proId }
  })})
  console.log("proNode: ", proNode);
  //对于非关联文件，删除记录并删除文件
  const removeFolders = unlinkfoldersId.map(folderId => {return wx.cloud.callFunction({
    name: 'folderUpdate', data: { removeFolder: true, folderId: folderId }  
  })})
  console.log("removeFolders: ", removeFolders);
  _PtasksPromise = _PtasksPromise.concat(removeFolders);
  console.log("_PtasksPromise: ", _PtasksPromise)
}

function _PupdateUserField(companyId, prosId, tasksId, eventsId, unlinkfilesId, unlinkfoldersId,  membersId, _PtasksPromise) {
  console.log("------------------------_PupdateUserField--------------------------------")
  if (companyId) {
    console.log(companyId)
    const company = membersId.map(item => {return wx.cloud.callFunction({
      name: 'userUpdate', data: { removeCompany: true, userId: item, companyId: companyId }
    })})
    console.log("company: ", company);
    _PtasksPromise = _PtasksPromise.concat(company);
  }
  const projects = []
  membersId.forEach(memberId => { prosId.map(proId => {projects.push(wx.cloud.callFunction({
    name: 'userUpdate', data: { removeProjects: true, userId: memberId, proId: proId}
  }))})});
  console.log("projects: ", projects);
  _PtasksPromise = _PtasksPromise.concat(projects);
  const tasks = []
  membersId.forEach(memberId => {tasksId.map(taskId => {tasks.push(wx.cloud.callFunction({
    name: 'userUpdate', data: { removeTasks: true, userId: memberId, taskId: taskId}
  }))})})
  console.log("tasks: ", tasks);
  _PtasksPromise = _PtasksPromise.concat(tasks);
  const tags = []
  membersId.forEach(memberId => {tasksId.map(taskId => {folders.push(wx.cloud.callFunction({
    name: 'userUpdate', data: { removeTag: true, userId: memberId, taskId: taskId }
  }))})})
  console.log("tags: ", tags);
  _PtasksPromise = _PtasksPromise.concat(tags);
  const events = []
  membersId.forEach(memberId => {eventsId.map(eventId => {events.push(wx.cloud.callFunction({
    name: 'userUpdate', data: { removeEvents: true, userId: memberId, eventId: eventId }
  }))})})
  console.log("events: ", events);
  _PtasksPromise = _PtasksPromise.concat(events);
  const files = []
  membersId.forEach(memberId => {unlinkfilesId.map(fileId => {files.push(wx.cloud.callFunction({
    name: 'userUpdate', data: { removeFile: true, userId: memberId, fileId: fileId }
  }))})})
  console.log("files: ", files);
  _PtasksPromise = _PtasksPromise.concat(files);
  const folders = []
  membersId.forEach(memberId => {unlinkfoldersId.map(folderId => {folders.push(wx.cloud.callFunction({
    name: 'userUpdate', data: { removeFolder: true, userId: memberId, folderId: folderId }
  }))})})
  console.log("folders: ", folders);
  _PtasksPromise = _PtasksPromise.concat(folders);
  console.log("_PtasksPromise: ", _PtasksPromise);
}

function _PupdateCompanyField(proId, tasksId, eventsId, unlinkfilesId, unlinkfoldersId, companysId, _PtasksPromise) {
  console.log("------------------------_PupdateCompanyField--------------------------------")
  const projects = companysId.map(companyId => {return wx.cloud.callFunction({
    name: 'companyUpdate', data: { removeProjects: true, companyId: companyId, proId: proId }
  })});
  console.log("projects: ", projects);
  _PtasksPromise = _PtasksPromise.concat(projects);
  const tasks = []
  companysId.forEach(companyId => {tasksId.map(taskId => {tasks.push(wx.cloud.callFunction({
    name: 'companyUpdate', data: { removeTasks: true, companyId: companyId, taskId: taskId }
  }))})})
  console.log("tasks: ", tasks);
  _PtasksPromise = _PtasksPromise.concat(tasks);
  const events = []
  companysId.forEach(companyId => {eventsId.map(eventId => {events.push(wx.cloud.callFunction({
    name: 'companyUpdate', data: { removeEvents: true, companyId: companyId, eventId: eventId }
  }))})})
  console.log("tasks: ", events);
  _PtasksPromise = _PtasksPromise.concat(events);
  const files = []
  companysId.forEach(companyId => {unlinkfilesId.map(fileId => {files.push(wx.cloud.callFunction({
    name: 'companyUpdate', data: { removeFiles: true, companyId: companyId, fileId: fileId }
  }))})})
  console.log("files: ", files);
  _PtasksPromise = _PtasksPromise.concat(files);
  const folders = []
  companysId.forEach(companyId => {unlinkfoldersId.map(folderId => {folders.push(wx.cloud.callFunction({
    name: 'companyUpdate', data: { removeFolders: true, companyId: companyId, folderId: folderId }
  }))})})
  console.log("folders: ", folders);
  _PtasksPromise = _PtasksPromise.concat(folders);
  console.log("_PtasksPromise: ", _PtasksPromise);
}

export function deletProject(proInfo, _PtasksPromise, action, _this) {
  let proId = proInfo._id; let membersId = proInfo.members; let companysId = proInfo.companys;let tasksId = proInfo.allTasksNode || [];
  let eventsId = proInfo.events || []; let foldersId = proInfo.allfolders || []; let filesId = proInfo.allfiles || [];
  let unlinkfilesId = [];let unlinkfilesPath = []; let linkfilesId = []; let unlinkfoldersId = []; let linkfoldersId = [];
  let queryFilesTask = filesId.map(item => {return fileDB.doc(item).get()});
  Promise.all(queryFilesTask).then(res => {
    let filesInfo = res.map(item => {return item.data});
    console.log("filesInfo: ", filesInfo);
    filesInfo.forEach(item => {
      let fileId = item._id;//子文件的id
      let filePath = item.fileID;//子文件的存储位置
      let filetaskNode = item.taskNode || [];//子文件的关联任务
      let islinktask = filetaskNode.length === 1 ? tasksId.indexOf(filetaskNode[0]) === -1 : true;
      console.log("islinktask: ", islinktask, tasksId.indexOf(filetaskNode[0]) === -1)
      let fileeventNode = item.eventNode || [];//子文件的关联日程
      let islinkevent = fileeventNode.length === 1 ? eventsId.indexOf(fileeventNode[0]) === -1 : true;
      let fileproNode = item.proNode;//子文件所属项目，若长度大于1，则表示该文件夹属于别的项目，从而不能删除，只能移除
      if ((filetaskNode.length === 0 || !islinktask) && (fileeventNode.length === 0 || !islinkevent)) {
        unlinkfilesId.push(fileId);//没有任何关联的文件
        unlinkfilesPath.push(filePath)
      } else {
        linkfilesId.push(fileId)//存在关联的文件
      }
    });
    console.log("unlinkfilesId: ", unlinkfilesId);
    console.log("linkfilesId: ", linkfilesId);
    let queryFoldersTask = foldersId.map(item => {return folderDB.doc(item).get()});
    Promise.all(queryFoldersTask).then(res=>{
      let foldersInfo = res.map(item => {return item.data});
      console.log("foldersInfo: ", foldersInfo);
      foldersInfo.forEach(item => {
        let folderId = item._id;//子文件的id
        let folderPath = item.fileID;//子文件的存储位置
        let foldertaskNode = item.taskNode || [];//子文件的关联任务
        let islinktask = foldertaskNode.length === 1 ? tasksId.indexOf(foldertaskNode[0]) === -1 : true;
        let foldereventNode = item.eventNode || [];//子文件的关联日程
        let islinkevent = foldereventNode.length === 1 ? eventsId.indexOf(foldereventNode[0]) === -1 : true;
        let folderproNode = item.proNode;//子文件所属项目，若长度大于1，则表示该文件夹属于别的项目，从而不能删除，只能移除
        if ((foldertaskNode.length === 0 || !islinktask) && (foldereventNode.length === 0 || !islinkevent)) {
          unlinkfoldersId.push(folderId);//没有任何关联的文件夹
        } else {
          linkfoldersId.push(folderId)//存在关联的文件夹
        }
      });
      console.log("unlinkfoldersId: ", unlinkfoldersId);
      console.log("linkfoldersId: ", linkfoldersId);
      //更新项目表；删除一条记录
      _PupdateProjectField(proId, _PtasksPromise);
      //更新任务表
      _PupdateTaskField(tasksId, _PtasksPromise);
      //更新日程表
      _PupdateEventField(eventsId, _PtasksPromise);
      _PupdateFileField(unlinkfilesId, unlinkfilesPath, linkfilesId, proId, _PtasksPromise);
      _PupdateFolderField(unlinkfoldersId, linkfoldersId, proId, _PtasksPromise);
      _PupdateUserField(null, [proId], tasksId, eventsId, unlinkfilesId, unlinkfoldersId, membersId, _PtasksPromise);
      _PupdateCompanyField(proId, tasksId, eventsId, unlinkfilesId, unlinkfoldersId, companysId, _PtasksPromise);
      Promise.all(_PtasksPromise).then(res => {
        //显示tabbar
        wx.showTabBar()
        let projectsId = _this.data.projects.filter(item => {return item != proId});
        console.log("projectsId: ", projectsId)
        util.getCompanyName2ProjectsInfo(_this.data.companys, projectsId, _this);
        if (action) {
          action[0].loading = false;
          _this.setData({
            visible2: false,
            actions2: action,
            toggle: _this.data.toggle ? false : true
          });
        }
      })
    })
  })
}

/**
 * 删除班级，remove company
 */
function _CupdateCompanyField(companyId, _CtasksPromise){
  console.log("------------------------_CupdayeCompanyField--------------------------------")
  const removeCompany = wx.cloud.callFunction({
    name: 'companyUpdate', data: { removeCompany: true, companyId: companyId }
  });
  console.log("removeCompany: ", removeCompany);
  _CtasksPromise = _CtasksPromise.concat(removeCompany);
  console.log("_CtasksPromise: ", _CtasksPromise)
}
function _CupdateProjectField(prosId, _CtasksPromise){
  console.log("------------------------_CupdateProjectField--------------------------------")
  const removeProjects = prosId.map(proId => {
    return wx.cloud.callFunction({
      name: 'projectUpdate', data: { removeProject: true, proId: proId }
    })
  })
  console.log("removeProjects: ", removeProjects);
  _CtasksPromise = _CtasksPromise.concat(removeProjects);
  console.log("_CtasksPromise: ", _CtasksPromise)
}
function _CupdateFileField(filesId, filesPath, _CtasksPromise) {
  //对于非关联文件，删除记录并删除文件
  const removeFiles = filesId.map(fileId => {
    return wx.cloud.callFunction({name: 'fileUpdate', data: { removeFile: true, fileId: fileId }})
  })
  console.log("removeFiles: ", removeFiles);
  _CtasksPromise = _CtasksPromise.concat(removeFiles);
  const deletefiles = wx.cloud.deleteFile({ fileList: filesPath});
  console.log("deletefiles: ", deletefiles);
  _CtasksPromise = _CtasksPromise.concat(deletefiles);
  console.log("_CtasksPromise: ", _CtasksPromise)
}
function _CupdateFolderField(foldersId, _CtasksPromise) {
  //对于非关联文件，删除记录并删除文件
  const removeFolders = foldersId.map(folderId => {
    return wx.cloud.callFunction({ name: 'folderUpdate', data: { removeFolder: true, folderId: folderId } })
  })
  console.log("removeFolders: ", removeFolders);
  _CtasksPromise = _CtasksPromise.concat(removeFolders);
  console.log("_CtasksPromise: ", _CtasksPromise)
}

export function deleteCompany(companyInfo, _CtasksPromise, _this) {
  let companyId = companyInfo._id; let membersId = companyInfo.members || []; let companysId = companyInfo.companys || []; 
  let prosId = companyInfo.projectsNode || []; let tasksId = companyInfo.tasks || [];
  let eventsId = companyInfo.events || []; let filesId = companyInfo.files || []; let foldersId = companyInfo.folders || [];
  let queryFilesTask = filesId.map(item => { return fileDB.doc(item).get() });
  Promise.all(queryFilesTask).then(res => {
    let filesInfo = res.map(item => { return item.data });
    let filesPath = filesInfo.map(item => {return item.fileID});
    _CupdateCompanyField(companyId, _CtasksPromise);
    //更新项目表；删除一条记录
    _CupdateProjectField(prosId, _CtasksPromise);
    //更新任务表
    _PupdateTaskField(tasksId, _CtasksPromise);
    //更新日程表
    _PupdateEventField(eventsId, _CtasksPromise);
    _CupdateFileField(filesId, filesPath, _CtasksPromise);
    _CupdateFolderField(foldersId, _CtasksPromise);
    _PupdateUserField(companyId, prosId, tasksId, eventsId, filesId, foldersId, membersId, _CtasksPromise);
    Promise.all(_CtasksPromise).then(res => {
      let companysInfo = _this.data.companysInfo.filter(item => { return item._id != companyId });
      _this.setData({ companysInfo: companysInfo, companysId: companysInfo.map(item => {return item._id})});
      if (app.globalData.currentCompany === companyId) { 
        app.globalData.currentCompany = _this.data.companysId[0];
        _this.setData({ currentCompany: app.globalData.currentCompany })
      }
      wx.hideLoading();
    })
  })
}
