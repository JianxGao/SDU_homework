/**
 * 获取access token
 * 发送请求
 * 
 */
const {Wechat} = require('./accessToken.js')
const w = new Wechat();



