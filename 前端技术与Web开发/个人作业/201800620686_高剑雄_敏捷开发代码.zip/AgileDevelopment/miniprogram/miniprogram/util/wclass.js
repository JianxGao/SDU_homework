const app = getApp()
const db = wx.cloud.database();
const userDB = db.collection('user')
const companyDB = db.collection('companys')
const projectDB = db.collection('projects')
const taskDB = db.collection('tasks')
const eventDB = db.collection('events')
const fileDB = db.collection('files');
const folderDB = db.collection('folders')
var dateTimePicker = require('./dateTimePicker.js');
var util = require('./wutils.js')
/**
 * 获取项目的任务名
 */
export function getProjectsTasksName(projectsId, _this){
  let allTasksNode = [];
  let length = 0;
  let allprojectsName = [];
  projectsId.forEach(proId => {
    projectDB.doc(proId).get().then(res => {
      allprojectsName.push(res.data.name)
      length += 1
      allTasksNode = allTasksNode.concat(res.data.allTasksNode || []);
      if (length === projectsId.length) {
        _this.setData({
          allTasksNode: allTasksNode,
          allprojectsName: allprojectsName
        });
        console.log("allTasksNode:", allTasksNode, allprojectsName)
        if (allTasksNode.length > 0) {
          let tasksName = allTasksNode.map(item => { return taskDB.doc(item).get() });
          Promise.all(tasksName).then(res => {
            let alltasksNameList = res.map(item => { return item.data.name });
            _this.setData({
              alltasksNameList: alltasksNameList
            })
            console.log("alltasksNameList: ", _this.data.alltasksNameList)
            return;
          })
        } else {
          return;
        }
      }
    })
  })
}

export function getTasksProNodeName(tasksInfo, _this) {
  let length = 0;
  tasksInfo.forEach(taskInfo => {
    let proNode = taskInfo.proNode;//所属项目
    console.log("proNode: ", proNode)
    let projectsName = proNode.map(item => {return projectDB.doc(item).get()});
    Promise.all(projectsName).then(res => {
      length += 1;
      let proNodeName = res.map(item => { return item.data.name});
      taskInfo.projectsName = '#' + proNodeName.join(',#');
      console.log(length);
      if (length === tasksInfo.length) {
        console.log("tasksInfo: ", tasksInfo);
        // _this.setData({ tasksInfo: tasksInfo });
        // formatTasksInfo(tasksInfo, _this)
        getTasksParentTaskName(tasksInfo, _this);
      }
    })
  })
}

export function getTasksParentTaskName(tasksInfo, _this) {
  let length = 0;
  tasksInfo.forEach(taskInfo => {
    let parentTaskNode = taskInfo.taskNode ? taskInfo.taskNode : null;//所属项目
    // console.log("parentTaskNode: ", parentTaskNode)
    let parentTask = parentTaskNode ? taskDB.doc(parentTaskNode).get() : null;
    Promise.all([parentTask]).then(res => {
      length += 1;
      let parentTaskName = res[0] ? res[0].data.name : null;
      taskInfo.parentTaskName = parentTaskName;
      // console.log(length);
      if (length === tasksInfo.length) {
        // console.log("parentTaskName: ", parentTaskName, taskInfo);
        _this.setData({ tasksInfo: tasksInfo });
        formatTasksInfo(tasksInfo, _this);
        wx.hideLoading()
      }
    });
  })
}

export function formatTasksInfo(allTasksInfo, _this) {
  let executeTaskInfo = allTasksInfo.filter(item => { return item.executor === app.globalData.openid });
  let followerTaskInfo = allTasksInfo.filter(item => { return item.members.indexOf(app.globalData.openid) != -1 });
  let createTaskInfo = allTasksInfo.filter(item => { return item.creator === app.globalData.openid });
  _this.setData({
    executeTaskInfo: executeTaskInfo,
    followerTaskInfo: followerTaskInfo,
    createTaskInfo: createTaskInfo
  })
}

export function updateStatus(allTaskInfo, taskId, _this) {
  let status;
  allTaskInfo
    .filter(item => { return item._id === taskId })
    .map(item => {
      console.log(item);
      item.finished = !item.finished;
      console.log(item)
      status = item.finished
      return item
    });
  console.log("status:", status, allTaskInfo);

  wx.cloud.callFunction({
    name: 'taskUpdate',
    data: {
      updateFinished: true,
      taskId: taskId,
      finished: status
    }
  }).then(res => {
    formatTasksInfo(allTaskInfo, _this)
  })
}

/**
 * 日程
 */
export function getProjectsEventsName(projectsId, _this) {
  let allEventsNode = [];
  let length = 0;
  let allprojectsName = [];
  projectsId.forEach(proId => {
    projectDB.doc(proId).get().then(res => {
      allprojectsName.push(res.data.name);
      length += 1
      allEventsNode = allEventsNode.concat(res.data.events || []);
      if (length === projectsId.length) {
        _this.setData({
          allEventsNode: allEventsNode,
          allprojectsName: allprojectsName
        });
        console.log("allEventsNode:", allEventsNode, allprojectsName)
        if (allEventsNode.length > 0) {
          let eventsName = allEventsNode.map(item => { return eventDB.doc(item).get() });
          Promise.all(eventsName).then(res => {
            let alleventsNameList = res.map(item => { return item.data.name });
            _this.setData({
              alleventsNameList: alleventsNameList
            })
            console.log("alleventsNameList: ", _this.data.alleventsNameList)
            return;
          })
        } else {
          return;
        }
      }
    })
  })
}

