module.exports = {
  _class: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/class.png',
  project: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/project.png',
  task: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/task.png',
  note: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/note.png',
  file: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/file.png',
  event: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/event.png',
  linkman: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/linkman.png',
  mine: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/mine.png',
  add: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/add.png',
  wechatLogo: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/WeChatIcon.png',
  userLogin: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/userLogin.png',
  setting: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/setting.png',
  none: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/none.png',
  confirm: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/pro-finished.png',
  confirm98: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/pro-finish.png',
  circle: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/circle.png',
  checkBox: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/check_box.png',
  checkedBox: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/checkboxlist.png',
  down: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/down.png',
  list: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/list98.png',
  members: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/Members.png',
  close: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/guanbi.png',
  close03a9f4: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/close.png',
  isAdd: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/isAdd.png',
  ellipsis :'cloud://homework-84qwq.686f-homework-84qwq-1301103607/ellipsis.png',
  link: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/link.png',
  trash: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/trash.png',
  // tab选项卡 #989898 / #03a9f4
  homeSelected: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/home-selected.png',
  home: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/home.png',
  eventTab: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/event-tab.png',
  eventSelected: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/event-selected.png',
  taskTab: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/task-tab.png',
  taskSelected: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/task-selected.png',
  notificationTab: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/notification-tab.png',
  notidicationSelected: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/notification-selected.png',
  userSelected: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/user-selected.png',
  userTab: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/user-tab.png',
  tagTab: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/tag-tab.png',
  tagSelected: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/tag-selected.png',
  group: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/group.png',
  projects: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/projects.png',
  projectsSelected: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/projects-selected.png',
  add03a9f4: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/add03a9f4.png',
  arrow: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/goto-r.png',
  search: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/search.png',
  star: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/star.png',
  starSelected: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/star-selected.png',
  attach: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/attach.png',
  folder: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/folder03.png',
  _delete: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/delete-btn.png',
  dashline: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/dashline.png'
}
// homework - 84qwq.686f - homework - 84qwq - 1301103607
// dashline: 'cloud://homework-84qwq.686f-homework-84qwq-1301103607/dashline.png'






