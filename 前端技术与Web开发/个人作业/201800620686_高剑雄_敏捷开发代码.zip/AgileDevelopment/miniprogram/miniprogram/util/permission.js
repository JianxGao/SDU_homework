/**
 * 添加权限
 */
function updateCompanyPermission(companyId, userId, tasksPromise){
  console.log("--------------------------------updateCompanyPermission--------------------------------")
  const addPermission = wx.cloud.callFunction({
    name: 'companyUpdate', data: { addPermission: true, companyId: companyId, userId: userId }
  })
  console.log("addPermission: ", addPermission);
  tasksPromise = tasksPromise.concat(addPermission)
  const deletePermission = wx.cloud.callFunction({
    name: 'companyUpdate', data: { deletePermission: true, companyId: companyId, userId: userId}
  })
  console.log("deletePermission: ", deletePermission); tasksPromise = tasksPromise.concat(deletePermission);
  const modifyPermission = wx.cloud.callFunction({
    name: 'companyUpdate', data: { modifyPermission: true, companyId: companyId, userId: userId }
  })
  console.log("modifyPermission: ", modifyPermission);
  tasksPromise = tasksPromise.concat(modifyPermission);
  console.log("tasksPromise: ", tasksPromise);
}

function updateProjectsPermission(projectsId, userId, tasksPromise) {
  console.log("--------------------------------updateProjectsPermission--------------------------------")
  const addPermission = projectsId.map(proId => {return wx.cloud.callFunction({
    name: 'projectUpdate', data: { addPermission: true, proId: proId, userId: userId }
  })})
  console.log("addPermission: ", addPermission);
  tasksPromise = tasksPromise.concat(addPermission)
  const deletePermission = projectsId.map(proId => {return wx.cloud.callFunction({
    name: 'projectUpdate', data: { deletePermission: true, proId: proId, userId: userId }
  })})
  console.log("deletePermission: ", deletePermission); tasksPromise = tasksPromise.concat(deletePermission);
  const modifyPermission = projectsId.map(proId => {return wx.cloud.callFunction({
    name: 'projectUpdate', data: { modifyPermission: true, proId: proId, userId: userId }
  })})
  console.log("modifyPermission: ", modifyPermission);
  tasksPromise = tasksPromise.concat(modifyPermission);
  console.log("tasksPromise: ", tasksPromise);
}

function updateTasksPermission(tasksId, userId, tasksPromise) {
  console.log("--------------------------------updateTasksPermission--------------------------------")
  const addPermission = tasksId.map(taskId => {return wx.cloud.callFunction({
    name: 'taskUpdate', data: { addPermission: true, taskId: taskId, userId: userId }
  })})
  console.log("addPermission: ", addPermission);
  tasksPromise = tasksPromise.concat(addPermission)
  const deletePermission = tasksId.map(taskId => {return wx.cloud.callFunction({
    name: 'taskUpdate', data: { deletePermission: true, taskId: taskId, userId: userId }
  })})
  console.log("deletePermission: ", deletePermission);
  tasksPromise = tasksPromise.concat(deletePermission);
  const modifyPermission = tasksId.map(taskId => {return wx.cloud.callFunction({
    name: 'taskUpdate', data: { modifyPermission: true, taskId: taskId, userId: userId }
  })})
  console.log("modifyPermission: ", modifyPermission);
  tasksPromise = tasksPromise.concat(modifyPermission);
  console.log("tasksPromise: ", tasksPromise);
}

function updateEventsPermission(eventsId, userId, tasksPromise) {
  console.log("--------------------------------updateEventsPermission--------------------------------")
  const addPermission = eventsId.map(eventId => {return wx.cloud.callFunction({
    name: 'eventUpdate', data: { addPermission: true, eventId: eventId, userId: userId }
  })})
  console.log("addPermission: ", addPermission);
  tasksPromise = tasksPromise.concat(addPermission)
  const deletePermission = eventsId.map(eventId => {return wx.cloud.callFunction({
    name: 'eventUpdate', data: { deletePermission: true, eventId: eventId, userId: userId }
  })})
  console.log("deletePermission: ", deletePermission);
  tasksPromise = tasksPromise.concat(deletePermission);
  const modifyPermission = eventsId.map(eventId => {return wx.cloud.callFunction({
    name: 'eventUpdate', data: { modifyPermission: true, eventId: eventId, userId: userId }
  })})
  console.log("modifyPermission: ", modifyPermission);
  tasksPromise = tasksPromise.concat(modifyPermission);
  console.log("tasksPromise: ", tasksPromise);
}

export function addCompanyAdministrator(companyInfo, userId, tasksPromise) {
  let companyId = companyInfo._id;
  let projectsId = companyInfo.projectsNode || [];
  let tasksId = companyInfo.tasks || [];
  let eventsId = companyInfo.events || [];
  updateCompanyPermission(companyId, userId, tasksPromise);
  updateProjectsPermission(projectsId, userId, tasksPromise);
  updateTasksPermission(tasksId, userId, tasksPromise);
  updateEventsPermission(eventsId, userId, tasksPromise);
}

export function addProjectAddministrator(projectInfo, userId, tasksPromise) {
  let projectId = projectInfo._id;
  let tasksId = projectInfo.tasks || [];
  let eventsId = projectInfo.events || [];
  updateProjectsPermission([projectId], userId, tasksPromise);
  updateTasksPermission(tasksId, userId, tasksPromise);
  updateEventsPermission(eventsId, userId, tasksPromise);
}

/**
 * 删除权限
 */
function removeCompanyPermission(companyId, userId, tasksPromise) {
  console.log("--------------------------------removeCompanyPermission--------------------------------")
  const removeAddPermission = wx.cloud.callFunction({
    name: 'companyUpdate', data: { removeAddPermission: true, companyId: companyId, userId: userId }
  })
  console.log("removeAddPermission: ", removeAddPermission);
  tasksPromise = tasksPromise.concat(removeAddPermission)
  const removeDeletePermission = wx.cloud.callFunction({
    name: 'companyUpdate', data: { removeDeletePermission: true, companyId: companyId, userId: userId }
  })
  console.log("removeDeletePermission: ", removeDeletePermission); 
  tasksPromise = tasksPromise.concat(removeDeletePermission);
  const removeModifyPermission = wx.cloud.callFunction({
    name: 'companyUpdate', data: { removeModifyPermission: true, companyId: companyId, userId: userId }
  })
  console.log("removeModifyPermission: ", removeModifyPermission);
  tasksPromise = tasksPromise.concat(removeModifyPermission);
  console.log("tasksPromise: ", tasksPromise);
}
function removeProjectPermission(projectsId, userId, tasksPromise) {
  console.log("--------------------------------removeCompanyPermission--------------------------------")
  const removeAddPermission = projectsId.map(proId => {return wx.cloud.callFunction({
    name: 'projectUpdate', data: { removeAddPermission: true, proId: proId, userId: userId }
  })})
  console.log("removeAddPermission: ", removeAddPermission);
  tasksPromise = tasksPromise.concat(removeAddPermission)
  const removeDeletePermission = projectsId.map(proId => {return wx.cloud.callFunction({
    name: 'projectUpdate', data: { removeDeletePermission: true, proId: proId, userId: userId }
  })})
  console.log("removeDeletePermission: ", removeDeletePermission); 
  tasksPromise = tasksPromise.concat(removeDeletePermission);
  const removeModifyPermission = projectsId.map(proId => {return wx.cloud.callFunction({
    name: 'projectUpdate', data: { removeModifyPermission: true, proId: proId, userId: userId }
  })})
  console.log("removeModifyPermission: ", removeModifyPermission);
  tasksPromise = tasksPromise.concat(removeModifyPermission);
  console.log("tasksPromise: ", tasksPromise);
}
function removeTasksPermission(tasksId, userId, tasksPromise) {
  console.log("--------------------------------removeTasksPermission--------------------------------")
  const removeAddPermission = tasksId.map(taskId => {return wx.cloud.callFunction({
    name: 'taskUpdate', data: { removeAddPermission: true, taskId: taskId, userId: userId }
  })})
  console.log("removeAddPermission: ", removeAddPermission);
  tasksPromise = tasksPromise.concat(removeAddPermission)
  const removeDeletePermission = tasksId.map(taskId => {return wx.cloud.callFunction({
    name: 'taskUpdate', data: { removeDeletePermission: true, taskId: taskId, userId: userId }
  })})
  console.log("removeDeletePermission: ", removeDeletePermission);
  tasksPromise = tasksPromise.concat(removeDeletePermission);
  const removeModifyPermission = tasksId.map(taskId => {return wx.cloud.callFunction({
    name: 'taskUpdate', data: { removeModifyPermission: true, taskId: taskId, userId: userId }
  })})
  console.log("removeModifyPermission: ", removeModifyPermission);
  tasksPromise = tasksPromise.concat(removeModifyPermission);
  console.log("tasksPromise: ", tasksPromise);
}
function removeEventsPermission(eventsId, userId, tasksPromise) {
  console.log("--------------------------------removeTasksPermission--------------------------------")
  const removeAddPermission = eventsId.map(eventId => {return wx.cloud.callFunction({
    name: 'eventUpdate', data: { removeAddPermission: true, eventId: eventId, userId: userId }
  })})
  console.log("removeAddPermission: ", removeAddPermission);
  tasksPromise = tasksPromise.concat(removeAddPermission)
  const removeDeletePermission = eventsId.map(eventId => {return wx.cloud.callFunction({
    name: 'eventUpdate', data: { removeDeletePermission: true, eventId: eventId, userId: userId }
  })})
  console.log("removeDeletePermission: ", removeDeletePermission);
  tasksPromise = tasksPromise.concat(removeDeletePermission);
  const removeModifyPermission = eventsId.map(eventId => {return wx.cloud.callFunction({
    name: 'eventUpdate', data: { removeModifyPermission: true, eventId: eventId, userId: userId }
  })})
  console.log("removeModifyPermission: ", removeModifyPermission);
  tasksPromise = tasksPromise.concat(removeModifyPermission);
  console.log("tasksPromise: ", tasksPromise);
}

export function removeCompanyAdministrator(companyInfo, userId, tasksPromise) {
  let companyId = companyInfo._id;
  let projectsId = companyInfo.projectsNode || [];
  let tasksId = companyInfo.tasks || [];
  let eventsId = companyInfo.events || [];
  removeCompanyPermission(companyId, userId, tasksPromise);
  removeProjectPermission(projectsId, userId, tasksPromise);
  removeTasksPermission(tasksId, userId, tasksPromise);
  removeEventsPermission(eventsId, userId, tasksPromise);
}

export function removeProjectAddministrator(projectInfo, userId, tasksPromise) {
  let projectId = projectInfo._id;
  let tasksId = projectInfo.allTasksNode || [];
  let eventsId = projectInfo.events || [];
  removeProjectPermission([projectId], userId, tasksPromise);
  removeTasksPermission(tasksId, userId, tasksPromise);
  removeEventsPermission(eventsId, userId, tasksPromise);
}