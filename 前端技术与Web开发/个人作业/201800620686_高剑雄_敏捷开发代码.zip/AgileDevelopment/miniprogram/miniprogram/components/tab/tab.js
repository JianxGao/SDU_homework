// components/tab/tab.js
Component({
  // 接受外部的类 
  externalClasses: ['tabs-active-text-class', 'tabs-width', 'tabs-external', 'tabs-item-external', 'tabs-item-active-external', 'active-font-color'],
  /**
   * Component properties
   */
  properties: {
    tabs: {
      type: Array,
      value: []
    }
  },

  /**
   * Component initial data
   */
  data: {
    currentIndex: 0
  },

  /**
   * Component methods
   */
  methods: {
    itemclick: function(e) {
      console.log(e);
      let index = e.currentTarget.dataset.index;
      this.setData({
        currentIndex: index,
      })
      const myEventDetail = {index: index};
      const myEventOption = {};
      this.triggerEvent('tabclick', myEventDetail, myEventOption)
    }
  }
})
