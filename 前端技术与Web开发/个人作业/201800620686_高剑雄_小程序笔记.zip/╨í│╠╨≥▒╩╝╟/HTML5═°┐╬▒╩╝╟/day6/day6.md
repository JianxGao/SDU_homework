## **表单**

### **input跳警告**

- 解决方法：
  - 加上id，并与label绑定
  -  加上title

### **input的常用属性**

- maxlength：允许输入的最大字数
- placeholder：占位文字（没有输入时，显示的值）

```html
<div>
        <label for="phone">手机：</label>
        <input id="phone"
               type="text"
               name="phone"
               maxlength="11"
               placeholder="请输入手机号码">
</div>
```

- name：名字（服务器规定的）

  - 在提交数据给服务器时，可用于区分数据类型

  - **没有name无法提交数据**

- value：取值(服务器规定的)

- form：设置所属的form元素（填写form元素的id）
  一旦使用了此属性，input元素即使不写在form元素内部，它的数据也能够提交给服务器

### **布尔属性（boolean attributes）**

- 布尔属性可以没有属性值，写上属性名就代表使用这个属性
- 常见的布尔属性有**disabled、checked、readonly、multiple、autofocus、selected**
- 如果要给布尔属性设值，值就是属性名本身

- readonly：只读

```html
<div>
        <label for="phone">手机：</label>
        <input id="phone"
               type="text"
               name="phone"
               maxlength="11"
               placeholder="请输入手机号码" 
               readonly="readonly">
</div>
```

- disabled：禁用

```html
<div>
        <label for="phone">手机：</label>
        <input id="phone"
               type="text"
               name="phone"
               maxlength="11"
               placeholder="请输入手机号码" 
               disabled="disabled">
</div>
```

<img src="1.png">

- checked：默认被选中
  - 只有当type为**radio或checkbox**时可用
- autofocus：当页面加载时，自动聚焦（加到第一个输入文本的input）

```html
<div>
        <label for="phone">手机：</label>
        <input id="phone"
               type="text"
               name="phone"
               maxlength="11"
               placeholder="请输入手机号码"
               autofocus>
</div>
```

### **按钮**

- 普通按钮（type=button）
  - 使用value属性设置按钮文字

- 重置按钮（type=reset）
  - 重置它所属form的所有表单元素（包括input、textarea、select）

- 提交按钮（type=submit）
  - 提交它所属form的表单数据给服务器（包括input、textarea、select）

- 默认情况下，敲回车键（Enter）会自动提交表单数据给服务器
  - 如需禁止此行为，需要编写相应的JavaScript代码

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>按钮2</title>
</head>
<body>
<form action="http://www.baidu.com">

    <input type="text" name="phone">
    <button type="button">获取验证码</button>
    <button type="reset">重置</button>
    <button type="submit">提交</button>
</form>
</body>
</html>
```

