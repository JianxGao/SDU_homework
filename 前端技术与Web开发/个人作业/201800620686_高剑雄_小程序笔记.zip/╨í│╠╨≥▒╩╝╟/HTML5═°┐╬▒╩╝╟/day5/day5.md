## CSS特性

### CSS属性的继承

- 一个属性如果没有设置某属性的值，就会跟随**父元素**的值

- **color、font-size**等属性是可以继承的
- 有些属性是不可继承的，可以查官方文档。

- 举例

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>1</title>
    <style>
        div {
            color: #0f0;
            width: 100px;
            height: 100px;
            background-color: blue;
        }

        p {
            background-color: red;
        }
    </style>
</head>
<body>
<div>
    <p>我是p</p>
</div>
</body>
</html>
```

<img src="img/2.png">

- **width,  height,  background-color**都是**不可inherited**的

- 不能继承的属性，一般可以使用**inherit**值强制继承    

  ```html
  <!DOCTYPE html>
  <html lang="zh">
  <head>
      <meta charset="UTF-8">
      <title>1</title>
      <style>
          div {
              color: #0f0;
              width: 100px;
              height: 100px;
              background-color: blue;
              border: 2px solid #ff0;
          }
  
          p {
              background-color: red;
              /*强制继承父元素的border属性*/
              border: inherit;
          }
      </style>
  </head>
  <body>
  <div>
      <p>我是p</p>
  </div>
  </body>
  </html>
  ```

  <img src="img/3.png">

- 浏览器的开发者工具也会标识出哪些样式是继承过来的

<img src="img/1.png" alt="1">

### **继承的注意点**

- CSS属性继承的是**计算值**，并不是当初编写属性时的指定值

- 举例

  ```html
  <!DOCTYPE html>
  <html lang="zh">
  <head>
      <meta charset="UTF-8">
      <title>CSS属性的继承</title>
      <style>
          .div1{
              font-size: 50px;
          }
          .div2{
              /* 字面值-指定值，即50% */
              /* 计算值，即50px * 50% = 25px */
              font-size: 50%;
          }
          .div3{
              font-size: inherit;
          }
      </style>
  </head>
  <body>
  <div class="div1">div1
      <div class="div2">div2
          <div class="div3">div3</div>
      </div>
  </div>
  </body>
  </html>
  ```

<img src="img/4.png">

### CSS属性的层叠

- CSS允许多个相同名字的CSS层叠在同一个元素上
  - 层叠后的结果是：只有一个CSS属性会生效

  <img src="img/5.png" width=400px>

- 浏览器的开发者工具非常清晰地显示了哪个CSS属性会生效

<img src="img/6.png" width=200px>

- 哪个CSS会生效，取决于CSS属性所处环境的优先级高低

### **CSS属性的优先级** 

- 为方便比较CSS属性的优先级，可以给CSS属性所处的环境定义一个权值（权重）
  - <font color=orange size=3>**!important（只针对某一属性）**</font>：10000
  - **<font color=orange size=3>内联样式</font>**：1000
  - **<font color=orange size=3>id选择器</font>**：100
  - **<font color=orange size=3>类选择器、属性选择器、伪类</font>**：10
  - **<font color=orange size=3>元素选择器、伪元素</font>**：1
  - **<font color=orange size=3>通配符</font>**：0
- 针对性越强的选择器，优先级越高
  - !important>内联样式id>class、属性、伪类>标签(元素)、伪元素>通配符(*)
- 如果优先级相同，采取就近原则

- 举例

```css
#box{
    color: #f00;
}

.title{
    color: #0f0;
    font-size: 20px;
}

*{
    color: #ff0;
}

div{
    color: #00f !important;
    font-size: 50px;
}
```

<img src="img/7.png">

- 比较优先级的严谨方法

  - 从权值最大的开始比较每一种权值的数量多少，数量多的则优先级高，即可结束比较

  - 如果数量相同，比较下一个较小的权值，以此类推

  - 如果所有权值比较完毕后，发现数量都相同，就采取“就近原则”

- 总结：选择器的针对性越强，优先级越高

### **小细节**

- 以下2个选择器效果一致

<img src="img/8.png" width=250><img src="img/9.png" width=250>

- <font color= darkblue>#test</font>和<font color= darkblue>[id</font>=<font color= green>"test"</font><font color= darkblue>]</font>看起来好像一样，其本质不同
  - <font color= darkblue>#test</font>优先级比[<font color= darkblue>id</font>=<font color= green>"test"</font>]高

- 浏览器会给一些元素设定默认样式

- `<p>`不能嵌套`<div>`。`<div>`可以嵌套`<p>`

```html
<p>我是p
<div>我是div</div>
</p>
上述代码会自动生成一下代码
<p>我是p</p>
<div>我是div</div>
<p></p>
```

### **CSS属性使用经验**

- 选择器的优先级太低
- 选择没选中对应的元素

- CSS属性的使用形式不对
  - 元素不支持此CSS属性，比如span默认不支持width和height
  - 浏览器不支持此CSS属性，比如旧版本的浏览器不支持CSS3的某些属性
  - 被同类型的CSS属性覆盖，比如font覆盖font-size

- 建议
  - 充分利用浏览器的开发者工具进行调试（增加、修改样式）、查错

## **列表**

- HTML提供了3组常用的用来展示列表的元素
  - 有序列表：ol、li

  - 无序列表：ul、li
  - 定义列表：dl、dt、dd

### **有序列表-ol、li**

- ol（ordered list）
  有序列表，直接子元素<font color=orange size=3>**只能**</font>是li
  
- li（list item）
  列表中的每一项
  
  ```html
  <ol>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
  </ol>
  ```
  
  <img src="img/10.png">

### **无序列表-ul、li**

- ul（unordered list）
  无序列表，直接子元素<font color=orange size=3>**只能**</font>是li

- li（list item）
  列表中的每一项
  
  ```html
  <ul>
      <li>1</li>
      <li>2</li>
      <li>3</li>
      <li>4</li>
      <li>5</li>
  </ul>
  ```
  
  <img src="img/11.png">

> <font color=blue size=3>如果列表里面有列表，实现方法是：li里面嵌套新的ul</font>

```html
<ul>
    <li>1
        <ol>
            <li>1</li>
            <li>2</li>
            <li>3</li>
            <li>4</li>
            <li>5</li>
        </ol>
    </li>
    <li>2</li>
    <li>3</li>
    <li>4</li>
    <li>5</li>
</ul>
```

练习

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>list</title>
    <style>
        ul {
            list-style-type: none;
        }

        /*li {*/
        /*    !*去除li前面的项目符号*!*/（两次注释）
        /*    list-style-type: none;*/
        /*}*/

        .list .item .tag {
            color: #fff;
            background-color: #999;
            padding-left: 5px;
            padding-right: 5px;
        }
        
        .list .item .tag.main {
            background-color: #D60000;
        }

        .list .item {
            margin-bottom: 5px;
        }

        .list .item a {
            text-decoration: none;
            color: #3b5998;
        }

        .list .item a:hover {
            text-decoration: underline;
            color: #d10301;
        }
    </style>
</head>
<body>
<ul class="list">
    <li class="item">
        <span class="tag main">1</span>
        <a href="#">针尖对麦芒 WEY VV7s与马自达CX-5</a>
    </li>
    <li class="item">
        <span class="tag main">2</span>
        <a href="#">针尖对麦芒 WEY VV7s与马自达CX-5</a>
    </li>
    <li class="item">
        <span class="tag main">3</span>
        <a href="#">针尖对麦芒 WEY VV7s与马自达CX-5</a>
    </li>
    <li class="item">
        <span class="tag">4</span>
        <a href="#">针尖对麦芒 WEY VV7s与马自达CX-5</a>
    </li>
    <li class="item">
        <span class="tag">5</span>
        <a href="#">针尖对麦芒 WEY VV7s与马自达CX-5</a>
    </li>
</ul>
</body>
</html>
```

<img src="img/12.png">

### **定义列表：dl、dt、dd**

- dl（definition list）
  - 定义列表，直接子元素只能是dt、dd

- dt（definition term）
  - 列表中每一项的项目名

- dd（definition description）
  - 列表中每一项的具体描述，是对 dt 的描述、解释、补充
  - 一个dt后面一般紧跟着1个或者多个dd

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>dl、dt、dd</title>
</head>
<body>
<dl>
    <dt>项目名称1</dt>
    <dd>项目描述11</dd>
    <dd>项目描述12</dd>
    <dd>项目描述13</dd>
    <dd>项目描述14</dd>
    <dt>项目名称2</dt>
    <dd>项目描述21</dd>
    <dd>项目描述22</dd>
    <dd>项目描述23</dd>
    <dd>项目描述24</dd>
</dl>
</body>
</html>
```

<img src="img/13.png">

- dt、dd常见的组合
  - 事物的名称、事物的描述
  - 问题、答案
  - 类别名、归属于这类的各种事物

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>dl、dt、dd</title>
    <style>
        dd {
            margin: 0px;
        }
        a {
            text-decoration: none;
            font-size: 13px;
        }
    </style>
</head>
<body>

<dl>
    <dt>支付方式</dt>
    <dd><a href="#">货到付款</a></dd>
    <dd><a href="#">货到付款</a></dd>
    <dd><a href="#">货到付款</a></dd>
    <dd><a href="#">货到付款</a></dd>
    <dd><a href="#">货到付款</a></dd>
</dl>
</body>
</html>
```

<img src="img/14.png">

### **列表相关的CSS属性**

- 列表相关的常见CSS属性有4个：

  > list-style-type、list-style-image、list-style-position、list-style

- 适用于display设置为list-item的元素，比如<font color=blue size=3>li元素</font>

- 它们都可以继承，所以设置给<font color=blue size=3>ol、ul元素</font>，默认也会应用到<font color=blue size=3>li元素</font>
  

  
- <font color=orange size=3>list-style-type</font>：设置li元素前面标记的样式

- disc（实心圆）、circle（空心圆）、square（实心方块）

- decimal（阿拉伯数字）、lower-roman（小写罗马数字）、upper-roman（大写罗马数字）

- lower-alpha（小写英文字母）、upper-alpha（大写英文字母）

- none（什么也没有）

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>list'css</title>
    <style>
        li {
            list-style-type: circle;
        }
    </style>
</head>
<body>
<ul>
    <li>li1</li>
    <li>li2</li>
    <li>li3</li>
    <li>li4</li>
    <li>li5</li>
</ul>
</body>
</html>
```



<img src="img/15.png">

```css
<style>
        li {
            list-style-type: decimal;
        }
</style>
```

​	<img src="img/16.png">

- <font color=orange size=3>list-style-image</font>：设置某张图片为li元素前面的标记，会覆盖list-style-type的设置

  - 图片优先级比type**<font color=red size=3>高</font>**

  - ```css
    <style>    
        li {        
            list-style-image: url("");    
        }
    </style>
    ```

- <font color=orange size=3>list-style-position</font>：设置li元素前面标记的位置，可以取outside、inside2个值
  
- **很少用**
  
- **<font color=orange size=3>list-style</font>：是list-style-type、list-style-image、list-style-position的缩写属性**
  
  - <font color=blue size=3>list-style</font>: outside url("images/dot.png");
- 一般最常用的还是设置为none，去掉li元素前面的默认标记 <font color=blue size=3>list-style</font>: none;

## **表格**

### **table、tr、td**

- table：表格
- tr：表格中的行
- td：行中的单元格

### **table的常用属性**

| border      | 边框的宽度                            |
| ----------- | ------------------------------------- |
| cellpadding | 单元格内部的间距                      |
| cellspacing | 单元格之间的间距                      |
| width       | 表格的宽度                            |
| align       | 表格的水平对齐方式left、center、right |

### **tr的常用属性**

| valign | 单元格的垂直对齐方式top、middle、bottom、baseline |
| ------ | ------------------------------------------------- |
| align  | 单元格的水平对齐方式left、center、right           |

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>table</title>
</head>
<body>
<table border="1" cellpadding="10" cellspacing="0" width="500" align="center">
    <tr align="center" valign="middle">
        <td>放映时间</td>
        <td>语言版本</td>
        <td width="70">放映厅</td>
        <td>售价（元）</td>
        <td>选座购票</td>
    </tr>
    <tr align="center">
        <td>13:15</td>
        <td>国语3D</td>
        <td>2号厅</td>
        <td>￥48</td>
        <td><input type="button" value="选座购票"></td>
    </tr>
    <tr align="center">

        <td>13:15</td>
        <td>国语3D</td>
        <td>2号厅</td>
        <td>￥48</td>
        <td><input type="button" value="选座购票"></td>
    </tr>
    <tr align="center">
        <td>13:15</td>
        <td>国语3D</td>
        <td>2号厅</td>
        <td>￥48</td>
        <td><input type="button" value="选座购票"></td>
    </tr>
    <tr align="center">
        <td>13:15</td>
        <td>国语3D</td>
        <td>2号厅</td>
        <td>￥48</td>
        <td><input type="button" value="选座购票"></td>
    </tr>
</table>
</body>
</html>
```

<img src="img/17.png">



### **细线表格的实现**

- 方法1
  - 表格的border为0（或不设置border）
  - 分别设置表格、单元格的背景色
    - 表格的**背景色**决定了**表格线的颜色**
  - 设置cellspacing的值
    - 决定了表格线的粗细


```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>table</title>
    <style>
        td {
            background-color: #fff;
        }
        table {
            background-color: #000;
        }
    </style>
</head>
<body>
<table  cellpadding="10" cellspacing="1" width="500" align="center">
    <tr align="center" valign="middle">
        <td>放映时间</td>
        <td>语言版本</td>
        <td width="70">放映厅</td>
        <td>售价（元）</td>
        <td>选座购票</td>
    </tr>
    <tr align="center">
        <td>13:15</td>
        <td>国语3D</td>
        <td>2号厅</td>
        <td>￥48</td>
        <td><input type="button" value="选座购票"></td>
    </tr>
    <tr align="center">
        <td>13:15</td>
        <td>国语3D</td>
        <td>2号厅</td>
        <td>￥48</td>
        <td><input type="button" value="选座购票"></td>
    </tr>
    <tr align="center">
        <td>13:15</td>
        <td>国语3D</td>
        <td>2号厅</td>
        <td>￥48</td>
        <td><input type="button" value="选座购票"></td>
    </tr>
    <tr align="center">
        <td>13:15</td>
        <td>国语3D</td>
        <td>2号厅</td>
        <td>￥48</td>
        <td><input type="button" value="选座购票"></td>
    </tr>
</table>
</body>
</html>
```

<img src="img/18.png">

- 方法2
  - table { border-collapse: collapse; }
  - 合并单元格的边框

```css
<style>    
    td {        
        /* 设置每一个单元格的边框 */        
        border: 1px solid #000;    
    }    
    table {        
        /* 合并单元格的边框 */        
        border-collapse: collapse;    
    }
</style>
```

<img src="img/19.png">

### **其他元素**

- tbody：表格的主体

- caption：表格的标题

- thead：表格的表头

- tfoot：表格的页脚

- th：表格的表头单元格

- 练习：

  ```html
  <!DOCTYPE html>
  <html lang="zh">
  <head>
      <meta charset="UTF-8">
      <title>table</title>
      <style>
          .movie-list {
              /* 设置单元格之间的间距 */
              border-spacing: 0;
          }
  
          .movie-list caption {
              font-weight: 700;
              font-size: 20px;
              margin-bottom: 10px;
          }
  
          .movie-list .title {
              font-weight: 600;
          }
  
          .movie-list td {
              width: 100px;
              height: 50px;
              /*border: 1px solid #000;*/
              text-align: center;
          }
  
          .movie-list .price {
              color: #f00;
          }
  
          /*.movie-list tr:not(.title) td:nth-of-type(4){*/
          /*    color: #f00;*/
          /*}*/
  
          /* 偶数行背景色 */
          .movie-list tr:nth-of-type(even) {
              background-color: #fff;    
          }
  
          /* 奇数行背景色 */
          .movie-list tr:nth-of-type(odd) {
              background-color: #f1f1f1;
          }
          .movie-list .buy_tn {
              background-color: #f00;
              color: #fff;
              border: none;
              border-radius: 10px;
              /* 去除聚焦时外轮廓 */
              outline: none;
              padding-top: 3px;
              padding-bottom: 3px;
          }
  
          .movie-list .buy_tn:hover {
              cursor: pointer;
          }
      </style>
  </head>
  <body>
  
  <table align="center" class="movie-list">
      <!-- 表格的标题 -->
      <caption>欢迎光临万达影城</caption>
      <tr class="title">
          <!-- th会自动加粗 -->
          <td>放映时间</td>
          <td>语言版本</td>
          <td>放映厅</td>
          <td>售价（元）</td>
          <td>选座购票</td>
      </tr>
      <tr>
          <td>13:15</td>
          <td>国语3D</td>
          <td>2号厅</td>
          <td class="price">￥48</td>
          <td><input type="button" value="选座购票" class="buy_tn"></td>
      </tr>
      <tr>
          <td>13:15</td>
          <td>国语3D</td>
          <td>2号厅</td>
          <td class="price">￥48</td>
          <td><input type="button" value="选座购票" class="buy_tn"></td>
      </tr>
      <tr>
          <td>13:15</td>
          <td>国语3D</td>
          <td>2号厅</td>
          <td class="price">￥48</td>
          <td><input type="button" value="选座购票" class="buy_tn"></td>
      </tr>
      <tr>
          <td>13:15</td>
          <td>国语3D</td>
          <td>2号厅</td>
          <td class="price">￥48</td>
          <td><input type="button" value="选座购票" class="buy_tn"></td>
      </tr>
  
  </table>
  </body>
  </html>
  ```

  <img src="img/20.png">

### **单元格合并**

- rowspan：单元格可横跨的行数

- colspan：单元格可横跨的列数
- **向右向下拓展**

```html
<td colspan="2" rowspan="2">td01</td>
```

- 因此上html中删除三个被覆盖掉元素即可

  ```html
  <!DOCTYPE html>
  <html lang="zh">
  <head>
      <meta charset="UTF-8">
      <title>课程表</title>
      <style>
          td {
              border: 1px solid #000;
              text-align: center;
          }
  
          td[colspan],[rowspan], .date {
              font-weight: 700;
          }
  
          table {
              border-collapse: collapse;
          }
  
          .date td {
              width: 70px;
          }
      </style>
  </head>
  <body>
  <table align="center">
      <tr>
          <td colspan="6">课程表</td>
      </tr>
      <tr class="date">
          <td></td>
          <td>星期一</td>
          <td>星期二</td>
          <td>星期三</td>
          <td>星期四</td>
          <td>星期五</td>
      </tr>
      <tr>
          <td rowspan="4">上午</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
      </tr>
      <tr>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
      </tr>
      <tr>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
      </tr>
      <tr>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
      </tr>
      <tr>
          <td rowspan="4">下午</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
      </tr>
      <tr>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
      </tr>
      <tr>
  
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
      </tr>
      <tr>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
      </tr>
      <tr>
          <td rowspan="2">晚自习</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
      </tr>
      <tr>
  
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
          <td>化学</td>
      </tr>
  </table>
  </body>
  </html>
  ```

<img src="img/21.png">

### **border-spacing**

- 用于设置单元格之间的水平、垂直间距

<img src="img/22.png">

## **表单**

### **常用元素**

- form：表单
  - 一般情况下，其他表单相关元素都是它的后代元素

- input：单行文本输入框、单选框、复选框、按钮等元素

- textarea：多行文本框

- select、option：下拉选择框

- button：按钮

- label：表单元素的标题

- fieldset：表单元素组

- legend：fieldset的标题

### input**的常用属性**

- type：input的类型

  - text：文本输入框（明文输入）
  - password：文本输入框（密文输入）
  - radio：单选框
    - 例如：区别性别
  - checkbox：复选框
  - button：按钮<font color=red size=3>（不写value就是没有文字的）</font>
  - reset：重置<font color=red size=3>（不写value，默认是重置）</font>
  - submit：提交表单数据给服务器<font color=red size=3>（不写value，默认是提交）</font>
  - file：文件上传
  - hidden：隐藏域

  ```html
  <!DOCTYPE html>
  <html lang="zh">
  <head>
      <meta charset="UTF-8">
      <title>form</title>
  </head>
  <body>
  <div>
      手机：<input type="text">
  </div>
  <div>
      密码：<input type="password">
  </div>
  <div>
      验证码：<input type="text">
      <input type="button" value="获取验证码">
  </div>
  <div>
      性别：男<input type="radio"> 女<input type="radio"><br>
  </div>
  <div>
      兴趣：
      篮球<input type="checkbox">
      足球<input type="checkbox">
      跑步<input type="checkbox">
  </div>
  <div>
      <input type="reset" value="重置">     
  </div>
  </body>
  </html>
  ```

<img src="img/23.png">

### form**的常用属性**

- action

  - 用于提交表单数据的请求URL

- method

  - 请求方法（get和post），默认是get

  - 提交表单数据时，浏览器发送的是http请求，有2种请求方法可以选择

    - **get**
      - 在请求URL后面以`?`的形式跟上发给服务器的参数，多个参数之间用&隔开，比如
      http://ww.test.com/login?phone=123&password=234&sex=1
      - 由于浏览器和服务器对URL长度有限制，因此在URL后面附带的参数是有限制的，**通常不能超过1KB**

    <img src="img/24.png">

    - **post**
      - 发给服务器的参数全部放在**请求体**中
      - 理论上，post传递的数据量没有限制（具体还得看服务器的处理能力）
      - 提交文件一定要用

    <img src="img/25.png">

- target

  - 在什么地方打开URL（参考a元素的target）

- enctype

  - 规定了在向服务器发送表单数据之前如何对数据进行编码
  - 取值有3种
    - application/x-www-form-urlencoded：默认的编码方式
    - multipart/form-data：**文件上传时必须为这个值，并且method必须是post**
    - text/plain：普通文本传输

  accept-charset：规定表单提交时使用的字符编码





### 文件上传

```html
<form action="http://www.baidu.com" target="_blank" method="post" enctype="multipart/form-data">
	<div>
        	<input type="file" name="photo">
	</div>
</form>
```

上传成功后如图所示：

<img src="img/26.jpg">

### 请求

- **name**

- **value**
  - 可设置默认值

### input和**label**

- label元素一般跟input配合使用，用来表示input的标题
- labe可以跟某个input绑定，点击label就可以激活对应的input
  - label的for和input的id相同即可

### 整体表单代码

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>form</title>
</head>
<body>

<!-- value可以设置默认值-->

<form action="http://www.baidu.com" target="_blank" method="post" enctype="multipart/form-data">
    <div>
        <label for="phone">手机：</label>
        <input id="phone" type="text" name="phone">
    </div>

    <div>
        <label for="pwd">密码：</label>
        <input id="pwd" type="password" name="pwd">
    </div>

    <div>
        <label for="code">验证码：</label>
        <input id="code" type="text" name="code">
        <input type="button" value="获取验证码">
    </div>

    <div>
        <label for="photo">照片：</label>
        <input id="photo" type="file" name="photo">
    </div>

    <div>
        性别：
        男<input type="radio" name="sex" value="1">
        女<input type="radio" name="sex" value="2">
    </div>

    <div>
        <!--
        checkbox的name和value都是由服务器规定的
        同一种类型的checkbox，name值要保持一致
        -->
        兴趣：
        篮球<input type="checkbox" name="hobby" value="1">
        足球<input type="checkbox" name="hobby" value="2">
        跑步<input type="checkbox" name="hobby" value="3">

        电影：
        《电影1》<input type="checkbox" name="movie" value="1">
        《电影2》<input type="checkbox" name="movie" value="2">
        《电影3》<input type="checkbox" name="movie" value="3">
    </div>

    <div>
        <input type="reset" value="重置">
        <input type="submit" value="注册">
    </div>

</form>

</body>
</html>
```













