## **常用图片格式**

- **png：**静态图片，支持透明
- **jpg：** 静态图片，不支持透明（有背景色）
- **gif：**  动态图片、静态图片，支持透明

**示例：**

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>picture</title>
</head>
<body bgcolor="red">
    0.png
    <img src="0.png" alt=""> <br>
    1.jpg
    <img src="1.jpg" alt=""> <br>
    2.gif
    <img src="2.gif" alt=""> <br>
    3.gif
    <img src="3.gif" alt=""> <br>
</body>
</html>
```

**效果图：**

<img src="2.png" width="400">

## **像素(px)**

- 像素(px)是图片显示的最小单位
- 每个像素都能表示一种颜色
- 计算机显示出来的图像都是由一堆像素组成的
- 组成图片的像素越多，显示越清晰
- 平时说的屏幕分辨率，一半都是用像素作为单位
- **就算改了后缀名，图片格式仍然不变**

示例：50和50px是一样的

```html
<img src="0.png" 
     alt="XXXXXXXXXXXX"
     width="50"
     width="50px">
```

**（官方文档：alt的值不能为空）**

## **a元素**

- 定义超链接，用于打开新的URL
- 常用属性
  - href：制定要打开的URL
  - Hypertext Reference的简称
  - target：在哪里打开URL
    - _self：默认值，在当前窗口打开URL
    - _blank：在新窗口打开URL
    - _parent：在父窗口打开URL
    - _top：在顶层窗口打开URL
    - _frame的名称：指定页面打开

示例：

```html
<a href="www.baiud.com" >百度</a>
<a href="www.baiud.com" target="_self">百度</a>
<a href="www.baiud.com" target="_blank">百度</a>
```

## **iframe元素**

- 实现在一个html文档中嵌入其他html文档
- frameboder属性
  - ="1"：显示边框
  - ="0"：不显示边框

**示例：**

```html
<iframe src="http://www.baidu.com" 
        frameborder ="1" 
        width="1000" 
        height="800"></iframe>
```

**效果图：**<img src="3.png" alt="图片未加载" height="300">

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>page_a</title>
</head>
<body>
我是页面A
<iframe src="page_b.html" frameborder="1" width="500" height="500"></iframe>
</body>
</html>
```

```html
<body>
我是页面B
<iframe src="page_c.html" frameborder="1"></iframe>
</body>
```

```html
<body>
我是页面C
<br>
<a href="http://www.baidu.com" target="_self">    百度(_self)</a>
<br>
<a href="http://www.baidu.com" target="_blank">   百度(_blank)</a>
<br>
<a href="http://www.baidu.com" target="_parent">  百度(_parent)</a>
<br>
<a href="http://www.baidu.com" target="_top">     百度(_top)</a>
</body>
```

<img src="4.png" alt="111">

- parent： 在页面B打开百度
- top：       在页面A打开百度
- blank：  在新页面打开百度
- _frame的名称：指定页面打开
  - **需要设定name！！！！**

**代码示例：**

```html
<iframe name="frame1" src="http://www.baidu.com" frameborder="1">
</iframe>
<iframe name="frame2" src="http://www.taobao.com" frameborder="1"></iframe>
<a href="http://www.qq.com" target="frame1"> 腾讯网 </a>
```

点击腾讯网可以在iframe1中的界面打开腾讯网

> **注：很少使用iframe**

## **base元素**

- 可以利用base元素设置当前页面所有a元素的**默认行为**
  - href：对于相对路径而言，默认添加base中的href
  - target：默认一下所有a元素的tar
  - get都是该值
- base元素写在head元素中
- 最好不要分成2个base写，写在一个里面更好。

## **锚点链接**

- 实现**页面的内部跳转**

- a元素

**代码示例：**

```html
<a href="#name">xxxxxxxx</a>
```

- **写上#**才是寻找页面内部内容
  - **就写一个#**就是回到最顶部

  - 如果是**其他页面**，可以写成：

  ```html
  <a href="htmlname.html#name">跳转到html的name处</a>
  ```

- 设定**跳转到**元素的**id值**（必须是id）

  - 只有a元素例外

  ```html
  <a href="#first">跳转到第一章</a>
  <a name="first">第一章</a>
  ```

- span、h元素都可以使用锚点链接

- name不是所有元素都有的属性（span就没有这个属性）


### **综上，定义锚点的方法：**

- **1、**不管什么元素，定义id属性值（href="#id值"）
- **2、**a元素，定义name属性值（href="#name值"）


## **伪链接**

- 没有指明具体链接地址的链接
- 需要对应的js代码

```html
<a href="#" onclick="alert("充值成功！"); return false;">立即充值</a><br>
```

- 把一个链接当作按钮来使用


- 若不写href的值，默认回到文档顶部。但是，**非常危险**！！

```html
<a href="javascript:alert("充值成功！");">立即充值</a><br>
```

**等同于第一个代码示例**（锚点链接颜色会变化，用js链接颜色不会变化）

```html
<a href="#" onclick="return false;">立即充值</a><br>
<a href="javascript:;">立即充值</a><br>
```

**上面两个链接就是什么事都不做。**

## **图片链接**

```html
<a href="http://www.baidu.com" target="_blank">
	<img src="images.png" alt="111">
</a>
```

## **a元素其他用途**

```html
<a href="https://github.com/CoderMJLee/MJRefresh/archive/master.zip
         ">下载压缩文件</a><br>
<a href="mailto:12345@qq.com">发邮件</a><br>
<a href="ed2k://|file|%E7%94%9F%E6%B4%BB%E5%A4%A7%E7%88%86%E7%82%B8.The.Big.Bang.Theory.S10E24.END.%E4%B8%AD%E8%8B%B1%E5%AD%97%E5%B9%95.WEB-HR.AAC.1024X576.x264-%E4%BA%BA%E4%BA%BA%E5%BD%B1%E8%A7%86.mp4|194911068|a3285a9ddbea54f5200d3367ec376a58|h=ky54pschiappe5afeqic3oujrue7sxta|/
         "></a>
```

## **URL**

- URL的全程是Uniform Resource Locator（统一资源定位符）
- URL就是资源的地址、位置，互联网上的每个资源都有一个唯一的URL
- 通过一个URL，可以找到互联网上唯一的资源
- URL的基本格式：protocol://hostname/path =协议://主机地址/路径

https://www.baiduc.com.img/bdlogo.gif

https://183.232.231.173.img/bdlogo.gif（两者等效）

- 协议：不同的协议，代表着不同的资源查找方式、资源传输方式
- 主机地址：存放资源的主机的IP地址（域名）
- 路径：资源在主机的具体位置

## **URL常见的协议**

- http

  - 超文本传输协议，访问的是远程的**网络资源**，格式是http://
  - http协议是在网络开发中最常用的协议
  - https相当于是http的安全版

- file

  - 访问的是本地计算机上的资源，格式是file://（不用加主机地址）

    **相当危险！！**

- mailto

  - 访问的是电子邮件地址，格式是mailto:

- ftp

  - 访问的是共享主机的文件资源，格式是ftp://

- ed2k

  - 通过支持ed2k（专用下载链接）协议的P2P软件访问该资源（代表软件：电驴），格式是ed2k://

- thunder

  - 通过支持thunder（专用下载路径）协议的P2P软件访问该资源（代表软件：迅雷），格式是：thunder://

## **更具体的URL**

```protocol://hostname[:port]/path/[;parameters][?query]#fragment```

```	http://www.baidu.com:80/s?wd=ios#page```

**path一般是s，[]内容可以省略**

- port（端口号）
  - 一台拥有IP地址的主机可以提供许多服务，如Web服务、FTP服务、SMTP服务等
  - 主机通过 “IP地址+端口号” 来区分不同的服务，端口号类似于营业厅的窗口
  - 端口号的范围0~65536，HTTP默认端口号是80，FTP默认端口号是21

<img src="5.png" alt="111">

- query
  - 请求参数，提交给服务器的参数
  - 例如，上述中"**wd=ios**"
- fragment
  - 锚点位置

## **标签语义化**

- 选择标签的时候，尽量让每一个标签都有正确的语义（尽管css与js可以实现相应功能）

