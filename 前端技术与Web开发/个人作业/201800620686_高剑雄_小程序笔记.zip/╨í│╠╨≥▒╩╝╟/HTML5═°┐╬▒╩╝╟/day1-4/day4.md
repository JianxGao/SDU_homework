## **CSS选择器（selector）**

- 按照一定的规则选出符合条件的元素，为之添加CSS样式

- 选择器的种类繁多，大概可以这么归类
  - 通用选择器（universal selector）
  - 元素选择器（type selectors）
  - 类选择器（class selectors）
  - id选择器（id selectors）
  - 属性选择器（attribute selectors）
  - 组合（combinators）
  - 伪类（pseudo-classes）
  - 伪元素（pseudo-elements）

### 元素选择器（type selectors）

- 所有选中元素

  - 在如下代码中，div就是选择器，{}中表示给选择器选中的元素设置的样式

  ```html
  <style>
      div{
          color: red;
      }
  </style>
  ```

### **通用选择器（universal selector）**

- 所有的元素

  ```html
  *{
  	color: red;
  }
  ```

- 一般用来给**所有元素**作一些通用性的设置

  - 如内边距、外边距

    ```html
    *{
    	margin: 0;
    	padding: 0;
    }
    ```

  - 参考：https://www.jd.com

- 效率比较低，尽量不要使用

### **id选择器（id selectors）**

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>selector1</title>
    <style>
        #p3{
            color: red;
        }
    </style>
</head>
<body>
    <p>我是p1</p>
    <p>我是p2</p>
    <p id="p3">我是p3</p>
    <p>我是p4</p>
</body>
</html>
```

![](11.png)

- 注意点：
  - 同一个文档中id要唯一，不能重复
  - 如果id值是由多个单词组成，单词之间可以用`-`、`_`连接，也可以使用驼峰标识（如 the main title，要写成theMainTitle）
  - 最好不要使用标签名作为id值
  - 中划线又叫连字符（hyphen）

### **类选择器（class selector）**

- **开发过程中，最常用最灵活的选择器**
- 一个元素可以由多个class值，每个class之间用**空格**隔开

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>selector1</title>
    <style>
        .main{
            color: #579242;
        }
    </style>
</head>
<body>
    <p>我是p1</p>
    <p>我是p2</p>
    <p class="main food">我是p3</p>
    <p class="main">我是p4</p>
    <p class="main">我是p5</p>
    <p>我是p6</p>
    <p>我是p7</p>
    <p>我是p8</p>
    <p>我是p9</p>
</body>
</html>
```

![](12.png)

- class值如果由多个单词组成，单词之间可以用`-`、`_`连接，也可以使用驼峰标识
- 最好不要用标签名作为class值

练习：

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>practice</title>
    <style>
        .sure{
            background-color: #53a93f;
            color: #fff;
            /* 内边距 */
            padding-left: 20px;
            padding-right: 20px;
            padding-top: 10px;
            padding-bottom: 10px;
            font-size: 18px;
            /*
            设置鼠标样式（鼠标移动到元素上时显示的样式）
            cursor: pointer是一只小手的样式
            */
            cursor: pointer;
        }
        .delete{
            background-color: #D73D32;
            color: #fff;
            padding-left: 20px;
            padding-right: 20px;
            padding-top: 10px;
            padding-bottom: 10px;
            font-size: 18px;
            /* 圆角半径 */
            border-radius: 5px;
            /*
           设置鼠标样式（鼠标移动到元素上时显示的样式）
           cursor: pointer是一只小手的样式
           */
            cursor: pointer;
        }
        .reset{
            background-color: #F6C12A;
            color: #fff;
            padding-left: 20px;
            padding-right: 20px;
            padding-top: 10px;
            padding-bottom: 10px;
            font-size: 18px;
            /* 圆角半径 */
            border-radius: 5px;
            /*
           设置鼠标样式（鼠标移动到元素上时显示的样式）
           cursor: pointer是一只小手的样式
           */
            cursor: pointer;
        }
        .cancel{
            background-color: #57B5E3;
            color: #fff;
            /* 内边距 */
            padding-left: 20px;
            padding-right: 20px;
            padding-top: 10px;
            padding-bottom: 10px;
            font-size: 18px;
            /*
           设置鼠标样式（鼠标移动到元素上时显示的样式）
           cursor: pointer是一只小手的样式
           */
            cursor: pointer;
        }
    </style>
</head>
<body>
<br><br><br><br><br>
    <span class="sure">确定</span>
    <span class="delete">删除</span>
    <span class="reset">重置</span>
    <span class="cancel">取消</span>
</body>
</html>
```

![](13.png)

**代码改进：**

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>practice</title>

    <style>
        /* 按钮（button） */
        .btn{
            color: #fff;
            /* 内边距 */
            padding-left: 20px;
            padding-right: 20px;
            padding-top: 10px;
            padding-bottom: 10px;
            font-size: 18px;
            /*
           设置鼠标样式（鼠标移动到元素上时显示的样式）
           cursor: pointer是一只小手的样式
           */
            cursor: pointer;
        }

    	/* 按照颜色分类 */
        /* 危险 */
        .danger{
            background-color: #D73D32;
        }
        /* 警告 */
        .warning{
            background-color: #F6C12A;
        }
        /* 普通 */
        .normal{
            background-color: #53a93f;
        }
        /* 取消 */
        .cancel{
            background-color: #57B5E3;
        }

    	/* 按照角度分类 */
        /* 圆角 */
        .round{
            /* 圆角半径 */
            border-radius: 5px;
        }
    </style>
</head>
<body>
<br><br><br><br><br>
<!--
项目中有4中类型的按钮
1、危险（danger）
2、警告（warning）
3、普通（normal）
4、取消（cancel）
这些按钮可能是直角，也可能是圆角
-->
    <span class="btn normal round">确定</span>
    <span class="btn danger">删除</span>
    <span class="btn warning">重置</span>
    <span class="btn cancel">取消</span>
</body>
</html>
```

- 类选择器的类顺序没有要求，可以任意换位置

### **属性选择器**

- **使用属性选择器时，格式为：`attribute[符号]="value"`，千万不能忘记加引号！**

- [[*attribute*\]](https://www.w3school.com.cn/cssref/selector_attribute.asp)选取带有指定属性的元素。

  - 举例1

  ```html
  <style>
      [href]{
          color: red;
      }
  </style>
  
  <a href="http://www.baidu.com">百度</a>
  <a>京东</a>
  <a href="http://www.163.com">网易</a>
  ```

- [[*attribute*=*value*\]](https://www.w3school.com.cn/cssref/selector_attribute_value.asp)选取带有指定属性和值的元素。

  - 举例2

  ```html
  <style>
      [id="main"]{
          color: red;
      }
  </style>
  <div id="main">
      div
  </div>
  ```

  - **`#test`和`[id="text"]`本质上不同**

- [[*attribute*~=*value*\]](https://www.w3school.com.cn/cssref/selector_attribute_value_contain.asp)选取属性值中包含指定词汇的元素。（指定单词必须用空格与其他单词隔开）

  - 举例3

  ```html
  <style>
      [title~="one"]{
          color: red;
      }
  </style>
  <div title="one">div</div>
  <div title="one two">div</div>
  <div title="test one">div</div>
  <div title="test one two">div</div>
  ```

- [[*attribute*|=*value*\]](https://www.w3school.com.cn/cssref/selector_attribute_value_start.asp)属性值恰好等于**特定单词**或者以**特定单词**开头且后面紧跟**连字符-**的元素

  - 举例4

  ```html
  <style>
  	[title|="one"]{
  		color: red;
  	}
  </style>
  <div title="one-two">文字内容</div>
  <div title="one">文字内容</div>
  ```

  - 一般是用在lang属性上（语言代码）

    语言代码有很多后缀，适合使用`|=`

    ```html
    [lang|="en"]{
    	color: red;
    }
    [lang|="zh"]{
    	color: red;
    }
    ```

- [[*attribute*^=*value*\]](https://www.w3school.com.cn/cssref/selector_attr_begin.asp)属性值以指定值**开头**的每个元素

  - 举例5

    ```html
    <!DOCTYPE html>
    <html lang="zh">
    <head>
        <meta charset="UTF-8">
        <title>css_selector</title>
        <style>
            [href^="mailto:"] {
                color: red;
            }
        </style>
    </head>
    <body>
    <a href="http://www.baodu.com">百度</a>
    <a href="http://www.163.com">网页</a>
    <a href="mailto:1234567@qq.com">邮件1</a>
    <a href="mailto:66666@qq.com">邮件2</a>
    </body>
    </html>
    ```

- [[*attribute*$=*value*\]](https://www.w3school.com.cn/cssref/selector_attr_end.asp)属性值以指定值**结尾**的每个元素

  - 举例6

  ```html
  <!DOCTYPE html>
  <html lang="zh">
  <head>
      <meta charset="UTF-8">
      <title>css_selector</title>
      <style>
          [href$=".zip"] {
              color: red;
          }
      </style>
  </head>
  <body>
  <a href="http://www.baodu.com/abc.zip">百度</a>
  <a href="http://www.163.com">网页</a>
  <a href="mailto:1234567@qq.com">邮件1</a>
  <a href="mailto:66666@qq.com">邮件2</a>
  </body>
  </html>
  ```

- [[*attribute**=*value*\]](https://www.w3school.com.cn/cssref/selector_attr_contain.asp)属性值中**包含**指定值的每个元素

  ```html
  <!DOCTYPE html>
  <html lang="zh">
  <head>
      <meta charset="UTF-8">
      <title>css_selector</title>
      <style>
          [href*="520it.com"] {
              color: red;
          }
      </style>
  </head>
  <body>
  <a href="http://www.520it.com">111</a>
  <a href="http://www.520it.com/abouts">222</a>
  <a href="http://bbs.520it.com">333</a>
  <a href="mailto:66666@qq.com">444</a>
  </body>
  </html>
  ```

  **知道：带有`[]`的是属性选择器**

### **后代（组合）选择器**

- div元素里面的span元素**（包括直接、间接子元素）**

```html
div span{
	color: red;
}
```

- div元素中的p元素中的span元素

```html
div p span{
	color: red;
}
```

### **子（组合）选择器**

- 找出div元素里面的**直接**span子元素**（不包括间接子元素）**

```HTML
div>span{
	color: red;
}
```

- **找出div中的p的直接span子元素**

```html
div>p>span{
	color: red;
}
```

**综合运用**

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>css_selector</title>
    <style>
        .name>#title>[title]{
            color: blue;
        }
    </style>
</head>
<body>
<div class="name">
    <div id="title">
        <span title="12121212">3476283647632</span>
    </div>
</div>
</body>
</html>
```

### **相邻兄弟（组合）选择器**

- div元素后面**紧挨着**的**p元素**（且div、p必须是兄弟关系）

```html
div+p{
	color: red;
}
```

### **全体兄弟（组合）选择器**

- div元素**后**的所有**p元素**（且div、p必须是兄弟关系）

```html
div~p{
	color: red;
}
```

## **选择器组**

### **交集选择器**

- 同时符合2个条件的元素（div元素、class值有one）

```html
div.one{
	color: red;
}
```

### **并集选择器**

- 所有div元素+所有class值有one的元素——所有title属性值=test的元素

```html
div,.one,[title="test"]{
	color: red;
}
```

等价于

```html
div{
	color: red;
}

.one{
	color: red;
}

[title="test"]{
	color: red;
}
```

- **把标签名放在前面**

### **练习**

- 1

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>practice1</title>
    <style>
        input[type="text"],textarea{
            color: red;
        }
    </style>
</head>
<body>
<!--单行文本-->
<input type="text">
<input type="radio">
<input type="checkbox">
<input type="color">
<!--多行文本-->
<textarea></textarea>
</body>
</html>
```

<img src="14.png" alt="错误">

- 2

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>practice2</title>
    <style>
        div.box>p>span>strong>span[title="one"]>span>strong#cat~em{
            color: red;
        }
    </style>
</head>
<body>
<div><em>em0</em></div>
<div class="box">
    <div><p>paper</p></div>
    <p>
        <span>span</span>
        <strong>
            <span title="one">
                <strong id="dog">strong-dog</strong>
                <span>
                    <em>em1</em>
                    <strong id="cat">strong-cat</strong>
                    <em>em2</em>
                    <em>em3</em>
                    <em>em4</em>
                </span>
            </span>
        </strong>
    </p>
</div>
</body>
</html>
```

- **优化原则：在保证精准性的前提下，尽量简洁**

```css
div.box>p>span>strong>span[title="one"]>span>strong#cat~em{
	color: red;
}
/*只取有属性或者id的标签*/
div.box span[title="one"] strong#cat~em{
	color: red;
}
/*删去标签名*/
div [title="one"] #cat~emm{
	color: red;
}
/*因为id是唯一的*/
#cat~em{
	color: red;
}
```

### **伪类选择器**

- 常见的伪类有：
  - 动态伪类（dynamic pseudo-classes）
    - :link、:visited、:hover、:active、:focus
  - 目标伪类（target pseudo-classes）
    - :target
  - 语言伪类（language pseudo-classes）
    - :lang( )
  - 元素状态伪类（UI element states pseudo-classes）
    - :enabled、:disabled、:checked
  - 结构伪类（structural pseudo-classes）
    - :nth-child( )、:nth-last-child( )、:nth-of-type( )、:nth-last-of-type( )
    - :first-child、:last-child、:first-of-type、:last-of-type
    - :root、:only-child、:only-of-type、:empty	
  - 否定伪类（negation pseudo-classes）
    - :not()

### **动态伪类（dynamic pseudo-classes）**

- a:link 未访问的链接

- a:visited 已访问的链接

- a:hover 鼠标挪动到链接上

- a:active 激活的链接（鼠标在链接上长按住未松开）

  - 使用举例

  ```html
  <!DOCTYPE html>
  <html lang="zh">
  <head>
      <meta charset="UTF-8">
      <title>动态伪类</title>
      <style>
          /*未访问的链接*/
          a:link{
              color: yellow;
          }
          /*已访问的链接*/
          a:visited{
              color: red;
          }
          /*当鼠标移动到链接上*/
          a:hover{
              color: blue;
          }
          /*被激活的链接（鼠标左键点击链接时，未松开）*/
          a:active{
              color: green;
          }
          div:hover{
              background-color: black;
          }
      </style>
  </head>
  <body>
  <a href="http://www.baidu.com">访问</a>
  <!-- 除了a元素，:hover、:active也能用在其他元素上 -->
  <div>我是div</div>
  </body>
  </html>
  ```

  ![](15.png)

  - 使用注意
    - **:hover必须放在:link和:visited后面才能完全生效**
    - **:active必须放在:hover后面才能完全生效**
    - 所以建议的编写顺序是 :link、:visited、:hover、:active
    - 记忆：女朋友看到LV包包后，ha ha大笑
  - 除了a元素，:hover、:active也能用在其他元素上

- :focus当前拥有输入焦点的元素（能接收键盘输入）

  - 对于a元素效果与a:active相似
  
    当tab选中时处于focus状态
  
- 动态伪类编写顺序建议为

  - :link、:visited、:focus、:hover、:active
  - 记忆：女朋友看到LV包包后，（Feng）疯一样地ha ha大笑

### **去除a元素默认的:focus效果**

- 在`a:focus{}`中加上outline: none;

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>focus</title>
    <style>
        a:focus{
            /* 清空默认的轮廓 */
            outline: none;
        }
    </style>
</head>
<body>

<a href="#">链接</a>
<a href="#">链接</a>
<a href="#">链接</a>
<a href="#">链接</a>
</body>
</html>
```

- tabindex
  - 将tabindex的属性设置为-1，代表禁止tab选中

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>focus</title>
    <style>
        a:focus{
            /* 清空默认的轮廓 */
            outline: none;
        }
    </style>
</head>
<body>
<input type="text" tabindex="-1">
<input type="text" tabindex="-1">
<input type="text" tabindex="1">
<input type="text" tabindex="2">
<a href="#">链接</a>
<a href="#">链接</a>
</body>
</html>
```

### **小细节**

- 直接给a元素设置样式，相当于给a元素的所有动态伪类都设置了

  ```html
  a{
  	color: red;
  }
  ```

- 相当于a:link、a:visited、a:hover、a:active、a:focus的color都是red

## **结构伪类（structural pseudo-classes）**

###  **- :nth-child( )**

- ```:nth-child(1)```
  
  - 是**父元素中的第1个子元素**
  
  ```html
  <!DOCTYPE html>
  <html lang="zh">
  <head>
      <meta charset="UTF-8">
      <title>nth-child</title>
      <style>
          /* span元素 并且它是父元素中的第一个子元素 */
          span:nth-child(1){
              color: red;
          }
      </style>
  </head>
  <body>
  <div>
      <span>span1</span>
      <span>span2</span>
      <span>span3</span>
      <span>span4</span>
  </div>
  </body>
  </html>
  ```
  
  <img src="17.png">
  
  ```html
  <!DOCTYPE html>
  <html lang="zh">
  <head>
      <meta charset="UTF-8">
      <title>nth-child</title>
      <style>
          /* span元素 并且它是父元素中的第一个子元素 */
          span:nth-child(1){
              color: red;
          }
      </style>
  </head>
  <body>
  <div>
      <p>123</p>
      <span>span1</span>
      <span>span2</span>
      <span>span3</span>
      <span>span4</span>
  </div>
  </body>
  </html>
  ```
  
  <img src="18.png">

- ```:nth-child(2n)```
  - n代表任意正整数和0，即偶数个的子元素
  - 等同于```:th-child(even)```

- `:nth-child(2n+1)`
  
- 等同于`:nth-child(odd)`
  
- **完整使用格式`:nth-child(an+b)`**
  
  - **父元素中的第an+b个子元素**
- 用`:nth-child()`表示最前面2个子元素
  
  - `:nth-child(-n+2)`

### **- :nth-last-child( )**

- `:nth-last-child()`的语法跟`:nth-child()`类似，不同点是`:nth-last-child()`从最后一个子元素开始往前计数

  - `:nth-last-child(1)`，代表倒数第一个子元素

  - `:nth-last-child(-n+2)`，代表最后2个子元素

- 如何表示第2个~倒数第2个元素（去除头和尾元素）

  **交集选择器**

  ```css
  p:nth-child(n+2):nth-last-child(n+2){
  	color: red;
  }
  ```

### **:nth-of-type( )、:nth-last-of-type( )**

- `:nth-of-type()`用法跟`:nth-child()`类似，

  不同点是`:nth-of-type()`计数时只计算同种类型的元素

- `:nth-last-of-type()`用法跟`:nth-of-type()`类似
  不同点是`:nth-last-of-type()`从最后一个这种类型的子元素开始往前计数

### **其他结构伪类**

- `:first-child`，等同于`:nth-child(1)`

- `:last-child`，等同于`:nth-last-child(1)`

- `:first-of-type`，等同于`:nth-of-type(1)`

- `:last-of-type`，等同于`:nth-last-of-type(1)`

- `:only-child`，是父元素中唯一的子元素

  - 等同于`:first-child:last-child`或者`:nth-child(1):nth-last-child(1)`

- `:only-of-type`，是父元素中唯一的这种类型的子元素

  - 等同于`:first-of-type` `:last-of-type`

    或者`:nth-of-type(1)` `:nth-last-of-type(1)`

- `:root`，根元素，就是HTML元素

### **结构伪类 - :empty**

`:empty`代表里面完全空白的元素

```css
p:empty {
    width: 100px;
    height: 20px;
    background: red;
}
```

### **否定伪类（negation pseudo-class）**

- `:not()`的格式是`:not(x)`
  
  - x是一个简单选择器
  - 元素选择器、通用选择器、属性选择器、类选择器、id选择器、伪类**（除否定伪类）**
  - **不知处组合**
  
- `:not(x)`表示除x以外的元素

  ```html
  <!DOCTYPE html>
  <html lang="zh">
  <head>
      <meta charset="UTF-8">
      <title>not</title>
      <style>
          div:not(#text){
              color: red;
          }
      </style>
  </head>
  <body>
  <div>div1</div>
  <div id="text">div2</div>
  <div>div3</div>
  <div>div4</div>
  <div>
      <p>我是p</p>
      <span>我是span</span>
  </div>
  </body>
  </html>
  ```

  <img src="19.png">

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>not</title>
    <style>
        :not(p):not(body):not(html){
            color: red;
        }
    </style>
</head>
<body>
<div>div1</div>
<div id="text">div2</div>
<div>div3</div>
<div>div4</div>
<div>
    <p>我是p</p>
    <span>我是span</span>
</div>
<p>我是p</p>
<span>我是span</span>
<strong>我是strong</strong>
</body>
</html>
```

<img src="20.png">

- **`:`前，最好加上元素名（不管伪类还是伪元素）**

### **伪元素（pseudo-elements）**

- 常用的伪元素有（一个或两个冒号都可以）
  - :first-line、::first-line
  - :first-letter、::first-letter 
  - :before、::before
  - :after、::after

- 为了区分伪元素和伪类，建议**伪元素使用2个冒号，比如::first-line**

#### **::first-line**

- ::first-line可以针对首行文本进行设置**（带上标签名）**

  ```html
  <!DOCTYPE html>
  <html lang="zh">
  <head>
      <meta charset="UTF-8">
      <title>pseudo-elements</title>
      <style>
          div {
              width: 100px;
              background-color: deepskyblue;
          }
          div::first-line{
              color: burlywood;
          }
      </style>
  </head>
  <body>
  <div>我是文字我是文字我是文字我是文字我是文字我是文字我是文字我是文字我是文字我是文字我是文字</div>
  </body>
  </html>
  ```

  <img src="21.png">

- 只有下列属性可以应用在::first-line伪元素**（不是所有的CSS属性都可以用在位元素上）**
  - 字体属性、颜色属性、背景属性
  - word-spacing、letter-spacing、text-decoration、text-transform、line-height

#### **::first-letter**

- 可以针对首字母设置属性

- 只有下列属性可以应用在::first-letter伪元素
  - 字体属性、margin属性、padding属性、border属性、颜色属性、背景属性
  - text-decoration、text-transform、letter-spacing、word-spacing（适当的时候）、line-height、float、vertical-align（只有当float是none时）

####  **::before和::after**

- 用来在一个元素的**内容之前或之后**插入其他内容（可以是文字、图片）
- 在CSS属性值中，使用`url(图片的URL)`来引用图片
  - `url(dot.png);`
  - `url('dot.png');`
  - `url("dot.png");`

- 举例

  ```html
  <!DOCTYPE html>
  <html lang="zh">
  <head>
      <meta charset="UTF-8">
      <title>before_after</title>
      <style>
          div::before{
              content: "666";
          }
          div::after{
              content: url("1.jpg");
          }
      </style>
  </head>
  <body>
  <div>我是div</div>
  </body>
  </html>
  ```

  <img src="22.png">

#### **attr()**

- 在content中，还可以使用attr(属性名)来获得元素的属性值

  ```html
  <!DOCTYPE html>
  <html lang="zh">
  <head>
      <meta charset="UTF-8">
      <title>attr()</title>
      <style>
          div::before{
              content: attr(class);
          }
          a[href^="http"]::after{
              content: "["attr(href)"]";
          }
      </style>
  </head>
  <body>
  <div class="abc">我是div</div>
  <a href="http://www.baidu.com">百度</a><br>
  <a href="http://www.jg.com">京东</a><br>
  <a href="http://www.taobao.com">淘宝</a>
  <a href="">哈哈</a>
  <a href="#">呵呵</a>
  </body>
  </html>
  ```

  <img src="23.png">

### **插件（Plugin）**

- 插件是基于某个系统平台或某个软件平台开发的程序，只能在指定的平台运行，不能脱离指定的平台单独运行
- 插件的定位是开发实现原平台不具备的功能
- 插件是一种可插拔的拓展程序，为其他应用程序增加额外的功能（比如浏览器插件）

#### **Emmet**

- Emmet官网： https://www.emmet.io/

- Emmet的作用
  - 提供了一种非常简洁的语法规则，按下Tab键就可以自动生成对应的一大串HTML\CSS代码
  
  - 可以极大地提高代码编写效率
  
  - 它是Zen Coding的升级版，由Zen Coding原作者开发，功能更加强大
  
    （Sublime Text默认无插件）

#### **基本语法（不要留空格）**

- `!`和`html:5`可以快速生成完整结构的html5代码

- **`>`和`+`**

  - **div>ul>li**

    ```HTML
    <div>
        <ul>
            <li></li>
        </ul>
    </div>	
    ```

  - **div+p+bq**

    ```html
    <div></div>
    <p></p>
    <blockquote></blockquote>
    ```

  - **div+div>p>span+em**

    ```html
    <div></div>
    <div>
    	<p>
        	<span></span>
            <em></em>
        </p>
    </div>
    ```

- **`*`和`^`**

  - **ul>li*5**

    ```html
    <ul>
    	<li></li>
    	<li></li>
        <li></li>
        <li></li>
        <li></li>
    </ul>
    ```

  - **div+div>p>span+em^h1**

    ```html
    <div></div>
    <div>
        <p>
            <span></span>
            <em></em>
        </p>
        <h1></h1>
    </div>
    ```

  **`^`代表上一级元素**
  
  **但是`^`再多，最终也是跟第一个元素同级**
  
  - **div+div>p>span+em^^^^h1**
  
  ```html
  <div></div>
  <div>
        <p><span></span><em></em></p>
  </div>
  <h1></h1>
  ```
  
- `()`

  - **div>(header>ul>li*2>a)+footer>p**
    
    
```html
    <div>
        <header>
            <ul>
                <li><a href=""></a></li>
                <li><a href=""></a></li>
            </ul>
        </header>
        <footer>
            <p></p>
        </footer>
    </div>
```

- **(div>dl>(dt+dd)*3)+footer>p** 
  
  ```html
    <div>
      <dl>
            <dt></dt>
          <dd></dd>
            <dt></dt>
          <dd></dd>
            <dt></dt>
          <dd></dd>
        </dl>
  </div>
    <footer>
      <p></p>
    </footer>
  ```
  
- **属性**

  - **div#header+div.page+div#footer.class1.class2.class3** 

    ```html
    <div id="header"></div>
    <div class="page"></div>
    <div id="footer" class="class1 class2 class3"></div>
    ```

  - **td[title=hello]**

    ```html
    <td title="hello"></td>
    ```

  - **td[title="Heelo world!" colspan=3]**

    ```html
    <td title="Heelo world!" colspan="3"></td>
    ```

  - **td[title colspan]**

    ```html
    <td title="" colspan=""></td>
    ```

- **`$`**

  - **ul>li.item*5**

    ```html
    <ul>
        <li class="item"></li>
        <li class="item"></li>
        <li class="item"></li>
        <li class="item"></li>
        <li class="item"></li>
    </ul>
    ```

  - **ul>li.item$*5**

    ```html
    <ul>
        <li class="item1"></li>
        <li class="item2"></li>
        <li class="item3"></li>
        <li class="item4"></li>
        <li class="item5"></li>
    </ul>
    ```

  - **ul>li.item$$*5**

    ```html
    <ul>
        <li class="item01"></li>
        <li class="item02"></li>
        <li class="item03"></li>
        <li class="item04"></li>
        <li class="item05"></li>
    </ul>
    ```

- **`$@`**

  ```html
  <!--ul>li.item$@*5-->
  <ul>
      <li class="item1"></li>
      <li class="item2"></li>
      <li class="item3"></li>
      <li class="item4"></li>
      <li class="item5"></li>
  </ul>
  <!--ul>li.item$@4*5-->
  <ul>
      <li class="item4"></li>
      <li class="item5"></li>
      <li class="item6"></li>
      <li class="item7"></li>
      <li class="item8"></li>
  </ul>
  <!--ul>li.item$@-*5-->
  <ul>
      <li class="item5"></li>
      <li class="item4"></li>
      <li class="item3"></li>
      <li class="item2"></li>
      <li class="item1"></li>
  </ul>
  <!--ul>li.item$@-9*5-->
  <ul>
      <li class="item13"></li>
      <li class="item12"></li>
      <li class="item11"></li>
      <li class="item10"></li>
      <li class="item9"></li>
  </ul>
  <!--ul>li.item$@9-*5-->
  <ul>
      <li class="item9-"></li>
      <li class="item10-"></li>
      <li class="item11-"></li>
      <li class="item12-"></li>
      <li class="item13-"></li>
  </ul>
  ul>li.item$$@4test*5
  <ul>
      <li class="item04test"></li>
      <li class="item05test"></li>
      <li class="item06test"></li>
      <li class="item07test"></li>
      <li class="item08test"></li>
  </ul>
  ul>li.item$@@4test*5
  <ul>
      <li class="item1@4test"></li>
      <li class="item2@4test"></li>
      <li class="item3@4test"></li>
      <li class="item4@4test"></li>
      <li class="item5@4test"></li>
  </ul>
  ```

- **{}**

  ```html
  <!--a{click}-->
  <a href="">click</a>
  <!--a>{click}-->
  <a href="">click</a>
  <!--a{click}+span{here}-->
  <a href="">click</a><span>here</span>
  <!--a>{click}+span{here}-->
  <a href="">click<span>here</span></a>
  <!--p{click}+a{here}+{to continue}-->
  <p>click</p><a href="">here</a>to continue
  <!--p>{click}+a{here}+{to continue}-->
  <p>click<a href="">here</a>to continue</p>
  ```

  

  <img src="24.png">

- **隐式标签**

  ```html
  <!--<div>-->
  <!--    .wrap>.content-->
  <!--</div>-->
  <div>
      <div class="wrap">
          <div class="content"></div>
      </div>
  </div>
  <!--<span>.item</span>-->
  <span><span class="item"></span></span>
  <!--<em>.item</em>-->
  <em><span class="item"></span></em>
  <!--ul>.item*5-->
  <ul>
      <li class="item"></li>
      <li class="item"></li>
      <li class="item"></li>
      <li class="item"></li>
      <li class="item"></li>
  </ul>
  table>#row$*4>[clospan=2]
  <table>
      <tr id="row1">
          <td clospan="2"></td>
      </tr>
      <tr id="row2">
          <td clospan="2"></td>
      </tr>
      <tr id="row3">
          <td clospan="2"></td>
      </tr>
      <tr id="row4">
          <td clospan="2"></td>
      </tr>
  </table>
  ```

- **其他简写**

  ```css
  /*w200*/
  width: 200px;
  /*w20+h30+m40*/
  width: 20px;
  height: 30px;
  margin: 40px;
  /*m20-30-40-50*/
  margin: 20px 30px 40px 50px;
  /*p-10-20--30*/
  padding: -10px 20px -30px;
  /*m10px20px*/
  /*m10-20*/
margin: 10px 20px;
  /*m10px-20*/
  margin: 10px -20px;
  /*fz20*/
  font-size: 20px;
  /*fz1.5*/
  font-size: 1.5em;
  /*fz50p*/
  font-size: 50%;
  /*fw400*/
  font-weight: 400;
  /*lh2*/
  line-height: 2;
  /*c#3*/
  color: #333333;
  ```
  
- 针对文字：

  - `p:%`
  - `e:em`
  - `x:ex`

- 更多语法规则，可以参考snippets.json
  
  - <a href="https://github.com/emmetio/emmet/blob/master/lib/snippets.json">https://github.com/emmetio/emmet/blob/master/lib/snippets.json</a>

<img src="25.png" width=400px>

<img src="26.png" width=350px;>

<img src="27.png" width=300px>

<img src="28.png" width=300px>

<img src="29.png" width=650px>










