## **CSS**

- 给网页中的每一个元素设置样式（排版布局），让网页更加精美

- Cascading Style Sheets，层叠样式表

- 很多资料，属性名=样式名

  ​					属性值=样式值

- CSS样式的书写格式

  ```css
  color: red
  ```

### 3种CSS样式应用

- 内联样式（inline style）（行内样式）

  - 将样式直接写在元素的style属性上

  - ```html
    <div style="color: red; background-color: blue; font-size: 20px;">文字内容</div>
    ```
  - <div style="color: red; background-color: blue; font-size: 20px;">文字内容</div>
  
  - **缺点：无法批量更改样式值**
  
- 文档样式表（document style sheet）（内嵌样式表）（embed style sheet）
  
  - 将样式写到head元素的style中
  
      ```html
      <head>
          <style type="text/css">
              div {
                  color: green;
                  /*设置背景色*/
                  backgruond-color: blue;
                   /*文字大小*/
                  font-size: 20px;
              }
          </style>
      </head>
      ```
  
      type属性的默认值="text/css"可省略
  
    - **缺点：无法批量修改多个页面的公共样式值**
  
- 外部样式表（external style sheet）

  - 将样式写在单独的css文件中，然后再当前网页的head元素中用link元素引用

  - 例子：

    css文件内容

    ```css
    @charset"UTF-8";
    div {
    	color: green;           
    	backgruond-color: blue;          
    	font-size: 20px;
    }
    ```

    html文件内容

    ```html
    <link rel="stylesheet" href="css/filename.css" type="text/css">
    ```

    type属性的默认值="text/css"可省略

### **三种CSS样式的区别**

- 内联样式只针对某个特定的元素

- 文档样式表、外部样式表可以针对一堆元素

### **@import**

- html文档直接导入CSS文件**（效果与link相同）**

  ```html
  <style>
  	@import "css/page2.css";
  </style>
  ```

- css文件中导入其他css文件

  ```css
  @charset "UTF-8";
  @import "page.css";
  @import "page2.css";
  ```

- 另一种格式

  ```html
  <style>
  	@import url("css/page3.css")
      @import url('css/page3.css')
      @import url(css/page3.css)
  </style>
  ```

- 不建议使用@import导入CSS文件，它的效率比link元素低

### **等价写法**

```css
h1{ font-weight: bold}
h1{ font-size 12px}
h1{ line-height: 14px}
h1{ font-family: Serif}
h1{ font-variant: normal}
h1{ font-style: normal}
```

```css
h1{ font-weight: bold;
	font-size 12px;
	line-height: 14px;
 	font-family: Serif;
 	font-variant: normal;
	font-style: normal;
}
```

### **CSS注释**

- ```css
  /*注释内容*/（不能嵌套）
  ```

- 可写位置：css文件中、style标签中

- ```html
  <style>
  	<!--这是一段注释-->（不能这么写！！）
      div{
          /*这是一段注释*/
          color:red;
      }
  </style>
  
  <div>我是div</div>
  ```

  **在css环境中写html注释会使css失效！！**
  
  **style标签中必须写/* 注释内容*/**

### **HTML和CSS的编写准则**

- **结构、样式分离**

	- 不要使用html元素的属性来给元素添加样式
	
	  **不推荐！！**
	
	```html
	<body bgcolor="yellow">
	<img src="images/beauty.jpg" alt="" width="200">
	</body>
	```
	
	**更推荐如下代码！**
	
	```html
	<style>
	    body{
	        background-color: yellow;
	    }
	    
	    img{
	        width: 200px;
	    }
	</style>
	
	<body>
		<img src="images/beauty.jpg" alt="">
	</body>
	```

- 废弃使用：deprecated。如font标签
- css产生的目的，就是取缔在html中增加样式，使html只负责结构

### **设置网页图标**

- link元素可以设置网页图标

- rel属性不能省略。指定文档与链接资源的关系

- 一般若rel确定，相应的type也会默认确定，所以可以省略type

  ```html
  <head>
      <meta charset="UTF-8">
      <title>网页图标</title>
      <link rel="icon" （不能省略）
            href="（http）//www.jd.com/favicon.ico" 
            type="image/x-iocn">
  </head>
  ```

- 网页图标支持的图片格式是ico、png，常用大小是16 * 16、24 * 24、32 *32（单位：像素）

- 搜索图标引擎，搜索code

### **CSS简史**

- CSS 1 -> CSS 2 -> CSS 2.1 -> CSS 2.2

- CSS 3：是CSS 2.x 以后对某一些 CSS模块进行升级更新后的称呼，

  比如CSS Color Module Level 3、Selectors Level 3、CSS Namespaces Module Level 3。

  目前并不存在真正意义的CSS 3

- CSS 4：是CSS 2.x 以后对某一些 CSS模块进行升级更新后的称呼，比如CSS Color Module Level 4、Selectors Level 4、CSS Text Module Level 4。目前并不存在真正意义的CSS 4

### **常用CSS属性**

- 按照CSS属性的具体用途，大致可以分类为
  - 文本：color、direction、letter-spacing、word-spacing、line-height、text-align、text-indent、text-transform、text-decoration、white-space
  - 字体：font、font-family、font-style、font-size、font-variant、font-weight
  - 背景：background、background-color、background-image、background-repeat、background-attachment、background-position
  - 盒子模型：width、height、border、margin、padding
  - 列表：list-style
  - 表格：border-collapse
  - 显示：display、visibility、overflow、opacity、filter
  - 定位： vertical-align、position、left、top、right、bottom、float、clear
- **CSS属性名都是小写！**

### **css官方文档**

- 官方文档地址
  - https://www.w3.org/standards/techs/css
  - https://www.w3.org/TR/CSS22/
  - https://www.w3.org/TR/CSS22/propidx.html
- CSS代码合法检测
  - http://jigsaw.w3.org/css-validator/
- CSS属性可用性（常用）
  - https://caniuse.com

### **最常用的CSS属性**

- color：前景色

  - 包括文字、装饰线、边框、外轮廓等的颜色

- background-color：背景色

- width：宽度

- height：高度

- font-size：字体大小

- 前景和背景色的区别

  ![](6.png)

### **span元素**

- 在默认情况下，与普通文本没有区别
- 用于区分特殊文本和普通文本，比如用来显示一些关键字

**小练习：**

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>practice</title>
    <style>
        pre{
            background-color: black;
            width: 350px;
            /* 在pre的上下左右都添加20px的内边距 */
            padding: 20px;
        }
        span{
            font-size: 25px;
        }
    </style>
</head>
<body>
<pre>
<code>
<span style="color: green;">/* box style */</span>
<span style="color: deepskyblue">.box</span><span style="color: white;">{</span>
    <span style="color: red;">margin</span><span style="color: white;">:</span><span style="color: rebeccapurple;"> 0 0 30</span><span style="color: white;">px</span><span style="color: rebeccapurple;"> 0</span><span style="color: white;">;</span>
    <span style="color: red;">padding</span><span style="color: white;">:</span><span style="color: rebeccapurple;"> 15</span><span style="color: white;">px;</span>
    <span style="color: red;">color</span><span style="color: white;">: red;</span>
    <span style="color: red;">background-color</span><span style="color: white;">: #007799;</span>
    <span style="color: red;">box-shadow</span><span style="color: white;">: none;</span>
    <span style="color: white;">}</span>
</code>
</pre>
</body>
</html>
```

效果如图所示:

![](7.png)

### **笔记技巧**

- 录视频做成gif插入，day3中的软件录制并转换
  - PDF不支持gif

- 输入目录：``[toc]+Enter``

### **div元素**

- 一般作为其他元素的父容器，作为一个整体。

- 用于把网页分割为多个独立的部分

- 检测一些网站的div，可用如下代码：

  ```html
  div{
  	outline: 2px solid green !important;
  }
  ```
- div的css的其他属性值
```html
<Style>
    div{
        /*让元素向左浮动*/
        float: left;
        /*外边距：元素与元素之间的间距*/
        margin: 10px;
    }
</Style>
```

### **CSS属性可用性**

- 查询https://caniuse.com

- WebStorm智能提示，标识版本

### **颜色**

- 基本颜色关键字
  - black	red	white	blue	green……
- RGB颜色：通过三种颜色通道的变化、叠加产生各式各样的颜色
  - 十进制：**rgb(red, green, blue)**
    - rgb(red, green, blue)，每一种颜色取值范围0~255
      - **黑色，rgb(0, 0, 0) 			白色，rgb(255, 255, 255)**
      - 也可以使用百分比，100%代表255
  - 十六进制：**#rrggbb**、#rgb
    - `#rrggbb`每一种颜色取值范围是00-FF
    - 红色`#ff0000`	黑色`#000000`	白色`#ffffff`
  - `#rgb`会自动转化为`#rrggbb`
      - 如`#fb0`扩展为`#ffbb00`
      - **尽量使用`#rgb`代替`#rrggbb`**
  - 一些颜色的RGB对照表
    - RGB颜色值越大，越靠近白色，越浅色
    - RGB颜色值越小，越靠近黑色，越深色
    - RGB颜色值一样的，一般是灰色

![](8.png)

- RGBA颜色：rgba(red, green, blue, alpha)

  - 在RGB颜色的基础上加了一个alpha，透明度
  - alpha取值范围是0.0~1.0
    - 0代表完全透明，1代表完全不透明
  - 关键字transparent等价于rgba(0, 0, 0, 0)，完全透明

## **CSS文本属性**

### **text-decoration**

- 用于设置文字的装饰线
  - none：无任何修饰线
    - **可以去除a元素默认的下划线**
  - underline：下划线
  - overline：上划线
  - line-through：删除线（中划线）

代码示例：

```html
<style>
    div{
        text_decoration: underline;
    }
</style>
<div>
    我是div
</div>
```

- u、ins默认设置了text-decoration为underline

### **letter-spacing**

- 设置字符之间的间距

### **word-spacing**

- 设置单词之间的间距

```html
<style>
    div{
        letter-spacing: 10px;
        word-spacing: 10px;
    }
</style>
<div>
    我是 div 好好 呵呵 嗯嗯
</div>
```

![](9.png)

### **text-transfrom**

- 大小写转换
  - capitalize：将单词首字母变成大写
  - uppercase：所有字母都变大写
  - lowercase：所有字母都变小写
  - none：没有任何影响
- 简易通过text-transfrom控制字母大小写，不在html中写死

### **text-indent**

- 设置第一行内容的缩进

- `text-indent: 2em；`刚好是缩进2个文字

  - em是一个相对单位，相对于font-size进行计算。

    em相当于font-size*2

- 不适用于所有元素，`<span>`等元素并不适用。

### **text-align**

- 设置**元素内容**在**元素中**的水平对齐方式
  - left：左对齐
  - right：右对齐
  - center：正中间显示
  - justify：两端对齐

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>text-align</title>
    <style>
        div{
            background-color: #f00;
            text-align: center;
        }
        span{
            background-color: #00f;
            text-align: center;
        }
    </style>
</head>
<body>
    <div>我是div</div>
    <span>我是span</span>
</body>
</html>
```

效果如图：

![](10.png)

**调式技巧：加一个背景色！**

宽度默认是占据整个父元素：`<div>`、`<p>`、`<h1>`~`<h6>`等等

宽度默认包裹内容，宽度等于内容的总宽度：`<span>`、`<strong>`、`<a>`

### **font-size**

- 决定文字的大小

  - 具体数值+数字
    
  - 如：100px
    
  - 也可以用em单位

    - 1em代表100%，2em代表200%，0.5em代表50%

  - 百分比

    - 基于父元素的font-size计算

    ```html
    <style>
        div{
            font-size: 20px;
        }
        span{
            font-size: 350%;/*350%*20px=70px*/(也可以写3.5em;)
        }
    </style>
    
    <div>
        <span>我是span</span>
    </div>
    ```

- 一般给`<body>`设置font-size就表示设置网页的默认字体大小

  - 其他元素可以基于父元素设置字体大小

### **font-family**

- 用于设置文字的字体名称

- 可以设置1个或者多个字体名称（从左到右按顺序选择字体，直到找到可欧阳那个的字体为止）

  ```html
  <style>
      span{
          font-family: "Consolas", "Courier New", "华文彩云", "Arial";
      }
  </style>
  ```

- 一般情况下，英文字体只适用于英文，中文字体同时适用于英文和中文
  
  - 一般英文字体写在前面，中文字体写在后面

### **@font-face**

- 让网页支持网络字体，不局限于系统自带的字体
- 常见的字体种类
  - TrueType字体：拓展名是 .ttf
  - OpenType字体：拓展名是 .ttf、.otf，建立在TrueType字体之上
  - Embedded OpenType字体：拓展名是 .eot，OpenType字体的压缩版
  - SVG字体：拓展名是 .svg、 .svgz
  - web开放字体：拓展名是 .woff，建立在TrueType字体之上
- 并不是所有浏览器都支持以上字体，使用时要多加测试
- 字体下载：http://font.chinaz.com/

```html
<style>
    @font-face{
        /*加载文字字体*/ 
        src: url("fonts/filename.ttf"),
           	 url("fonts/filename2.otf");
        /*自定义字体名称*/
        font-family: "迷你剪纸";
        
    }
    /*background-image: url("");*/
</style>
```

### **font-weight**

- 设置文字的粗细（重量）
- 100|200|300|400|500|600|700|800|900：每一个数字表示一个重量
  - normal：等于400
  - bold：等于700
  - strong、b、h1~h6等标签的font-weight默认就是bold

### **font-style**

- 设置文字的常规、斜体显示
  - normal：常规显示
  - italic：用**文字的斜体**显示（可能有字体不支持斜体）
  - oblique：文本倾斜显示
- em、i、cite、address、var、dfn等元素的font-style默认就是italic

### **font-variant**

- 影响小写字母的显示形式
  - normal：常规显示
  - small-caps：将小写字母替换为缩小过的大写字母