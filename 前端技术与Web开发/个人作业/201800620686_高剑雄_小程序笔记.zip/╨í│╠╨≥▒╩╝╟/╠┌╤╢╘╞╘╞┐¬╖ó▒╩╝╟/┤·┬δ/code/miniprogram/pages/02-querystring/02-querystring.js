// pages/02-querystring/02-querystring.js
const db = wx.cloud.database();
const _ = db.command

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  query_number:function(){
    console.log("Query_number")
    db.collection("data")
      .where({
        count: _.nin([1,3,4])
      })
      .get().then(console.log)
  },

  query_String:function(){
    console.log('Query_string')
    db.collection("data")
      .field({
        desc: true
      })
      .get().then(console.log)
  },

  query_zhengze:function(){
    console.log("Query_zhengze")
    db.collection("data")
      .where({
        name: new db.RegExp({
          regexp:'name-0[1-9]', //匹配name-01, name-02 …… name-09
          options:'i'
        })
      })
      .get().then(console.log)
  },

  query_location: function () {
    console.log('Query_location')
    db.collection("location").get().then(res =>{
      console.log(res.data[0].location.latitude)
    })
  },

  add_location:function(){
    db.collection("location").add({
      data:{
        location: db.Geo.Point(100.0012, 10.0022)
      }
    }).then(res => {
        console.log(res)
      })

    
    
    

  },


})