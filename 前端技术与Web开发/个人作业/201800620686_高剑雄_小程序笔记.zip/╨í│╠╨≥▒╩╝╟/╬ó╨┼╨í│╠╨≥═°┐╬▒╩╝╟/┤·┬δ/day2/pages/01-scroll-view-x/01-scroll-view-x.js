// pages/01-scroll-view-x/01-scroll-view-x.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    itemsData:[
      {
        "imgUrl": "https://img14.360buyimg.com/n1/s150x150_jfs/t30814/9/944457966/151730/b9082df7/5c01fcbbNa3869e29.jpg.dpg",
        "price": "1699",
        "outPrice": "1899"
      },
      {
        "imgUrl": "https://img14.360buyimg.com/n1/s150x150_jfs/t30409/283/889241385/203388/d44ae817/5c00d21aNcfbb2aa7.jpg.dpg",
        "price": "38.7",
        "outPrice": "60"
      },
      {
        "imgUrl": "https://img14.360buyimg.com/n1/s150x150_jfs/t1/17561/2/174/181822/5c078d55E6b3dd312/001c59776d959381.jpg.dpg",
        "price": "1899",
        "outPrice": "2899"
      },
      {
        "imgUrl": "https://img14.360buyimg.com/n1/s150x150_jfs/t26470/12/2593089004/174952/e153816b/5c0633c1N80aff116.jpg.dpg",
        "price": "28.5",
        "outPrice": "35.9"
      },
      {
        "imgUrl": "https://img14.360buyimg.com/n1/s150x150_jfs/t1411/245/746207504/132419/981fb579/55a8d386N2cbd7ba1.jpg.dpg",
        "price": "5399",
        "outPrice": "6799"
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }, 

  /**
   * 监听scroll-view的滚动
   */
  onbindscroll: function(event){
    // console.log(event.detail)
  },

  /**
   * 监听scroll-view的滚动最左边
   */
  onbindscrolltoupper: function(event){
    console.log(event.detail);
  },

  
})