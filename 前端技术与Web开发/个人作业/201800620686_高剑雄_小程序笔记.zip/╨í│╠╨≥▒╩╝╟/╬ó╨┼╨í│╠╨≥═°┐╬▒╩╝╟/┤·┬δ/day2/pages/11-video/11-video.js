// pages/11-video/11-video.js
var pause= false;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    danmulist:[
      {
        text:'我是第一个文本',
        color:'red',
        time: 3
      },
      {
        text:'我是第二个文本',
        color:'grren',
        time: 10
      }
    ],
    urls: [
      "http://baobab.kaiyanapp.com/api/v1/playUrl?vid=56841&editionType=default&source=qcloud",
      "http://baobab.kaiyanapp.com/api/v1/playUrl?vid=56499&editionType=default&source=qcloud",
      "http://baobab.kaiyanapp.com/api/v1/playUrl?vid=19111&editionType=default&source=qcloud",
      "http://baobab.kaiyanapp.com/api/v1/playUrl?vid=22963&editionType=high&source=qcloud",
    ],
    pause:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 获取video组件对象
    this.videoContext = wx.createVideoContext("myVideo", this);
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  onbindpause: function(event){
    this.setData({
      pause:true
    })
  },

  onbindplay: function (event){
    this.setData({
      pause:false
    })
  },

  /**
   * 处理button的点击事件
   */
  sendDanMu:function(event){
    // consloe.log(event)
    // 获取input里面值
    console.log(this.inoutValue)
    // 2.发送弹幕
    if (this.videoContext){
      this.videoContext.sendDanmu({
        text:this.inoutValue,
        color:'red',


      })
    }

  },

  onbindblur:function(event){
    // console.log(event.detail.value)
    // 把数据存在page对象
    this.inoutValue = event.detail.value;
  }
})