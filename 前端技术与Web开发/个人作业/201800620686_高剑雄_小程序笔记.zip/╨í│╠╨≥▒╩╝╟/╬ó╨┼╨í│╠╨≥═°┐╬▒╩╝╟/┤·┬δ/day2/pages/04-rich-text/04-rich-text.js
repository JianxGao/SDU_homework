// pages/04-rich-text/04-rich-text.js

// 定义了一个字符串模板
let htmlSnip=
`
  <h3>我是一个h2</h3>
  <p>hfdghkdfgkhdfkghkdfhgksgkhfdk飞海口龙华考试大纲风格和客服电话给看过跨多个给客顾客很对口高考和快感和肯定会看过跨多个是</p>
  <div class="div-class">上攻略:</div>



`


Page({

  /**
   * 页面的初始数据
   */
  data: {
    htmlSnip: htmlSnip,
    nodes:[
      {
        name:'div',
        attrs:{
          class:'div-class', 
          style:"background:gray"
        },
        children:[
          {
            type:'text',
            text:'上攻略1:'
          },
          {
            type:'text',
            text:'上攻略2:'
          }
        ],
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})