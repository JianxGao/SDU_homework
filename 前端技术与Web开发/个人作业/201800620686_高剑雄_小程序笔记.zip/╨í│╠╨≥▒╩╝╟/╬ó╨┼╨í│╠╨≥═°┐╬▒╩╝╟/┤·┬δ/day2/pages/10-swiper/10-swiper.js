// pages/10-swiper/10-swiper.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    banners: [
      'https://img20.360buyimg.com/pop/s1180x940_jfs/t1/107021/1/10614/58514/5e1de60aE3f9946db/aa8a8408c74deae7.jpg.webp',
      'https://img12.360buyimg.com/pop/s1180x940_jfs/t1/106610/6/12025/31828/5e425a19Ec5b6273b/eba9fbce2a0bcfc8.jpg.webp',
      'https://img13.360buyimg.com/pop/s1180x940_jfs/t1/109385/22/5588/89655/5e3d0541Ec3e8c351/711da03a91bc9e33.jpg.webp'
    ],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },


  onbindchange:function(event){
    console.log(event.detail)

  }
})