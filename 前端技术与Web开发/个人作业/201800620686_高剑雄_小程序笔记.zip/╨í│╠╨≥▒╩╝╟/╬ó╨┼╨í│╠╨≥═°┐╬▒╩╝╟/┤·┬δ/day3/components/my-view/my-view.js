Component({

  /**
   * 组件的属性列表
   */
  properties: {

    arrsPramas: {
      type: Array, // 类型（必填），目前接受的类型包括：String, Number, Boolean, Object, Array, null（表示任意类型）
      value: [0, 0, 0, 0], // 属性初始值（可选），如果未指定则会根据类型选择一个
      observer(newVal, oldVal, changedPath) {
        // 属性被改变时执行的函数（可选），也可以写成在methods段中定义的方法名字符串, 如：'_propertyChange'
        // 通常 newVal 就是新设置的数据， oldVal 是旧数据
        console.log(newVal, oldVal, changedPath) // [1,2,3,4] , [0,0,0,0] , ["arrsPramas"]
        // 通常这里也可以将数据备份到data中
        this.setData({
          as: newVal
        })
      }
    },
    
    strPramas: { // 属性名
      type: String, // 类型（必填），目前接受的类型包括：String, Number, Boolean, Object, Array, null（表示任意类型）
      value: '', // 属性初始值（可选），如果未指定则会根据类型选择一个
    },

    numPramas: Number // 简化的定义方式
    //...
  },


})
